import java.io.OutputStream;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Build-time tool: packs the class files of the running JDK's API modules into one jar.
 * The app uses it as the compile-time class library, so java.net.http, java.awt, etc. all exist.
 * Usage: java GenJdkApi.java <output.jar>
 */
public class GenJdkApi {
    static final String[] MODULES = {"java.base", "java.logging", "java.sql", "java.xml", "java.net.http",
            "java.management", "java.naming", "java.scripting", "java.desktop", "java.prefs", "java.compiler",
            "java.datatransfer", "java.instrument", "java.xml.crypto", "jdk.unsupported", "jdk.httpserver"};
    static final String[] DESKTOP_ONLY = {"java/awt/", "java/beans/", "javax/imageio/"};

    public static void main(String[] args) throws Exception {
        Path out = Paths.get(args[0]);
        if (out.getParent() != null) Files.createDirectories(out.getParent());
        FileSystem jrt = FileSystems.getFileSystem(URI.create("jrt:/"));
        long count = 0;
        try (OutputStream os = Files.newOutputStream(out); ZipOutputStream z = new ZipOutputStream(os)) {
            z.setLevel(9);
            for (String mod : MODULES) {
                Path root = jrt.getPath("/modules/" + mod);
                if (!Files.exists(root)) continue;
                List<Path> files;
                try (Stream<Path> s = Files.walk(root)) {
                    files = s.filter(p -> p.toString().endsWith(".class")).collect(Collectors.toList());
                }
                for (Path p : files) {
                    String rel = root.relativize(p).toString();
                    if (rel.equals("module-info.class")) continue;
                    if (mod.equals("java.desktop")) {
                        boolean ok = false;
                        for (String pre : DESKTOP_ONLY) if (rel.startsWith(pre)) ok = true;
                        if (!ok) continue;
                    }
                    z.putNextEntry(new ZipEntry(rel));
                    z.write(Files.readAllBytes(p));
                    z.closeEntry();
                    count++;
                }
            }
        }
        System.out.println("Wrote " + count + " classes, " + Files.size(out) / 1024 / 1024 + " MB -> " + out);
    }
}
