# Plugin Builder

Android app that compiles Java Minecraft plugins (Paper/Spigot) from your phone.
Pick a project folder, tap BUILD, get the .jar in Downloads/PluginBuilder.

## Two build modes
- **Cloud (default):** the app zips your project, uploads it to YOUR private GitHub repo, runs a build there
  with real Maven/Gradle and downloads the JAR. Supports Lombok, relocation, multi-module, anything.
  One-time setup inside the app: a GitHub token + repo name (the app installs the workflow itself).
- **On phone:** compiles locally with the Eclipse compiler. If the cloud build fails, the app asks
  before falling back to this.

Local mode supports: dependencies from pom.xml / build.gradle (auto-downloaded), full JDK class library
(java.net.http, java.awt, ...), multi-module Maven/Gradle projects, package relocation (shading),
and a simplified Lombok (Getter, Setter, Data, Value, Builder, constructors, ToString, EqualsAndHashCode,
NonNull, Slf4j). Other annotation processors and advanced Lombok features need the cloud mode.

## Recover source (decompiler)
The Recover tab turns a compiled plugin JAR back into an editable Maven project: decompiled Java (CFR), restored
resources and plugin.yml, a generated pom.xml (Paper version guessed from api-version, libraries read from the JAR's
Maven metadata) and notes. It then verifies itself: recompiles the result and compares classes, member signatures
and a call/string fingerprint against your original JAR (VERIFY_REPORT.txt). You can decompile on the phone (private, offline) or on GitHub (uploads the JAR to your private repo, runs CFR on a full Java
machine; if the cloud step fails the app asks before falling back to the phone). A decompiler can never restore comments or
local variable names, and no tool can guarantee 100% identical logic, so test the rebuilt plugin before using it.

## Getting the APK (no laptop)
1. Create a GitHub repo, upload PluginBuilder.zip (do not unzip it).
2. Add file > Create new file, name it `.github/workflows/build.yml`, paste the build.yml contents.
3. Actions tab > "Build APK" > Run workflow (about 6 minutes).
4. Download PluginBuilder.apk from the repo's Releases page and install it.

## Cloud token
Create a fine-grained token at github.com/settings/personal-access-tokens/new, only for your build repo, with
Repository permissions: Contents, Actions and Workflows = Read and write. Use a PRIVATE repo.

## Notes
- To support newer Java in local mode, bump `org.eclipse.jdt:ecj` in app/build.gradle and MAX_JAVA in Builder.java.
- Keep the app open while a cloud build runs (the screen stays on during builds).
