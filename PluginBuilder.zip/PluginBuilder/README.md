# Plugin Builder

Android app that compiles Java Minecraft plugins (Paper/Spigot) on the phone.
Pick a project folder, tap BUILD, get the .jar in Downloads/PluginBuilder.

## Get the APK (no laptop needed)
1. Create a GitHub repo, upload this project (or just PluginBuilder.zip, see below).
2. Add `.github/workflows/build.yml` (already inside this project).
3. Open the Actions tab, run "Build APK", wait about 5 minutes.
4. Open the repo's Releases page, download PluginBuilder.apk, install it.

## Using the app
- Choose project folder: the folder with pom.xml or build.gradle (or just src/ and plugin.yml).
- Dependencies are read from pom.xml / build.gradle and downloaded automatically.
- Paper API version: leave blank to use the project's own, or tap Pick for a list.
- Extra dependencies: `group:artifact:version`, one per line. Start with `+` to bundle into the jar.
- First build downloads about 26 MB (Java class library) plus dependencies. Later builds are fast.

## Limits
- Compiles against the Android Java class library: java.net.http, java.lang.management, java.awt etc. are missing.
- No Lombok or other annotation processors. No Maven/Gradle plugins (only shading without relocation).
- Multi-module projects: pick one module folder.
- To support newer Java, bump `org.eclipse.jdt:ecj` in app/build.gradle and MAX_JAVA in Builder.java.
