package com.rwee.pluginbuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilderFactory;

/** Minimal Maven POM model: properties, parent chain, dependencies, repositories. */
final class Pom {

    static final class Dep {
        String g, a, v, scope, classifier, type;
        boolean optional;
        final Set<String> excl = new HashSet<>();

        String key() { return g + ":" + a; }

        @Override public String toString() { return g + ":" + a + ":" + v; }
    }

    String groupId, artifactId, version, name, finalName, packaging = "jar";
    int javaVersion;
    boolean usesShade, hasRelocation;
    final Map<String, String> props = new HashMap<>();
    final List<Dep> deps = new ArrayList<>();
    final Map<String, Dep> managed = new HashMap<>();
    final List<String> repos = new ArrayList<>();
    final List<String> modules = new ArrayList<>();
    final List<String[]> relocations = new ArrayList<>();

    private static final Pattern VAR = Pattern.compile("\\$\\{([^}]+)\\}");

    /** parentLoader receives {groupId, artifactId, version} of the parent and returns its Pom (or null). */
    static Pom parse(File f, Function<String[], Pom> parentLoader) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(false);
        try {
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        } catch (Exception ignored) { }
        Document doc = dbf.newDocumentBuilder().parse(f);
        Element root = doc.getDocumentElement();
        Pom p = new Pom();

        Element par = child(root, "parent");
        if (par != null) {
            String pg = text(par, "groupId"), pa = text(par, "artifactId"), pv = text(par, "version");
            Pom pp = parentLoader == null ? null : parentLoader.apply(new String[]{pg, pa, pv});
            if (pp != null) {
                p.props.putAll(pp.props);
                p.managed.putAll(pp.managed);
                p.repos.addAll(pp.repos);
                p.groupId = pp.groupId;
                p.version = pp.version;
                p.javaVersion = pp.javaVersion;
                p.usesShade = pp.usesShade;
                p.hasRelocation = pp.hasRelocation;
                p.deps.addAll(pp.deps);
                p.relocations.addAll(pp.relocations);
            } else {
                p.groupId = pg;
                p.version = pv;
            }
            if (pv != null) {
                p.props.put("project.parent.version", pv);
                p.props.put("parent.version", pv);
            }
            if (pg != null) p.props.put("project.parent.groupId", pg);
        }

        String s;
        if ((s = text(root, "groupId")) != null) p.groupId = s;
        p.artifactId = text(root, "artifactId");
        if ((s = text(root, "version")) != null) p.version = s;
        p.name = text(root, "name");
        if ((s = text(root, "packaging")) != null) p.packaging = s;

        Element propsEl = child(root, "properties");
        if (propsEl != null) {
            for (Element e : children(propsEl, null)) p.props.put(e.getTagName(), e.getTextContent().trim());
        }
        // project.* values (resolved after property map is complete)
        p.groupId = p.sub(p.groupId);
        p.version = p.sub(p.version);
        if (p.groupId != null) { p.props.put("project.groupId", p.groupId); p.props.put("pom.groupId", p.groupId); }
        if (p.artifactId != null) { p.props.put("project.artifactId", p.artifactId); p.props.put("pom.artifactId", p.artifactId); }
        if (p.version != null) { p.props.put("project.version", p.version); p.props.put("pom.version", p.version); }
        p.name = p.sub(p.name);
        if (p.name != null) p.props.put("project.name", p.name);

        Element dm = child(root, "dependencyManagement");
        if (dm != null) {
            Element ds = child(dm, "dependencies");
            if (ds != null) {
                for (Element e : children(ds, "dependency")) {
                    Dep d = p.readDep(e);
                    if (d != null && !"import".equals(d.scope)) p.managed.put(d.key(), d);
                }
            }
        }
        Element ds = child(root, "dependencies");
        if (ds != null) {
            for (Element e : children(ds, "dependency")) {
                Dep d = p.readDep(e);
                if (d != null) {
                    final String k = d.key();
                    p.deps.removeIf(x -> x.key().equals(k));
                    p.deps.add(d);
                }
            }
        }
        Element rs = child(root, "repositories");
        if (rs != null) {
            for (Element r : children(rs, "repository")) {
                String url = p.sub(text(r, "url"));
                if (url != null && url.startsWith("http")) p.repos.add(url.endsWith("/") ? url : url + "/");
            }
        }

        Element ms = child(root, "modules");
        if (ms != null) {
            for (Element m : children(ms, "module")) {
                String mt = m.getTextContent().trim();
                if (!mt.isEmpty()) p.modules.add(mt);
            }
        }

        Element build = child(root, "build");
        if (build != null) {
            p.finalName = p.sub(text(build, "finalName"));
            Element plugins = child(build, "plugins");
            if (plugins != null) {
                for (Element pl : children(plugins, "plugin")) {
                    String aid = text(pl, "artifactId");
                    if (aid == null) continue;
                    if (aid.equals("maven-shade-plugin") || aid.equals("maven-assembly-plugin")) p.usesShade = true;
                    NodeList rl = pl.getElementsByTagName("relocation");
                    for (int ri = 0; ri < rl.getLength(); ri++) {
                        Element re = (Element) rl.item(ri);
                        String pat = p.sub(text(re, "pattern")), shaded = p.sub(text(re, "shadedPattern"));
                        if (pat != null && shaded != null) { p.relocations.add(new String[]{pat, shaded}); p.hasRelocation = true; }
                    }
                    if (aid.equals("maven-compiler-plugin")) {
                        Element cfg = child(pl, "configuration");
                        if (cfg != null) {
                            for (String t : new String[]{"release", "source", "target"}) {
                                int j = parseJava(p.sub(text(cfg, t)));
                                if (j > 0) { p.javaVersion = j; break; }
                            }
                        }
                    }
                }
            }
        }
        if (p.javaVersion == 0) {
            for (String k : new String[]{"maven.compiler.release", "maven.compiler.source", "maven.compiler.target", "java.version"}) {
                int j = parseJava(p.props.get(k) == null ? null : p.sub(p.props.get(k)));
                if (j > 0) { p.javaVersion = j; break; }
            }
        }
        return p;
    }

    /** Applies managed version/scope to a dependency declaration. */
    Dep effective(Dep d) {
        Dep m = managed.get(d.key());
        if (m == null) return d;
        Dep r = new Dep();
        r.g = d.g; r.a = d.a;
        r.v = d.v != null ? d.v : m.v;
        r.scope = d.scope != null ? d.scope : m.scope;
        r.classifier = d.classifier;
        r.type = d.type != null ? d.type : m.type;
        r.optional = d.optional;
        r.excl.addAll(d.excl);
        r.excl.addAll(m.excl);
        return r;
    }

    String sub(String s) {
        if (s == null) return null;
        for (int i = 0; i < 8 && s.contains("${"); i++) {
            Matcher m = VAR.matcher(s);
            StringBuffer sb = new StringBuffer();
            boolean changed = false;
            while (m.find()) {
                String val = props.get(m.group(1));
                if (val != null) changed = true; else val = m.group(0);
                m.appendReplacement(sb, Matcher.quoteReplacement(val));
            }
            m.appendTail(sb);
            s = sb.toString();
            if (!changed) break;
        }
        return s.trim();
    }

    private Dep readDep(Element e) {
        Dep d = new Dep();
        d.g = sub(text(e, "groupId"));
        d.a = sub(text(e, "artifactId"));
        d.v = sub(text(e, "version"));
        d.scope = sub(text(e, "scope"));
        d.classifier = sub(text(e, "classifier"));
        d.type = sub(text(e, "type"));
        d.optional = "true".equals(text(e, "optional"));
        Element ex = child(e, "exclusions");
        if (ex != null) {
            for (Element x : children(ex, "exclusion")) {
                String xg = text(x, "groupId"), xa = text(x, "artifactId");
                if (xg != null && xa != null) d.excl.add(xg + ":" + xa);
            }
        }
        return (d.g == null || d.a == null) ? null : d;
    }

    static int parseJava(String s) {
        if (s == null) return 0;
        s = s.trim();
        if (s.startsWith("1.")) s = s.substring(2);
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return 0; }
    }

    // ---- DOM helpers (direct children only) ----

    static Element child(Element parent, String tag) {
        List<Element> l = children(parent, tag);
        return l.isEmpty() ? null : l.get(0);
    }

    static List<Element> children(Element parent, String tag) {
        List<Element> out = new ArrayList<>();
        NodeList nl = parent.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n instanceof Element && (tag == null || ((Element) n).getTagName().equals(tag))) out.add((Element) n);
        }
        return out;
    }

    static String text(Element parent, String tag) {
        Element e = child(parent, tag);
        if (e == null) return null;
        String t = e.getTextContent();
        if (t == null) return null;
        t = t.trim();
        return t.isEmpty() ? null : t;
    }
}
