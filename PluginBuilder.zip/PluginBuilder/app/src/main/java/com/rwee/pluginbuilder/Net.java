package com.rwee.pluginbuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Tiny HTTP helper (redirect-following download + text fetch). */
final class Net {
    private Net() {}

    private static final String UA = "PluginBuilder/1.0";

    /** Returns an open 200 connection, or null for any other status code. */
    private static HttpURLConnection open(String url) throws IOException {
        String cur = url;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", UA);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect without Location header");
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            if (code != 200) {
                c.disconnect();
                return null;
            }
            return c;
        }
        throw new IOException("Too many redirects");
    }

    /** Downloads url to dest. Returns false on 404 / network error. */
    static boolean download(String url, File dest, BuildLog progress) {
        File tmp = new File(dest.getPath() + ".part");
        try {
            HttpURLConnection c = open(url);
            if (c == null) return false;
            File parent = dest.getParentFile();
            if (parent != null) parent.mkdirs();
            long total = c.getContentLengthLong();
            long done = 0, lastReport = 0;
            try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    done += n;
                    if (progress != null && total > 0 && done - lastReport > total / 5) {
                        lastReport = done;
                        progress.log("    " + (done * 100 / total) + "%");
                    }
                }
            }
            c.disconnect();
            if (dest.exists()) dest.delete();
            if (!tmp.renameTo(dest)) return false;
            return true;
        } catch (IOException e) {
            tmp.delete();
            return false;
        }
    }

    /** Fetches a URL as UTF-8 text, or null on failure. */
    static String text(String url) {
        try {
            HttpURLConnection c = open(url);
            if (c == null) return null;
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                return bos.toString("UTF-8");
            } finally {
                c.disconnect();
            }
        } catch (IOException e) {
            return null;
        }
    }
}
