package com.rwee.pluginbuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/** Tiny HTTP helper: redirect-following requests, downloads, text fetch. */
final class Net {
    private Net() {}

    private static final String UA = "PluginBuilder/1.1";

    static final class Resp {
        int code;
        byte[] body = new byte[0];
        String text() {
            try { return new String(body, "UTF-8"); } catch (IOException e) { return ""; }
        }
    }

    /** Opens a connection and follows redirects. Custom headers are dropped when the host changes. */
    private static HttpURLConnection connect(String method, String url, Map<String, String> headers, byte[] body)
            throws IOException {
        String cur = url, m = method;
        byte[] b = body;
        String host0 = new URL(url).getHost();
        for (int i = 0; i < 8; i++) {
            URL u = new URL(cur);
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod(m);
            c.setRequestProperty("User-Agent", UA);
            if (headers != null && u.getHost().equals(host0)) {
                for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            }
            if (b != null) {
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(b.length);
                try (OutputStream o = c.getOutputStream()) { o.write(b); }
            }
            int code = c.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect without Location header");
                cur = new URL(u, loc).toString();
                m = "GET";
                b = null;
                continue;
            }
            return c;
        }
        throw new IOException("Too many redirects");
    }

    static Resp request(String method, String url, Map<String, String> headers, byte[] body) throws IOException {
        HttpURLConnection c = connect(method, url, headers, body);
        try {
            Resp r = new Resp();
            r.code = c.getResponseCode();
            InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                try (InputStream is = in) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                    r.body = bos.toByteArray();
                }
            }
            return r;
        } finally {
            c.disconnect();
        }
    }

    static boolean download(String url, File dest, BuildLog progress) {
        return download(url, null, dest, progress);
    }

    /** Downloads url to dest. Returns false on any non-200 answer or network error. */
    static boolean download(String url, Map<String, String> headers, File dest, BuildLog progress) {
        File tmp = new File(dest.getPath() + ".part");
        try {
            HttpURLConnection c = connect("GET", url, headers, null);
            if (c.getResponseCode() != 200) {
                c.disconnect();
                return false;
            }
            File parent = dest.getParentFile();
            if (parent != null) parent.mkdirs();
            long total = c.getContentLengthLong();
            long done = 0, lastReport = 0;
            try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    done += n;
                    if (progress != null && total > 0 && done - lastReport > total / 5) {
                        lastReport = done;
                        progress.log("    " + (done * 100 / total) + "%");
                    }
                }
            }
            c.disconnect();
            if (dest.exists()) dest.delete();
            return tmp.renameTo(dest);
        } catch (IOException e) {
            tmp.delete();
            return false;
        }
    }

    /** Fetches a URL as UTF-8 text, or null on failure. */
    static String text(String url) {
        try {
            Resp r = request("GET", url, null, null);
            return r.code == 200 ? r.text() : null;
        } catch (IOException e) {
            return null;
        }
    }
}
