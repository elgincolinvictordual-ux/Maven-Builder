package com.rwee.pluginbuilder;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.commons.ClassRemapper;
import org.objectweb.asm.commons.Remapper;

import java.util.ArrayList;
import java.util.List;

/** Package relocation ("shading") of class files using ASM, like maven-shade / Shadow relocate. */
final class Relocator {
    private final List<String[]> internal = new ArrayList<>();   // {from/, to/}
    private final List<String[]> dotted = new ArrayList<>();     // {from, to}

    Relocator(List<String[]> rules) {
        for (String[] r : rules) {
            if (r == null || r.length < 2 || r[0] == null || r[1] == null) continue;
            internal.add(new String[]{r[0].replace('.', '/'), r[1].replace('.', '/')});
            dotted.add(new String[]{r[0], r[1]});
        }
    }

    boolean isEmpty() { return internal.isEmpty(); }

    /** Maps a class internal name or a resource path. */
    String mapPath(String p) {
        for (String[] r : internal) {
            if (p.startsWith(r[0] + "/")) return r[1] + p.substring(r[0].length());
        }
        return p;
    }

    byte[] rewrite(byte[] cls) {
        try {
            ClassReader cr = new ClassReader(cls);
            ClassWriter cw = new ClassWriter(0);
            cr.accept(new ClassRemapper(cw, new Remapper() {
                @Override public String map(String internalName) { return mapPath(internalName); }

                @Override public Object mapValue(Object value) {
                    if (value instanceof String) {
                        String s = (String) value;
                        for (String[] d : dotted) {
                            if (s.startsWith(d[0] + ".")) return d[1] + s.substring(d[0].length());
                        }
                    }
                    return super.mapValue(value);
                }
            }), 0);
            return cw.toByteArray();
        } catch (RuntimeException e) {
            return cls; // unsupported class version etc.: keep as is
        }
    }
}
