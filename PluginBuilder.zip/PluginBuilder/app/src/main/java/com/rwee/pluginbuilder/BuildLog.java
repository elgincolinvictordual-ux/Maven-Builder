package com.rwee.pluginbuilder;

/** Simple log sink so the build code stays independent from Android UI classes. */
public interface BuildLog {
    void log(String message);
}
