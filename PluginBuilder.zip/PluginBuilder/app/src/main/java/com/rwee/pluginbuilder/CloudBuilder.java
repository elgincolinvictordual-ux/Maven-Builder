package com.rwee.pluginbuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Builds a project on GitHub Actions: uploads a zip to the user's repo, triggers the workflow,
 * waits for it and downloads the resulting JAR(s).
 */
final class CloudBuilder {
    static final String WORKFLOW_FILE = "plugin-build.yml";
    static final String WORKFLOW_PATH = ".github/workflows/" + WORKFLOW_FILE;
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            ".git", "target", "build", ".gradle", ".idea", "out", "node_modules", ".vscode", ".github"));

    static final class CloudException extends Exception {
        final boolean buildFailed;
        CloudException(String m, boolean buildFailed) { super(m); this.buildFailed = buildFailed; }
    }

    private final Github gh;
    private final String workflowYaml;
    private final BuildLog log;
    long pollMs = 6000;

    CloudBuilder(Github gh, String workflowYaml, BuildLog log) {
        this.gh = gh;
        this.workflowYaml = workflowYaml;
        this.log = log;
    }

    /** Checks token + repo and installs the workflow. Returns a human readable status line. */
    String verifyAndSetup() throws CloudException {
        try {
            String who = gh.login();
            String branch = defaultBranch();
            ensureWorkflow(branch);
            return "Connected as " + who + ". Cloud builds are ready.";
        } catch (Github.ApiException e) {
            throw new CloudException(friendly(e), false);
        } catch (IOException e) {
            throw new CloudException("Network problem: " + e.getMessage(), false);
        }
    }

    List<File> build(File projectDir, int java, File outDir) throws CloudException {
        try {
            return doBuild(projectDir, java, outDir);
        } catch (CloudException e) {
            throw e;
        } catch (Github.ApiException e) {
            throw new CloudException(friendly(e), false);
        } catch (IOException e) {
            throw new CloudException("Network problem: " + e.getMessage(), false);
        }
    }

    private List<File> doBuild(File projectDir, int java, File outDir) throws IOException, CloudException {
        log.log("[1/5] Connecting to GitHub");
        String branch = defaultBranch();
        log.log("[2/5] Checking the cloud workflow");
        ensureWorkflow(branch);

        log.log("[3/5] Uploading project");
        String job = "j" + Long.toString(System.currentTimeMillis() / 1000, 36) + (int) (Math.random() * 90 + 10);
        File zip = File.createTempFile("project", ".zip");
        try {
            zipDir(projectDir, zip);
            log.log("  " + (zip.length() / 1024) + " KB");
            put("builds/" + job + ".zip", readAll(zip), "Plugin Builder upload " + job, branch, null);
        } finally {
            zip.delete();
        }

        log.log("[4/5] Building in the cloud");
        JSONObject body = Github.obj("ref", branch, "inputs", Github.obj("job", job, "java", String.valueOf(java)));
        for (int i = 0; ; i++) {
            try {
                gh.json("POST", "/actions/workflows/" + WORKFLOW_FILE + "/dispatches", body);
                break;
            } catch (Github.ApiException e) {
                if ((e.code == 404 || e.code == 422) && i < 8) { sleep(4000); continue; }
                throw e;
            }
        }

        long runId = 0;
        long deadline = System.currentTimeMillis() + 120_000;
        while (runId == 0 && System.currentTimeMillis() < deadline) {
            JSONObject r = gh.json("GET", "/actions/workflows/" + WORKFLOW_FILE
                    + "/runs?event=workflow_dispatch&per_page=10", null);
            JSONArray arr = r.optJSONArray("workflow_runs");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o != null && (o.optString("display_title") + " " + o.optString("name")).contains(job)) {
                        runId = o.optLong("id");
                        break;
                    }
                }
            }
            if (runId == 0) sleep(Math.max(500, pollMs / 2));
        }
        if (runId == 0) throw new CloudException("The cloud build did not start. Check the Actions tab of your repo.", false);

        String last = "";
        JSONObject run = null;
        long end = System.currentTimeMillis() + 25 * 60_000L;
        while (System.currentTimeMillis() < end) {
            run = gh.json("GET", "/actions/runs/" + runId, null);
            String st = run.optString("status");
            if (!st.equals(last)) { log.log("  cloud status: " + st.replace('_', ' ')); last = st; }
            if (st.equals("completed")) break;
            sleep(pollMs);
        }
        if (run == null || !"completed".equals(run.optString("status"))) {
            throw new CloudException("The cloud build timed out after 25 minutes.", false);
        }
        String conclusion = run.optString("conclusion");
        if (!conclusion.equals("success")) {
            logTail(runId);
            throw new CloudException("The cloud build ended with: " + conclusion + " (see the log above).", true);
        }

        log.log("[5/5] Downloading the JAR");
        JSONObject arts = gh.json("GET", "/actions/runs/" + runId + "/artifacts", null);
        String url = null;
        JSONArray aa = arts.optJSONArray("artifacts");
        if (aa != null) {
            for (int i = 0; i < aa.length(); i++) {
                JSONObject a = aa.optJSONObject(i);
                if (a != null && ("plugin-" + job).equals(a.optString("name"))) url = a.optString("archive_download_url");
            }
        }
        if (url == null) throw new CloudException("The build finished but produced no JAR.", true);
        File art = File.createTempFile("artifact", ".zip");
        try {
            if (!gh.download(url, art)) throw new CloudException("Could not download the built JAR.", false);
            return extractJars(art, outDir);
        } finally {
            art.delete();
        }
    }

    // ------------------------------------------------------------------

    private String defaultBranch() throws IOException {
        JSONObject r = gh.json("GET", "", null);
        boolean priv = r.optBoolean("private");
        log.log("  repo " + r.optString("full_name") + (priv ? " (private)" : " (PUBLIC: your uploaded source is visible to everyone)"));
        return r.optString("default_branch", "main");
    }

    private void ensureWorkflow(String branch) throws IOException {
        String sha = null;
        try {
            JSONObject f = gh.json("GET", "/contents/" + WORKFLOW_PATH + "?ref=" + branch, null);
            sha = f.optString("sha", null);
            String cur = new String(Base64.getMimeDecoder().decode(f.optString("content", "")), "UTF-8");
            if (cur.equals(workflowYaml)) { log.log("  workflow ready"); return; }
        } catch (Github.ApiException e) {
            if (e.code != 404) throw e;
        }
        log.log("  installing the build workflow in your repo...");
        put(WORKFLOW_PATH, workflowYaml.getBytes("UTF-8"), "Add Plugin Builder workflow", branch, sha);
        sleep(Math.min(5000, pollMs));
    }

    private void put(String path, byte[] data, String msg, String branch, String sha) throws IOException {
        JSONObject b = Github.obj("message", msg, "content", Base64.getEncoder().encodeToString(data), "branch", branch);
        try {
            if (sha != null) b.put("sha", sha);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        try {
            gh.json("PUT", "/contents/" + path, b);
        } catch (Github.ApiException e) {
            if (e.code == 404 || e.code == 422) {   // e.g. empty repo: let GitHub pick the branch
                b.remove("branch");
                gh.json("PUT", "/contents/" + path, b);
            } else throw e;
        }
    }

    private void logTail(long runId) {
        try {
            JSONObject jobs = gh.json("GET", "/actions/runs/" + runId + "/jobs", null);
            JSONArray ja = jobs.optJSONArray("jobs");
            if (ja == null || ja.length() == 0) return;
            long id = ja.getJSONObject(0).optLong("id");
            String txt = gh.text("/actions/jobs/" + id + "/logs");
            List<String> lines = new ArrayList<>();
            for (String l : txt.split("\\n")) lines.add(l.replaceFirst("^\\S+Z\\s", ""));
            List<String> pick = new ArrayList<>();
            for (String l : lines) if (l.contains("ERROR") || l.contains("error:") || l.contains("FAILURE") || l.contains("What went wrong")) pick.add(l);
            if (pick.isEmpty()) pick = lines.subList(Math.max(0, lines.size() - 40), lines.size());
            if (pick.size() > 40) pick = pick.subList(0, 40);
            log.log("  ---- cloud log ----");
            for (String l : pick) log.log("  " + l);
        } catch (Exception e) {
            log.log("  (could not fetch the cloud log: " + e.getMessage() + ")");
        }
    }

    private static String friendly(Github.ApiException e) {
        switch (e.code) {
            case 401: return "GitHub rejected the token (invalid or expired).";
            case 403: return "GitHub refused the request. The token needs access to this repo with Contents, Actions and Workflows write permission (classic tokens: repo + workflow). " + e.getMessage();
            case 404: return "Repository not found, or the token can't access it. Check the repo name and the token's permissions.";
            default: return "GitHub error " + e.code + ": " + e.getMessage();
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }

    private static byte[] readAll(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        }
    }

    static void zipDir(File dir, File zip) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(zip))) {
            addDir(z, dir, "");
        }
    }

    private static void addDir(ZipOutputStream z, File dir, String prefix) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) {
                if (!SKIP.contains(f.getName())) addDir(z, f, prefix + f.getName() + "/");
            } else if (f.length() < 50L * 1024 * 1024) {
                z.putNextEntry(new ZipEntry(prefix + f.getName()));
                try (InputStream in = new FileInputStream(f)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                }
                z.closeEntry();
            }
        }
    }

    private static List<File> extractJars(File zip, File outDir) throws IOException, CloudException {
        outDir.mkdirs();
        List<File> out = new ArrayList<>();
        try (ZipFile zf = new ZipFile(zip)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                String n = new File(ze.getName()).getName();
                if (ze.isDirectory() || !n.endsWith(".jar")) continue;
                File f = new File(outDir, n);
                try (InputStream in = zf.getInputStream(ze); OutputStream o = new FileOutputStream(f)) {
                    byte[] buf = new byte[65536];
                    int c;
                    while ((c = in.read(buf)) > 0) o.write(buf, 0, c);
                }
                out.add(f);
            }
        }
        if (out.isEmpty()) throw new CloudException("The build finished but the artifact held no JAR.", true);
        return out;
    }
}
