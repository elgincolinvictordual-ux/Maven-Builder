package com.rwee.pluginbuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Simplified source-level Lombok expansion for the on-phone compiler.
 * Supports the common annotations (Getter, Setter, ToString, EqualsAndHashCode, constructors,
 * Data, Value, basic Builder, NonNull, Slf4j/Log/Log4j2). Everything else is reported as unsupported.
 */
final class MiniLombok {

    private static final Set<String> SUPPORTED = new HashSet<>(Arrays.asList(
            "Getter", "Setter", "ToString", "ToString.Exclude", "EqualsAndHashCode", "EqualsAndHashCode.Exclude",
            "NoArgsConstructor", "AllArgsConstructor", "RequiredArgsConstructor", "Data", "Value", "Builder",
            "NonNull", "Slf4j", "Log", "Log4j2"));
    private static final Set<String> UNSUPPORTED = new HashSet<>(Arrays.asList(
            "Singular", "Builder.Default", "SneakyThrows", "Synchronized", "Cleanup", "With", "Accessors",
            "UtilityClass", "Delegate", "FieldDefaults", "ExtensionMethod", "Locked", "StandardException",
            "CommonsLog", "Log4j", "JBossLog", "XSlf4j", "Jacksonized", "SuperBuilder", "val", "var"));
    private static final Set<String> MODS = new HashSet<>(Arrays.asList(
            "public", "protected", "private", "static", "final", "transient", "volatile"));
    private static final Set<String> PRIMS = new HashSet<>(Arrays.asList(
            "boolean", "byte", "short", "char", "int", "long", "float", "double"));
    private static final Pattern ANN = Pattern.compile("@\\s*([A-Za-z_][\\w.]*)\\s*(\\((?:[^()]|\\([^()]*\\))*\\))?");
    private static final Pattern CLASS_KW = Pattern.compile("\\b(class|enum)\\s+(\\w+)");

    static boolean usesLombok(String src) { return src.contains("import lombok."); }

    private static final class Ann {
        String name, args;
        int start, end;
        String simple() { return name.startsWith("lombok.") ? name.substring(7) : name; }
    }

    private static final class Field {
        String name, type;
        boolean isStatic, isFinal, hasInit, nonNull, isTransient;
        List<Ann> anns = new ArrayList<>();
        Ann get(String n) { for (Ann a : anns) if (a.simple().equals(n)) return a; return null; }
    }

    /** Returns transformed source; unsupported usages are appended to warnings. */
    static String transform(String src, List<String> warnings) {
        String cur = src;
        for (int guard = 0; guard < 300; guard++) {
            String next = processOne(cur);
            if (next == null) break;
            cur = next;
        }
        // report unsupported annotations still present
        String m = mask(cur);
        Set<String> found = new HashSet<>();
        Matcher am = ANN.matcher(m);
        while (am.find()) {
            String n = am.group(1);
            if (n.startsWith("lombok.")) n = n.substring(7);
            if (UNSUPPORTED.contains(n)) found.add("@" + n);
        }
        if (cur.contains("import lombok.val;") || cur.contains("import lombok.var;")) found.add("val");
        if (!found.isEmpty()) warnings.add("Unsupported Lombok features: " + found + " (use the cloud build for these)");
        // drop imports of handled annotations
        StringBuilder out = new StringBuilder();
        for (String line : cur.split("\\n", -1)) {
            Matcher im = Pattern.compile("^\\s*import\\s+lombok\\.(?:extern\\.\\w+\\.)?(\\w+)(?:\\.\\w+)*\\s*;\\s*$").matcher(line);
            if (im.matches() && SUPPORTED.contains(im.group(1))) continue;
            if (line.trim().equals("import lombok.*;") && found.isEmpty()) continue;
            out.append(line).append('\n');
        }
        if (out.length() > 0) out.setLength(out.length() - 1);
        return out.toString();
    }

    // ------------------------------------------------------------------

    private static String processOne(String src) {
        String m = mask(src);
        Matcher cm = CLASS_KW.matcher(m);
        int bestKw = -1;
        List<int[]> cands = new ArrayList<>();
        while (cm.find()) {
            int kw = cm.start();
            int p = kw - 1;
            while (p >= 0 && Character.isWhitespace(m.charAt(p))) p--;
            if (p >= 0 && m.charAt(p) == '.') continue; // Foo.class
            cands.add(new int[]{kw, cm.end(1) == 0 ? 0 : cm.start(2), cm.end(2)});
        }
        for (int i = cands.size() - 1; i >= 0; i--) {
            int[] c = cands.get(i);
            if (handle(src, m, c[0], c[2])) {
                return lastResult;
            }
        }
        return null;
    }

    private static String lastResult;

    /** Tries to expand lombok annotations for the class declared at kw. Sets lastResult on success. */
    private static boolean handle(String src, String m, int kw, int nameEnd) {
        int open = m.indexOf('{', nameEnd);
        if (open < 0) return false;
        int close = matching(m, open);
        if (close < 0) return false;
        int hs = kw - 1;
        while (hs >= 0 && "{};".indexOf(m.charAt(hs)) < 0) hs--;
        hs++;
        String name = classNameAt(m, kw);
        boolean isEnum = m.startsWith("enum", kw);
        String headTail = m.substring(nameEnd, open);
        String typeParams = "";
        Matcher tp = Pattern.compile("^\\s*<").matcher(headTail);
        boolean generic = tp.find();
        if (generic) typeParams = "<?>";

        List<Ann> classAnns = annotations(src, m, hs, kw);
        List<Ann> useClass = new ArrayList<>();
        for (Ann a : classAnns) if (SUPPORTED.contains(a.simple())) useClass.add(a);

        List<Field> fields = new ArrayList<>();
        List<String> memberMasks = new ArrayList<>();
        members(src, m, open + 1, close, fields, memberMasks);
        boolean fieldHas = false;
        for (Field f : fields) for (Ann a : f.anns) if (SUPPORTED.contains(a.simple())) fieldHas = true;
        if (useClass.isEmpty() && !fieldHas) return false;

        Set<String> cls = new HashSet<>();
        for (Ann a : useClass) cls.add(a.simple());
        String bodyMask = m.substring(open + 1, close);

        StringBuilder gen = new StringBuilder();
        boolean data = cls.contains("Data"), value = cls.contains("Value");
        boolean ctorAnn = cls.contains("NoArgsConstructor") || cls.contains("AllArgsConstructor")
                || cls.contains("RequiredArgsConstructor");
        boolean explicitCtor = hasCtor(memberMasks, name);

        if (cls.contains("Slf4j")) gen.append("    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(").append(name).append(".class);\n");
        if (cls.contains("Log")) gen.append("    private static final java.util.logging.Logger log = java.util.logging.Logger.getLogger(").append(name).append(".class.getName());\n");
        if (cls.contains("Log4j2")) gen.append("    private static final org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(").append(name).append(".class);\n");

        // constructors
        if (cls.contains("NoArgsConstructor")) gen.append(ctor(name, access(find(useClass, "NoArgsConstructor"), "access"), new ArrayList<Field>()));
        if (cls.contains("AllArgsConstructor") || (!explicitCtor && !ctorAnn && (value || cls.contains("Builder")))) {
            Ann a = find(useClass, "AllArgsConstructor");
            gen.append(ctor(name, a != null ? access(a, "access") : (value ? "public" : ""), allArgs(fields)));
        }
        if (cls.contains("RequiredArgsConstructor") || (data && !explicitCtor && !ctorAnn && !cls.contains("Builder"))) {
            gen.append(ctor(name, access(find(useClass, "RequiredArgsConstructor"), "access"), required(fields)));
        }

        // accessors
        boolean classGet = cls.contains("Getter") || data || value, classSet = cls.contains("Setter") || data;
        for (Field f : fields) {
            Ann g = f.get("Getter"), s = f.get("Setter");
            String ga = g != null ? access(g, "value") : classGet && !f.isStatic ? "public" : null;
            String sa = s != null ? access(s, "value") : classSet && !f.isStatic ? "public" : null;
            if (ga != null && !ga.equals("NONE")) {
                String gn = getterName(f);
                if (!has(memberMasks, gn)) gen.append("    ").append(ga.isEmpty() ? "" : ga + " ").append(f.isStatic ? "static " : "")
                        .append(f.type).append(' ').append(gn).append("() { return ").append(f.isStatic ? name + "." : "this.").append(f.name).append("; }\n");
            }
            if (sa != null && !sa.equals("NONE") && !f.isFinal) {
                String sn = setterName(f);
                if (!has(memberMasks, sn)) {
                    gen.append("    ").append(sa.isEmpty() ? "" : sa + " ").append(f.isStatic ? "static " : "").append("void ").append(sn)
                            .append('(').append(f.type).append(' ').append(f.name).append(") { ");
                    if (f.nonNull) gen.append("if (").append(f.name).append(" == null) throw new NullPointerException(\"").append(f.name).append(" is marked non-null but is null\"); ");
                    gen.append(f.isStatic ? name + "." : "this.").append(f.name).append(" = ").append(f.name).append("; }\n");
                }
            }
        }

        if ((cls.contains("ToString") || data || value) && !has(memberMasks, "toString")) {
            StringBuilder sb = new StringBuilder("    @Override public String toString() { return \"" + name + "(\"");
            boolean first = true;
            for (Field f : fields) {
                if (f.isStatic || f.get("ToString.Exclude") != null) continue;
                sb.append(" + \"").append(first ? "" : ", ").append(f.name).append("=\" + ");
                if (f.type.matches("(boolean|byte|short|char|int|long|float|double)\\[\\]")) sb.append("java.util.Arrays.toString(this.").append(f.name).append(")");
                else if (f.type.endsWith("[]")) sb.append("java.util.Arrays.deepToString(this.").append(f.name).append(")");
                else sb.append("this.").append(f.name);
                first = false;
            }
            sb.append(" + \")\"; }\n");
            gen.append(sb);
        }
        if ((cls.contains("EqualsAndHashCode") || data || value) && !has(memberMasks, "equals") && !has(memberMasks, "hashCode")) {
            List<Field> eq = new ArrayList<>();
            for (Field f : fields) if (!f.isStatic && !f.isTransient && f.get("EqualsAndHashCode.Exclude") == null) eq.add(f);
            gen.append("    @Override public boolean equals(Object o) { if (o == this) return true; if (!(o instanceof ").append(name).append(")) return false; ")
                    .append(name).append(typeParams).append(" other = (").append(name).append(typeParams).append(") o; return true");
            for (Field f : eq) gen.append(" && java.util.Objects.deepEquals(this.").append(f.name).append(", other.").append(f.name).append(")");
            gen.append("; }\n    @Override public int hashCode() { return java.util.Arrays.deepHashCode(new Object[]{");
            for (int i = 0; i < eq.size(); i++) gen.append(i > 0 ? ", " : "").append("this.").append(eq.get(i).name);
            gen.append("}); }\n");
        }

        if (cls.contains("Builder")) {
            if (generic) return false;
            List<Field> bf = allArgs(fields);
            String bn = name + "Builder";
            gen.append("    public static ").append(bn).append(" builder() { return new ").append(bn).append("(); }\n");
            gen.append("    public static class ").append(bn).append(" {\n");
            for (Field f : bf) gen.append("        private ").append(f.type).append(' ').append(f.name).append(";\n");
            gen.append("        ").append(bn).append("() {}\n");
            for (Field f : bf) gen.append("        public ").append(bn).append(' ').append(f.name).append('(').append(f.type).append(' ')
                    .append(f.name).append(") { this.").append(f.name).append(" = ").append(f.name).append("; return this; }\n");
            gen.append("        public ").append(name).append(" build() { return new ").append(name).append("(");
            for (int i = 0; i < bf.size(); i++) gen.append(i > 0 ? ", " : "").append("this.").append(bf.get(i).name);
            gen.append("); }\n    }\n");
        }

        // build the new source: remove handled annotations (descending), then insert generated code before close
        List<int[]> removals = new ArrayList<>();
        for (Ann a : useClass) removals.add(new int[]{a.start, a.end});
        for (Field f : fields) for (Ann a : f.anns) if (SUPPORTED.contains(a.simple())) removals.add(new int[]{a.start, a.end});
        StringBuilder out = new StringBuilder(src);
        String insert = gen.toString();
        if (isEnum && insert.length() > 0 && bodyMask.indexOf(';') < 0) insert = "    ;\n" + insert;
        if (insert.length() > 0) out.insert(close, (src.charAt(close - 1) == '\n' ? "" : "\n") + insert);
        removals.sort((x, y) -> y[0] - x[0]);
        for (int[] r : removals) out.delete(r[0], r[1]);
        lastResult = out.toString();
        return true;
    }

    // ---- helpers -------------------------------------------------------

    private static Ann find(List<Ann> l, String n) {
        for (Ann a : l) if (a.simple().equals(n)) return a;
        return null;
    }

    /** True if a member declaration (not a call inside a body) already defines this method name. */
    private static boolean has(List<String> members, String method) {
        Pattern p = Pattern.compile("\\b" + Pattern.quote(method) + "\\s*\\(");
        for (String s : members) {
            int cut = s.length();
            for (char ch : new char[]{'{', ';', '='}) {
                int i = s.indexOf(ch);
                if (i >= 0 && i < cut) cut = i;
            }
            if (p.matcher(s.substring(0, cut)).find()) return true;
        }
        return false;
    }

    private static boolean hasCtor(List<String> members, String name) {
        Pattern p = Pattern.compile("^\\s*(?:(?:public|protected|private)\\s+)?" + Pattern.quote(name) + "\\s*\\(");
        for (String s : members) if (p.matcher(s).find()) return true;
        return false;
    }

    private static String access(Ann a, String key) {
        if (a == null || a.args == null) return "public";
        Matcher mm = Pattern.compile("AccessLevel\\.(\\w+)").matcher(a.args);
        if (!mm.find()) return "public";
        switch (mm.group(1)) {
            case "NONE": return "NONE";
            case "PRIVATE": return "private";
            case "PROTECTED": return "protected";
            case "PACKAGE": return "";
            default: return "public";
        }
    }

    private static String ctor(String name, String acc, List<Field> fs) {
        if ("NONE".equals(acc)) return "";
        StringBuilder sb = new StringBuilder("    ");
        if (!acc.isEmpty()) sb.append(acc).append(' ');
        sb.append(name).append('(');
        for (int i = 0; i < fs.size(); i++) sb.append(i > 0 ? ", " : "").append(fs.get(i).type).append(' ').append(fs.get(i).name);
        sb.append(") { ");
        for (Field f : fs) {
            if (f.nonNull) sb.append("if (").append(f.name).append(" == null) throw new NullPointerException(\"").append(f.name).append(" is marked non-null but is null\"); ");
            sb.append("this.").append(f.name).append(" = ").append(f.name).append("; ");
        }
        return sb.append("}\n").toString();
    }

    private static List<Field> allArgs(List<Field> fields) {
        List<Field> r = new ArrayList<>();
        for (Field f : fields) if (!f.isStatic && !(f.isFinal && f.hasInit)) r.add(f);
        return r;
    }

    private static List<Field> required(List<Field> fields) {
        List<Field> r = new ArrayList<>();
        for (Field f : fields) if (!f.isStatic && ((f.isFinal && !f.hasInit) || (f.nonNull && !f.hasInit))) r.add(f);
        return r;
    }

    private static String cap(String s) { return Character.toUpperCase(s.charAt(0)) + s.substring(1); }

    private static boolean isIsName(Field f) {
        return f.type.equals("boolean") && f.name.length() > 2 && f.name.startsWith("is") && Character.isUpperCase(f.name.charAt(2));
    }

    private static String getterName(Field f) {
        if (f.type.equals("boolean")) return isIsName(f) ? f.name : "is" + cap(f.name);
        return "get" + cap(f.name);
    }

    private static String setterName(Field f) {
        return "set" + cap(isIsName(f) ? f.name.substring(2) : f.name);
    }

    private static String classNameAt(String m, int kw) {
        Matcher mm = CLASS_KW.matcher(m);
        mm.find(kw);
        return mm.group(2);
    }

    private static List<Ann> annotations(String src, String m, int from, int to) {
        List<Ann> out = new ArrayList<>();
        Matcher am = ANN.matcher(m.substring(from, to));
        while (am.find()) {
            Ann a = new Ann();
            a.name = am.group(1);
            a.args = am.group(2) == null ? null : src.substring(from + am.start(2), from + am.end(2));
            a.start = from + am.start();
            a.end = from + am.end();
            out.add(a);
        }
        return out;
    }

    private static void members(String src, String m, int from, int to, List<Field> fields, List<String> memberMasks) {
        int i = from;
        while (i < to) {
            int start = i;
            int depthB = 0, depthP = 0;
            boolean hasEq = false;
            int end = -1;
            while (i < to) {
                char c = m.charAt(i);
                if (c == '(') depthP++;
                else if (c == ')') depthP--;
                else if (c == '=' && depthP == 0 && depthB == 0) hasEq = true;
                else if (c == '{') depthB++;
                else if (c == '}') {
                    depthB--;
                    if (depthB == 0 && !hasEq) { end = i + 1; i++; break; }
                } else if (c == ';' && depthB == 0 && depthP == 0) { end = i + 1; i++; break; }
                i++;
            }
            if (end < 0) end = to;
            String mm = m.substring(start, end);
            memberMasks.add(mm);
            if (mm.trim().isEmpty()) continue;
            Field f = parseField(src, m, start, end);
            if (f != null) fields.add(f);
        }
    }

    private static Field parseField(String src, String m, int start, int end) {
        String mm = m.substring(start, end);
        if (!mm.trim().endsWith(";")) return null;
        int eq = -1, dp = 0;
        for (int k = 0; k < mm.length(); k++) {
            char c = mm.charAt(k);
            if (c == '(') dp++;
            else if (c == ')') dp--;
            else if (c == '=' && dp == 0) { eq = k; break; }
        }
        String decl = eq >= 0 ? mm.substring(0, eq) : mm.substring(0, mm.lastIndexOf(';'));
        List<Ann> anns = annotations(src, m, start, start + decl.length());
        String stripped = ANN.matcher(decl).replaceAll(" ");
        if (stripped.contains("(")) return null;           // method or abstract method
        if (stripped.contains(",") && !stripped.contains("<")) return null; // multiple declarators
        Matcher nm = Pattern.compile("(\\w+)\\s*$").matcher(stripped);
        if (!nm.find()) return null;
        String name = nm.group(1);
        String before = stripped.substring(0, nm.start()).trim();
        if (before.isEmpty() || before.startsWith("class ") || before.contains(" class ") || before.startsWith("enum ")) return null;
        Field f = new Field();
        f.name = name;
        f.hasInit = eq >= 0;
        f.anns = anns;
        StringBuilder type = new StringBuilder();
        for (String tok : before.split("\\s+")) {
            if (MODS.contains(tok)) {
                if (tok.equals("static")) f.isStatic = true;
                else if (tok.equals("final")) f.isFinal = true;
                else if (tok.equals("transient")) f.isTransient = true;
            } else {
                if (type.length() > 0) type.append(' ');
                type.append(tok);
            }
        }
        f.type = type.toString().trim();
        if (f.type.isEmpty() || f.type.equals("return") || f.type.equals("throw")) return null;
        for (Ann a : anns) if (a.simple().equals("NonNull")) f.nonNull = true;
        return f;
    }

    private static int matching(String m, int open) {
        int d = 0;
        for (int i = open; i < m.length(); i++) {
            char c = m.charAt(i);
            if (c == '{') d++;
            else if (c == '}') { d--; if (d == 0) return i; }
        }
        return -1;
    }

    /** Blanks out comments and string/char literal contents (keeps length and newlines). */
    static String mask(String s) {
        char[] c = s.toCharArray();
        int n = c.length, i = 0;
        while (i < n) {
            char ch = c[i];
            if (ch == '/' && i + 1 < n && c[i + 1] == '/') {
                while (i < n && c[i] != '\n') c[i++] = ' ';
            } else if (ch == '/' && i + 1 < n && c[i + 1] == '*') {
                c[i++] = ' '; c[i++] = ' ';
                while (i < n && !(c[i] == '*' && i + 1 < n && c[i + 1] == '/')) { if (c[i] != '\n') c[i] = ' '; i++; }
                if (i < n) { c[i++] = ' '; if (i < n) c[i++] = ' '; }
            } else if (ch == '"' && i + 2 < n && c[i + 1] == '"' && c[i + 2] == '"') {
                i += 3;
                while (i < n && !(c[i] == '"' && i + 2 < n && c[i + 1] == '"' && c[i + 2] == '"')) { if (c[i] != '\n') c[i] = ' '; i++; }
                i += 3;
            } else if (ch == '"' || ch == '\'') {
                char q = ch;
                i++;
                while (i < n && c[i] != q && c[i] != '\n') {
                    if (c[i] == '\\' && i + 1 < n) { c[i++] = ' '; }
                    c[i++] = ' ';
                }
                i++;
            } else i++;
        }
        return new String(c);
    }
}
