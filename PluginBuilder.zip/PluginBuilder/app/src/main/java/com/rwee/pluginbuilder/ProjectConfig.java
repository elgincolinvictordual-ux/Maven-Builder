package com.rwee.pluginbuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads dependencies, repositories, modules and basic info from pom.xml or build.gradle(.kts). */
final class ProjectConfig {
    String system = "none";          // maven | gradle | none
    String name, version, groupId, finalName;
    int javaVersion;
    boolean shade, gradleSubprojects;
    Pom pom;                          // only for maven projects
    final List<Pom.Dep> deps = new ArrayList<>();
    final List<String> repos = new ArrayList<>();
    final List<String> modules = new ArrayList<>();
    final List<String[]> relocations = new ArrayList<>();
    final List<String[]> modDeps = new ArrayList<>();   // gradle project(':x') deps: {name, scope}
    final Map<String, String> vars = new HashMap<>();

    private static final Pattern G_DEP = Pattern.compile(
            "(?m)^\\s*(compileOnly|implementation|api|compile|provided|shadow|runtimeOnly)\\b\\s*\\(?\\s*[\"']"
                    + "([^\"':\\s$]+):([^\"':\\s$]+):([^\"':@\\s$]+)(?::([^\"'\\s$@]+))?[\"']");
    private static final Pattern G_PROJ = Pattern.compile(
            "(?m)^\\s*(compileOnly|implementation|api|compile|provided|shadow)\\b\\s*\\(?\\s*project\\(\\s*(?:path\\s*[:=]\\s*)?[\"']:?([^\"']+)[\"']");
    private static final Pattern G_VARDEP = Pattern.compile(
            "(?m)^\\s*(compileOnly|implementation|api|compile|provided|shadow)\\b[^\\n]*\\$");
    private static final Pattern G_REPO = Pattern.compile(
            "(?:\\burl\\s*=?\\s*(?:uri\\()?|\\bmaven\\s*\\(\\s*)\\s*[\"'](https?://[^\"']+)[\"']");
    private static final Pattern G_JAVA1 = Pattern.compile("JavaLanguageVersion\\.of\\(\\s*(\\d+)");
    private static final Pattern G_JAVA2 = Pattern.compile("release(?:\\.set)?\\s*[(=]\\s*(\\d+)");
    private static final Pattern G_JAVA3 = Pattern.compile("JavaVersion\\.VERSION_(?:1_)?(\\d+)");
    private static final Pattern G_VERSION = Pattern.compile("(?m)^\\s*version\\s*=?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern G_GROUP = Pattern.compile("(?m)^\\s*group\\s*=?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern G_NAME = Pattern.compile("rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']");
    private static final Pattern G_RELOC = Pattern.compile("relocate\\s*\\(?\\s*[\"']([^\"']+)[\"']\\s*,\\s*[\"']([^\"']+)[\"']");
    private static final Pattern G_INCLUDE = Pattern.compile("\\binclude\\s*\\(?((?:\\s*[\"'][^\"']*[\"']\\s*,?)+)");

    static ProjectConfig detect(File root, BuildLog log) {
        ProjectConfig c = new ProjectConfig();
        File pomF = new File(root, "pom.xml");
        File gradle = new File(root, "build.gradle");
        if (!gradle.isFile()) gradle = new File(root, "build.gradle.kts");
        try {
            if (pomF.isFile()) c.readMaven(pomF, log);
            else if (gradle.isFile()) c.readGradle(root, gradle, log);
            else if (new File(root, "settings.gradle").isFile() || new File(root, "settings.gradle.kts").isFile()) c.readSettingsOnly(root);
            else log.log("No pom.xml or build.gradle in " + root.getName() + ": using the Paper version field and extra dependencies only.");
        } catch (Exception e) {
            log.log("Warning: could not read the build file (" + e + "). Continuing without it.");
        }
        if (c.name == null) c.name = root.getName();
        if (c.version != null && c.version.contains("${")) c.version = null;
        return c;
    }

    /** Looks for ../pom.xml so multi-module children can inherit properties and managed versions. */
    static Function<String[], Pom> localParent(File pomFile) {
        return pr -> {
            File dir = pomFile.getAbsoluteFile().getParentFile();
            File pp = dir == null || dir.getParentFile() == null ? null : new File(dir.getParentFile(), "pom.xml");
            if (pp == null || !pp.isFile()) return null;
            try {
                Pom p = Pom.parse(pp, localParent(pp));
                return pr[1] != null && pr[1].equals(p.artifactId) ? p : null;
            } catch (Exception e) {
                return null;
            }
        };
    }

    private void readMaven(File f, BuildLog log) throws Exception {
        Pom p = Pom.parse(f, localParent(f));
        pom = p;
        system = "maven";
        name = p.artifactId;
        version = p.version;
        groupId = p.groupId;
        finalName = p.finalName;
        javaVersion = p.javaVersion;
        shade = p.usesShade;
        deps.addAll(p.deps);
        repos.addAll(p.repos);
        modules.addAll(p.modules);
        relocations.addAll(p.relocations);
        vars.putAll(p.props);
        if (modules.isEmpty()) {
            log.log("Maven project: " + p.artifactId + " " + (p.version == null ? "" : p.version)
                    + " (" + p.deps.size() + " dependencies" + (shade ? ", shading on" : "") + ")");
        }
    }

    private void readSettingsOnly(File root) throws IOException {
        system = "gradle";
        File settings = new File(root, "settings.gradle");
        if (!settings.isFile()) settings = new File(root, "settings.gradle.kts");
        readSettings(settings);
    }

    private void readSettings(File settings) throws IOException {
        String st = read(settings);
        Matcher nm = G_NAME.matcher(st);
        if (nm.find()) name = nm.group(1);
        Matcher im = G_INCLUDE.matcher(st);
        while (im.find()) {
            Matcher q = Pattern.compile("[\"']:?([^\"']+)[\"']").matcher(im.group(1));
            while (q.find()) modules.add(q.group(1).replace(':', '/'));
        }
    }

    private void readGradle(File root, File f, BuildLog log) throws IOException {
        system = "gradle";
        String t = read(f);
        Matcher m = G_DEP.matcher(t);
        while (m.find()) {
            Pom.Dep d = new Pom.Dep();
            String cfg = m.group(1);
            d.g = m.group(2);
            d.a = m.group(3);
            d.v = m.group(4);
            d.classifier = m.group(5);
            d.scope = scopeOf(cfg);
            deps.add(d);
        }
        Matcher pm = G_PROJ.matcher(t);
        while (pm.find()) modDeps.add(new String[]{pm.group(2).replace(':', '/'), scopeOf(pm.group(1))});
        Matcher vm = G_VARDEP.matcher(t);
        int skipped = 0;
        while (vm.find()) { if (!vm.group().contains("project(")) skipped++; }
        if (skipped > 0) {
            log.log("Note: " + skipped + " Gradle dependency line(s) use variables and were skipped."
                    + " Add them under Extra dependencies if needed.");
        }
        Matcher rm = G_REPO.matcher(t);
        while (rm.find()) repos.add(rm.group(1));
        for (Pattern jp : new Pattern[]{G_JAVA1, G_JAVA2, G_JAVA3}) {
            Matcher jm = jp.matcher(t);
            if (jm.find()) { javaVersion = Integer.parseInt(jm.group(1)); break; }
        }
        Matcher vv = G_VERSION.matcher(t);
        if (vv.find()) version = vv.group(1);
        Matcher gg = G_GROUP.matcher(t);
        if (gg.find()) groupId = gg.group(1);
        shade = t.contains("shadow");
        gradleSubprojects = t.contains("subprojects") || t.contains("allprojects");
        Matcher rl = G_RELOC.matcher(t);
        while (rl.find()) relocations.add(new String[]{rl.group(1), rl.group(2)});
        File settings = new File(root, "settings.gradle");
        if (!settings.isFile()) settings = new File(root, "settings.gradle.kts");
        if (settings.isFile()) readSettings(settings);
        if (name != null) { vars.put("name", name); vars.put("project.name", name); vars.put("project.artifactId", name); }
        if (version != null) { vars.put("version", version); vars.put("project.version", version); }
        if (groupId != null) { vars.put("group", groupId); vars.put("project.groupId", groupId); }
        if (modules.isEmpty()) {
            log.log("Gradle project: " + (name == null ? "?" : name) + " (" + deps.size() + " dependencies"
                    + (shade ? ", shadow on" : "") + ")");
        }
    }

    private static String scopeOf(String cfg) {
        return cfg.equals("compileOnly") || cfg.equals("provided") ? "provided"
                : cfg.equals("runtimeOnly") ? "runtime" : "compile";
    }

    private static String read(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        }
    }
}
