package com.rwee.pluginbuilder;

import org.eclipse.jdt.core.compiler.batch.BatchCompiler;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Checks how faithful a recovered project is: recompiles it, then compares the result with the original JAR
 * (class set, member signatures, and a fingerprint of called methods and string constants per class).
 * It cannot prove identical behaviour, but it shows exactly where the two differ.
 */
final class Verifier {

    static final class Report {
        boolean compiled;                // compiled with zero errors
        int errorCount;
        final Map<String, Integer> errorsByFile = new TreeMap<>();
        final List<String> errorMessages = new ArrayList<>();
        int classesOriginal, classesRecovered, membersCompared;
        final List<String> missingClasses = new ArrayList<>();
        final List<String> extraClasses = new ArrayList<>();
        final List<String> memberDiffs = new ArrayList<>();
        final List<String> benignDiffs = new ArrayList<>();
        final List<String> behaviorDiffs = new ArrayList<>();
        int behaviorIdentical, behaviorDiffering;
        String confidence = "UNKNOWN";
        String summary = "";
        String text = "";
    }

    private static final int MASK = 0x1 | 0x2 | 0x4 | 0x8 | 0x10 | 0x20 | 0x40 | 0x80 | 0x100 | 0x400;
    private static final int CLASS_MASK = 0x1 | 0x10 | 0x200 | 0x400 | 0x2000 | 0x4000;
    private static final Pattern ECJ_HEAD = Pattern.compile("^\\s*\\d+\\.\\s+ERROR in (.+?\\.java)");
    private static final Pattern INIT = Pattern.compile("^method (\\d+) <init>\\((.*)\\)V$");
    private static final Pattern JAVAC = Pattern.compile("^(.+?\\.java):\\d+: error: (.*)$");
    private static final Pattern NOISE_OWNER = Pattern.compile(
            "java/lang/(StringBuilder|StringBuffer|AssertionError|NoSuchFieldError)|java/lang/invoke/(StringConcatFactory|LambdaMetafactory|ObjectMethods)");
    private static final Pattern NOISE_CALL = Pattern.compile(
            "java/lang/(Integer|Long|Double|Float|Short|Byte|Character|Boolean)\\.(valueOf|intValue|longValue|doubleValue|floatValue|shortValue|byteValue|charValue|booleanValue).*"
                    + "|java/lang/Enum\\.ordinal.*|java/lang/Object\\.getClass.*|java/util/Objects\\.requireNonNull.*"
                    + "|java/lang/Throwable\\.addSuppressed.*|java/lang/String\\.hashCode.*|java/lang/Class\\.desiredAssertionStatus.*"
                    + "|.*\\.(access\\$\\d+|\\$values|\\$deserializeLambda\\$).*|.*\\.lambda\\$.*");

    private Verifier() {}

    private static final class Info {
        String name;
        final Set<String> members = new TreeSet<>();
        final Set<String> calls = new TreeSet<>();
        final Set<String> strings = new TreeSet<>();
    }

    /**
     * ownClasses: internal names (a/b/C) of the classes that were recovered. classpath: jars to compile against
     * (the original JAR should be first so skipped library classes resolve). classLib: JDK class library.
     */
    static Report verify(File originalJar, Set<String> ownClasses, File projectDir, List<File> classpath,
                         File classLib, int javaLevel, BuildLog log) {
        Report rep = new Report();
        File src = new File(projectDir, "src/main/java");
        File outDir = new File(projectDir, ".verify-classes");
        Builder.deleteRecursive(outDir);
        outDir.mkdirs();
        try {
            // ---- 1. compile the recovered sources
            List<String> args = new ArrayList<>();
            int lvl = Math.max(8, Math.min(Builder.MAX_JAVA, javaLevel));
            args.add(lvl <= 8 ? "-1.8" : "-" + lvl);
            args.addAll(Arrays.asList("-encoding", "UTF-8", "-proc:none", "-nowarn", "-g", "-parameters",
                    "-proceedOnError", "-bootclasspath", classLib.getPath(), "-d", outDir.getPath()));
            StringBuilder cp = new StringBuilder();
            for (File f : classpath) { if (cp.length() > 0) cp.append(File.pathSeparator); cp.append(f.getPath()); }
            if (cp.length() > 0) { args.add("-classpath"); args.add(cp.toString()); }
            args.add(src.getPath());
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            boolean ok = BatchCompiler.compile(args.toArray(new String[0]), pw, pw, null);
            pw.flush();
            parseErrors(sw.toString(), projectDir, rep);
            rep.compiled = ok && rep.errorCount == 0;

            // ---- 2. read both sides
            Map<String, Info> orig = readJar(originalJar, ownClasses);
            Map<String, Info> rec = readDir(outDir, outDir);
            rep.classesOriginal = orig.size();
            rep.classesRecovered = rec.size();
            for (String n : orig.keySet()) if (!rec.containsKey(n)) rep.missingClasses.add(n);
            for (String n : rec.keySet()) if (!orig.containsKey(n) && !isGeneratedHelper(n)) rep.extraClasses.add(n);

            for (Map.Entry<String, Info> e : orig.entrySet()) {
                Info o = e.getValue(), r = rec.get(e.getKey());
                if (r == null) continue;
                rep.membersCompared += o.members.size();
                Set<String> miss = diff(o.members, r.members), extra = diff(r.members, o.members);
                String cn = e.getKey();
                if (cn.contains("$")) {
                    // Known harmless quirk: the decompiler lists the hidden outer-instance constructor parameter twice
                    String outer = cn.substring(0, cn.lastIndexOf('$'));
                    for (String m : new ArrayList<>(miss)) {
                        Matcher mm = INIT.matcher(m);
                        if (!mm.matches() || !mm.group(2).startsWith("L" + outer + ";")) continue;
                        String twin = "method " + mm.group(1) + " <init>(L" + outer + ";" + mm.group(2) + ")V";
                        if (extra.remove(twin)) {
                            miss.remove(m);
                            rep.benignDiffs.add(cn + ": constructor shows the hidden outer-instance parameter twice (decompiler quirk, harmless)");
                        }
                    }
                }
                for (String m : miss) rep.memberDiffs.add(cn + ": missing " + m);
                for (String m : extra) rep.memberDiffs.add(cn + ": changed/extra " + m);
                // behaviour fingerprint
                Set<String> cm = diff(o.calls, r.calls), ce = diff(r.calls, o.calls);
                Set<String> sm = diff(o.strings, r.strings), se = diff(r.strings, o.strings);
                if (cm.isEmpty() && ce.isEmpty() && sm.isEmpty() && se.isEmpty()) rep.behaviorIdentical++;
                else {
                    rep.behaviorDiffering++;
                    StringBuilder sb = new StringBuilder(e.getKey()).append(":");
                    if (!cm.isEmpty()) sb.append(" calls only in original ").append(cut(cm));
                    if (!ce.isEmpty()) sb.append(" calls only in recovered ").append(cut(ce));
                    if (!sm.isEmpty()) sb.append(" strings only in original ").append(cut(sm));
                    if (!se.isEmpty()) sb.append(" strings only in recovered ").append(cut(se));
                    rep.behaviorDiffs.add(sb.toString());
                }
            }
        } catch (Throwable t) {
            rep.text = "Verification could not run: " + t;
            rep.summary = "Verification could not run (" + t.getMessage() + ")";
            rep.confidence = "UNKNOWN";
            return rep;
        } finally {
            Builder.deleteRecursive(outDir);
        }
        finish(rep);
        return rep;
    }

    private static boolean isGeneratedHelper(String n) {
        return n.matches(".*\\$\\d+$");    // anonymous/switch-map helper classes are numbered differently per compiler
    }

    private static Set<String> diff(Set<String> a, Set<String> b) {
        Set<String> d = new TreeSet<>(a);
        d.removeAll(b);
        return d;
    }

    private static String cut(Set<String> s) {
        List<String> l = new ArrayList<>(s);
        String j = String.join(" | ", l.subList(0, Math.min(4, l.size())));
        return "[" + j + (l.size() > 4 ? " ... +" + (l.size() - 4) : "") + "]";
    }

    private static void parseErrors(String out, File projectDir, Report rep) {
        String base = projectDir.getPath();
        String[] blocks = out.split("-{10}");
        for (String b : blocks) {
            String[] lines = b.trim().split("\\n");
            for (String l : lines) {
                Matcher m = ECJ_HEAD.matcher(l);
                if (m.find()) {
                    String f = m.group(1).replace(base + "/src/main/java/", "");
                    String msg = lines[lines.length - 1].trim();
                    add(rep, f, msg);
                    break;
                }
                Matcher j = JAVAC.matcher(l.trim());
                if (j.find()) {
                    add(rep, j.group(1).replace(base + "/src/main/java/", ""), j.group(2));
                    break;
                }
            }
        }
    }

    private static void add(Report rep, String file, String msg) {
        rep.errorCount++;
        rep.errorsByFile.merge(file, 1, Integer::sum);
        if (rep.errorMessages.size() < 40) rep.errorMessages.add(file + ": " + msg);
    }

    // ------------------------------------------------------------------ class reading

    private static Map<String, Info> readJar(File jar, Set<String> own) throws IOException {
        Map<String, Info> m = new LinkedHashMap<>();
        try (ZipFile zf = new ZipFile(jar)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                String n = ze.getName();
                if (ze.isDirectory() || !n.endsWith(".class") || n.endsWith("module-info.class") || n.startsWith("META-INF/")) continue;
                String cn = n.substring(0, n.length() - 6);
                if (!own.contains(cn)) continue;
                try (InputStream in = zf.getInputStream(ze)) { Info i = read(readAll(in)); if (i != null) m.put(i.name, i); }
            }
        }
        return m;
    }

    private static Map<String, Info> readDir(File base, File dir) throws IOException {
        Map<String, Info> m = new LinkedHashMap<>();
        File[] fs = dir.listFiles();
        if (fs == null) return m;
        for (File f : fs) {
            if (f.isDirectory()) m.putAll(readDir(base, f));
            else if (f.getName().endsWith(".class")) {
                try (InputStream in = new java.io.FileInputStream(f)) { Info i = read(readAll(in)); if (i != null) m.put(i.name, i); }
            }
        }
        return m;
    }

    private static Info read(byte[] bytes) {
        try {
            final Info info = new Info();
            new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
                @Override
                public void visit(int version, int access, String name, String sig, String superName, String[] itf) {
                    info.name = name;
                    List<String> ifs = itf == null ? new ArrayList<String>() : new ArrayList<>(Arrays.asList(itf));
                    Collections.sort(ifs);
                    info.members.add("class " + (access & CLASS_MASK) + " extends " + superName + " implements " + ifs);
                }

                @Override
                public FieldVisitor visitField(int access, String name, String desc, String sig, Object value) {
                    if ((access & Opcodes.ACC_SYNTHETIC) == 0) info.members.add("field " + (access & MASK) + " " + name + " " + desc);
                    return null;
                }

                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] exc) {
                    boolean synth = (access & (Opcodes.ACC_SYNTHETIC | Opcodes.ACC_BRIDGE)) != 0
                            || name.startsWith("lambda$") || name.startsWith("access$") || name.equals("$values");
                    if (!synth && !name.equals("<clinit>")) info.members.add("method " + (access & MASK) + " " + name + desc);
                    return new MethodVisitor(Opcodes.ASM9) {
                        @Override
                        public void visitMethodInsn(int op, String owner, String n, String d, boolean itf) {
                            String key = owner + "." + n + d;
                            if (!NOISE_OWNER.matcher(owner).matches() && !NOISE_CALL.matcher(key).matches()) info.calls.add(key);
                        }

                        @Override
                        public void visitLdcInsn(Object v) {
                            if (v instanceof String && !((String) v).isEmpty()) info.strings.add((String) v);
                        }

                        @Override
                        public void visitInvokeDynamicInsn(String n, String d, Handle bsm, Object... bsmArgs) {
                            if (bsm.getOwner().equals("java/lang/invoke/StringConcatFactory") && bsmArgs.length > 0 && bsmArgs[0] instanceof String) {
                                for (String part : ((String) bsmArgs[0]).split("[\u0001\u0002]")) if (!part.isEmpty()) info.strings.add(part);
                            }
                        }
                    };
                }
            }, ClassReader.SKIP_FRAMES);
            return info.name == null ? null : info;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return b.toByteArray();
    }

    // ------------------------------------------------------------------ report

    private static void finish(Report r) {
        boolean clean = r.compiled && r.missingClasses.isEmpty() && r.memberDiffs.isEmpty();
        boolean missingMember = false;
        for (String d : r.memberDiffs) if (d.contains(": missing ")) { missingMember = true; break; }
        if (!r.compiled || !r.missingClasses.isEmpty() || missingMember) r.confidence = "LOW";
        else if (!clean || r.behaviorDiffering > 0) r.confidence = "MEDIUM";
        else r.confidence = "HIGH";

        StringBuilder s = new StringBuilder();
        s.append("VERIFICATION REPORT\n===================\n");
        s.append("Overall confidence: ").append(r.confidence).append("\n\n");
        s.append("1. Does the recovered code compile?\n   ");
        if (r.compiled) s.append("Yes, with zero errors.\n");
        else {
            s.append(r.errorCount).append(" error(s) in ").append(r.errorsByFile.size()).append(" file(s):\n");
            for (Map.Entry<String, Integer> e : r.errorsByFile.entrySet()) s.append("     ").append(e.getKey()).append("  (").append(e.getValue()).append(")\n");
            s.append("   First messages:\n");
            for (int i = 0; i < Math.min(15, r.errorMessages.size()); i++) s.append("     ").append(r.errorMessages.get(i)).append('\n');
        }
        s.append("\n2. Same classes? original ").append(r.classesOriginal).append(", recovered ").append(r.classesRecovered).append('\n');
        if (r.missingClasses.isEmpty() && r.extraClasses.isEmpty()) s.append("   Yes, same set of classes.\n");
        for (String c : r.missingClasses) s.append("   MISSING in recovered: ").append(c).append('\n');
        for (String c : r.extraClasses) s.append("   extra in recovered: ").append(c).append('\n');
        s.append("\n3. Same fields, methods and signatures? (").append(r.membersCompared).append(" compared)\n");
        if (r.memberDiffs.isEmpty()) s.append("   Yes, all match" + (r.benignDiffs.isEmpty() ? "" : " (apart from the harmless ones below)") + ".\n");
        else for (int i = 0; i < Math.min(60, r.memberDiffs.size()); i++) s.append("   ").append(r.memberDiffs.get(i)).append('\n');
        if (!r.benignDiffs.isEmpty()) {
            s.append("   Known harmless differences (").append(r.benignDiffs.size()).append("):\n");
            for (String b : r.benignDiffs) s.append("     ").append(b).append('\n');
        }
        if (r.memberDiffs.size() > 60) s.append("   ... ").append(r.memberDiffs.size() - 60).append(" more\n");
        s.append("\n4. Same behaviour fingerprint? (methods called and text used, per class)\n");
        s.append("   ").append(r.behaviorIdentical).append(" classes identical, ").append(r.behaviorDiffering).append(" differ.\n");
        for (int i = 0; i < Math.min(40, r.behaviorDiffs.size()); i++) s.append("   ").append(r.behaviorDiffs.get(i)).append('\n');
        s.append("\nWhat this does and does not prove\n---------------------------------\n")
                .append("A match means the structure and the calls line up. It is strong evidence, not a proof: the compiler may\n")
                .append("still have produced different logic inside a method. Comments and local variable names can never be\n")
                .append("recovered from a compiled JAR. Test the rebuilt plugin on a server before you rely on it.\n");
        r.text = s.toString();
        r.summary = "Confidence " + r.confidence + ": "
                + (r.compiled ? "compiles cleanly" : r.errorCount + " compile error(s) in " + r.errorsByFile.size() + " file(s)")
                + "; " + (r.missingClasses.isEmpty() ? "all classes present" : r.missingClasses.size() + " class(es) missing")
                + "; " + (r.memberDiffs.isEmpty() ? "all " + r.membersCompared + " members match" : r.memberDiffs.size() + " member difference(s)")
                + "; " + r.behaviorIdentical + "/" + (r.behaviorIdentical + r.behaviorDiffering) + " classes have an identical call fingerprint.";
    }
}
