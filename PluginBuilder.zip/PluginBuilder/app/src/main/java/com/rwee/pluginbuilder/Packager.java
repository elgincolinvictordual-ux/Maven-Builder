package com.rwee.pluginbuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Builds the final plugin JAR: classes + resources (+ shaded libraries, optionally relocated). */
final class Packager {
    private Packager() {}

    /** Returns the set of entry names written. classDirs: own classes first, then bundled module classes. */
    static Set<String> pack(File out, List<File> classDirs, List<File> resourceRoots, Map<String, String> vars,
                            List<File> libs, Relocator reloc) throws IOException {
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        Set<String> seen = new HashSet<>();
        Manifest mf = new Manifest();
        mf.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        mf.getMainAttributes().putValue("Created-By", "Plugin Builder");
        try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(out), mf)) {
            seen.add("META-INF/MANIFEST.MF");
            for (File c : classDirs) addTree(jos, c, "", seen, null, false, reloc);
            for (File r : resourceRoots) addTree(jos, r, "", seen, vars, true, reloc);
            for (File lib : libs) addLib(jos, lib, seen, reloc);
        }
        return seen;
    }

    private static void addTree(JarOutputStream jos, File dir, String prefix, Set<String> seen,
                                Map<String, String> vars, boolean isResource, Relocator reloc) throws IOException {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            String path = prefix + f.getName();
            if (f.isDirectory()) {
                addTree(jos, f, path + "/", seen, vars, isResource, reloc);
                continue;
            }
            if (isResource && f.getName().endsWith(".java")) continue;
            String name = reloc != null && !reloc.isEmpty() ? reloc.mapPath(path) : path;
            if (!seen.add(name)) continue;
            jos.putNextEntry(new JarEntry(name));
            if (isResource && vars != null && prefix.isEmpty()
                    && (path.equals("plugin.yml") || path.equals("paper-plugin.yml"))) {
                String txt = new String(readAll(f), StandardCharsets.UTF_8);
                for (Map.Entry<String, String> e : vars.entrySet()) {
                    if (e.getValue() != null) txt = txt.replace("${" + e.getKey() + "}", e.getValue());
                }
                jos.write(txt.getBytes(StandardCharsets.UTF_8));
            } else if (reloc != null && !reloc.isEmpty() && path.endsWith(".class")) {
                jos.write(reloc.rewrite(readAll(f)));
            } else {
                try (InputStream in = new FileInputStream(f)) { copy(in, jos); }
            }
            jos.closeEntry();
        }
    }

    private static void addLib(JarOutputStream jos, File lib, Set<String> seen, Relocator reloc) throws IOException {
        try (ZipFile zf = new ZipFile(lib)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                String n = ze.getName();
                if (ze.isDirectory() || skipLibEntry(n)) continue;
                String name = reloc != null && !reloc.isEmpty() ? reloc.mapPath(n) : n;
                if (!seen.add(name)) continue;
                jos.putNextEntry(new JarEntry(name));
                try (InputStream in = zf.getInputStream(ze)) {
                    if (reloc != null && !reloc.isEmpty() && n.endsWith(".class")) {
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        copy(in, bos);
                        jos.write(reloc.rewrite(bos.toByteArray()));
                    } else {
                        copy(in, jos);
                    }
                }
                jos.closeEntry();
            }
        }
    }

    private static boolean skipLibEntry(String n) {
        String u = n.toUpperCase();
        if (u.equals("META-INF/MANIFEST.MF")) return true;
        if (u.startsWith("META-INF/") && (u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC"))) return true;
        if (u.endsWith("MODULE-INFO.CLASS")) return true;
        return u.startsWith("META-INF/MAVEN/");
    }

    private static byte[] readAll(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            copy(in, bos);
            return bos.toByteArray();
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
