package com.rwee.pluginbuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Builds the final plugin JAR: classes + resources (+ shaded libraries). */
final class Packager {
    private Packager() {}

    /** Returns the set of entry names written. */
    static Set<String> pack(File out, File classesDir, List<File> resourceRoots,
                            Map<String, String> vars, List<File> libs) throws IOException {
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        Set<String> seen = new HashSet<>();
        Manifest mf = new Manifest();
        mf.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        mf.getMainAttributes().putValue("Created-By", "Plugin Builder");
        try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(out), mf)) {
            seen.add("META-INF/MANIFEST.MF");
            addTree(jos, classesDir, "", seen, null, false);
            for (File r : resourceRoots) addTree(jos, r, "", seen, vars, true);
            for (File lib : libs) addLib(jos, lib, seen);
        }
        return seen;
    }

    private static void addTree(JarOutputStream jos, File dir, String prefix, Set<String> seen,
                                Map<String, String> vars, boolean isResource) throws IOException {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            String name = prefix + f.getName();
            if (f.isDirectory()) {
                addTree(jos, f, name + "/", seen, vars, isResource);
                continue;
            }
            if (isResource && f.getName().endsWith(".java")) continue;
            if (!seen.add(name)) continue;
            jos.putNextEntry(new JarEntry(name));
            if (isResource && vars != null && prefix.isEmpty()
                    && (name.equals("plugin.yml") || name.equals("paper-plugin.yml"))) {
                String txt = new String(readAll(f), StandardCharsets.UTF_8);
                for (Map.Entry<String, String> e : vars.entrySet()) {
                    if (e.getValue() != null) txt = txt.replace("${" + e.getKey() + "}", e.getValue());
                }
                jos.write(txt.getBytes(StandardCharsets.UTF_8));
            } else {
                try (InputStream in = new FileInputStream(f)) { copy(in, jos); }
            }
            jos.closeEntry();
        }
    }

    private static void addLib(JarOutputStream jos, File lib, Set<String> seen) throws IOException {
        try (ZipFile zf = new ZipFile(lib)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                String n = ze.getName();
                if (ze.isDirectory() || skipLibEntry(n) || !seen.add(n)) continue;
                jos.putNextEntry(new JarEntry(n));
                try (InputStream in = zf.getInputStream(ze)) { copy(in, jos); }
                jos.closeEntry();
            }
        }
    }

    private static boolean skipLibEntry(String n) {
        String u = n.toUpperCase();
        if (u.equals("META-INF/MANIFEST.MF")) return true;
        if (u.startsWith("META-INF/") && (u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC"))) return true;
        if (u.endsWith("MODULE-INFO.CLASS")) return true;
        return u.startsWith("META-INF/MAVEN/");
    }

    private static byte[] readAll(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            copy(in, bos);
            return bos.toByteArray();
        }
    }

    private static void copy(InputStream in, java.io.OutputStream out) throws IOException {
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
