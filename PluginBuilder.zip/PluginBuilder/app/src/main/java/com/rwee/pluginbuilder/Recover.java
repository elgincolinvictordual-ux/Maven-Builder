package com.rwee.pluginbuilder;

import org.benf.cfr.reader.api.CfrDriver;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Turns a compiled plugin JAR back into a buildable Maven project: decompiles the plugin's own classes with CFR,
 * restores resources and plugin.yml, detects bundled libraries and generates a pom.xml.
 */
final class Recover {

    static final class Result {
        File projectDir;
        String name;
        int javaFiles, resourceFiles;
        List<String> libs = new ArrayList<>();
        List<String> skipped = new ArrayList<>();
        String verifySummary = "", confidence = "UNKNOWN";
    }

    private static final Set<String> SHADE_SEGMENTS = new HashSet<>(Arrays.asList(
            "libs", "lib", "libraries", "shaded", "shade", "relocated", "thirdparty", "third_party", "vendor",
            "dependencies", "deps", "repackaged"));

    private static final Map<String, String> API_TO_PAPER = new LinkedHashMap<>();
    static {
        API_TO_PAPER.put("1.13", "1.13.2"); API_TO_PAPER.put("1.14", "1.14.4"); API_TO_PAPER.put("1.15", "1.15.2");
        API_TO_PAPER.put("1.16", "1.16.5"); API_TO_PAPER.put("1.17", "1.17.1"); API_TO_PAPER.put("1.18", "1.18.2");
        API_TO_PAPER.put("1.19", "1.19.4"); API_TO_PAPER.put("1.20", "1.20.4"); API_TO_PAPER.put("1.21", "1.21.4");
    }

    private Recover() {}

    static Result run(File jar, File outRoot, boolean skipShaded, File m2, File classLib, BuildLog log) throws Exception {
        log.log("[1/5] Reading the JAR");
        List<String> classes = new ArrayList<>();
        String pluginYml = null, paperYml = null;
        Map<String, String> poms = new TreeMap<>();
        byte[] mainClassBytes = null;
        Map<String, byte[]> classBytesProbe = new HashMap<>();
        try (ZipFile zf = new ZipFile(jar)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                String n = ze.getName();
                if (ze.isDirectory()) continue;
                if (n.endsWith(".class") && !n.endsWith("module-info.class") && !n.startsWith("META-INF/")) {
                    classes.add(n.substring(0, n.length() - 6));
                } else if (n.equals("plugin.yml")) pluginYml = readText(zf, ze);
                else if (n.equals("paper-plugin.yml")) paperYml = readText(zf, ze);
                else if (n.startsWith("META-INF/maven/") && n.endsWith("pom.properties")) poms.put(n, readText(zf, ze));
            }
            String yml = pluginYml != null ? pluginYml : paperYml;
            String main = yml == null ? null : yml(yml, "main");
            if (main != null) {
                ZipEntry me = zf.getEntry(main.replace('.', '/') + ".class");
                if (me != null) mainClassBytes = readBytes(zf, me);
            }
        }
        if (classes.isEmpty()) throw new IOException("This JAR contains no classes.");
        String yml = pluginYml != null ? pluginYml : paperYml;
        if (yml == null) log.log("  Warning: no plugin.yml in the JAR, so name and version are guessed.");
        String name = yml == null ? null : yml(yml, "name");
        String version = yml == null ? null : yml(yml, "version");
        String main = yml == null ? null : yml(yml, "main");
        String apiVersion = yml == null ? null : yml(yml, "api-version");

        // ---- own package vs. bundled libraries
        String keep = ownPrefix(main, classes);
        Set<String> shadedRoots = new LinkedHashSet<>();
        Map<String, Integer> shadedCount = new TreeMap<>();
        int own = 0;
        for (String c : classes) {
            String pkg = pkgOf(c);
            String root = shadedRoot(pkg, keep);
            if (root == null) own++;
            else { shadedRoots.add(root); shadedCount.merge(root, 1, Integer::sum); }
        }
        final Set<String> ownSet = new HashSet<>();
        for (String c : classes) if (!skipShaded || shadedRoot(pkgOf(c), keep) == null) ownSet.add(c);
        log.log("  " + classes.size() + " classes: " + own + " yours, " + (classes.size() - own) + " look like bundled libraries");
        for (Map.Entry<String, Integer> e : shadedCount.entrySet()) log.log("    library package " + e.getKey() + " (" + e.getValue() + " classes)");

        if (name == null) name = new File(jar.getName()).getName().replaceAll("(?i)\\.jar$", "").replaceAll("[^A-Za-z0-9_-]", "_");
        String projName = name.replaceAll("[^A-Za-z0-9._-]", "_");
        File proj = new File(outRoot, projName);
        Builder.deleteRecursive(proj);
        File decomp = new File(proj, ".decompiled");
        File srcDir = new File(proj, "src/main/java");
        File resDir = new File(proj, "src/main/resources");
        srcDir.mkdirs();
        resDir.mkdirs();

        // ---- project metadata (own coordinates, libraries, Java level, Paper version)
        String group = keep != null ? keep : "com.example";
        String artifact = projName.toLowerCase();
        String ver = version != null ? version : "1.0";
        List<String[]> libs = new ArrayList<>();
        for (Map.Entry<String, String> e : poms.entrySet()) {
            Map<String, String> p = props(e.getValue());
            String g = p.get("groupId"), a = p.get("artifactId"), v = p.get("version");
            if (g == null || a == null) continue;
            boolean isOwn = (main != null && main.startsWith(g + ".")) || a.equalsIgnoreCase(projName)
                    || (name != null && a.equalsIgnoreCase(name));
            if (isOwn) { group = g; artifact = a; if (v != null && version == null) ver = v; }
            else if (v != null) libs.add(new String[]{g, a, v});
        }
        int major = mainClassBytes != null && mainClassBytes.length > 7
                ? ((mainClassBytes[6] & 0xff) << 8 | (mainClassBytes[7] & 0xff)) : 0;
        int java = major >= 52 ? Math.min(21, Math.max(8, major - 44)) : 17;
        String paper = paperVersion(apiVersion, java);
        boolean legacyGroup = paper.startsWith("1.1") && minorOf(paper) <= 16;

        // ---- give the decompiler real type information (Paper API, libraries, JDK) for better output
        List<String> extraCp = new ArrayList<>();
        List<File> apiJars = new ArrayList<>();
        if (m2 != null) {
            try {
                log.log("  Fetching Paper API " + paper + " so the decompiler can resolve types...");
                List<Pom.Dep> roots = new ArrayList<>();
                Pom.Dep pd = new Pom.Dep();
                pd.g = legacyGroup ? "com.destroystokyo.paper" : "io.papermc.paper"; pd.a = "paper-api"; pd.v = paper + "-R0.1-SNAPSHOT"; pd.scope = "provided";
                roots.add(pd);
                for (String[] l : libs) { Pom.Dep d = new Pom.Dep(); d.g = l[0]; d.a = l[1]; d.v = l[2]; d.scope = "compile"; roots.add(d); }
                MavenResolver res = new MavenResolver(m2, Builder.repoOverride != null ? Builder.repoOverride
                        : Arrays.asList(Builder.PAPER_REPO, Builder.CENTRAL), log);
                res.resolve(roots);
                for (File f : res.classpath()) { extraCp.add(f.getPath()); apiJars.add(f); }
            } catch (Exception e) {
                log.log("  (could not fetch the API jars, continuing without them)");
            }
        }
        if (classLib != null) extraCp.add(classLib.getPath());

        // ---- decompile
        log.log("[2/5] Decompiling (this can take a minute)");
        Map<String, String> opts = new HashMap<>();
        opts.put("outputdir", decomp.getPath());
        opts.put("showversion", "false");
        opts.put("silent", "true");
        opts.put("recovertypeclash", "true");
        opts.put("recovertypehints", "true");
        opts.put("renameillegalidents", "true");
        if (!extraCp.isEmpty()) opts.put("extraclasspath", String.join(File.pathSeparator, extraCp));
        if (skipShaded && keep != null) {
            StringBuilder re = new StringBuilder("^");
            if (!shadedRoots.isEmpty()) {
                re.append("(?!(?:");
                int i = 0;
                for (String r : shadedRoots) { if (i++ > 0) re.append('|'); re.append(Pattern.quote(r + ".")); }
                re.append("))");
            }
            re.append(Pattern.quote(keep + ".")).append(".*");
            opts.put("jarfilter", re.toString());
        }
        new CfrDriver.Builder().withOptions(opts).build().analyse(Collections.singletonList(jar.getPath()));

        Result r = new Result();
        r.projectDir = proj;
        r.name = projName;
        r.javaFiles = moveJava(decomp, decomp, srcDir);
        Builder.deleteRecursive(decomp);
        if (r.javaFiles == 0) throw new IOException("The decompiler produced no source files.");
        log.log("  " + r.javaFiles + " Java files recovered");

        // ---- resources
        log.log("[3/5] Restoring resources");
        List<String> shadedPaths = new ArrayList<>();
        for (String s : shadedRoots) shadedPaths.add(s.replace('.', '/') + "/");
        try (ZipFile zf = new ZipFile(jar)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                String n = ze.getName();
                if (ze.isDirectory() || n.endsWith(".class") || n.startsWith("META-INF/")) continue;
                boolean inLib = false;
                for (String sp : shadedPaths) if (n.startsWith(sp)) { inLib = true; break; }
                if (skipShaded && inLib) continue;
                File out = new File(resDir, n);
                if (!out.getCanonicalPath().startsWith(resDir.getCanonicalPath())) continue;   // zip-slip guard
                out.getParentFile().mkdirs();
                try (InputStream in = zf.getInputStream(ze); OutputStream os = new FileOutputStream(out)) { copy(in, os); }
                r.resourceFiles++;
            }
        }
        log.log("  " + r.resourceFiles + " resource files restored");

        // ---- pom.xml
        log.log("[4/5] Generating the project files");
        StringBuilder pom = new StringBuilder();
        pom.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<project xmlns=\"http://maven.apache.org/POM/4.0.0\">\n")
                .append("  <modelVersion>4.0.0</modelVersion>\n")
                .append("  <groupId>").append(group).append("</groupId>\n")
                .append("  <artifactId>").append(artifact).append("</artifactId>\n")
                .append("  <version>").append(ver).append("</version>\n")
                .append("  <packaging>jar</packaging>\n")
                .append("  <properties>\n    <maven.compiler.release>").append(java).append("</maven.compiler.release>\n")
                .append("    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>\n  </properties>\n")
                .append("  <repositories>\n    <repository>\n      <id>papermc</id>\n      <url>https://repo.papermc.io/repository/maven-public/</url>\n    </repository>\n  </repositories>\n")
                .append("  <dependencies>\n    <dependency>\n      <groupId>")
                .append(legacyGroup ? "com.destroystokyo.paper" : "io.papermc.paper").append("</groupId>\n      <artifactId>paper-api</artifactId>\n      <version>")
                .append(paper).append("-R0.1-SNAPSHOT</version>\n      <scope>provided</scope>\n    </dependency>\n");
        for (String[] l : libs) {
            pom.append("    <dependency>\n      <groupId>").append(l[0]).append("</groupId>\n      <artifactId>").append(l[1])
                    .append("</artifactId>\n      <version>").append(l[2]).append("</version>\n    </dependency>\n");
            r.libs.add(l[0] + ":" + l[1] + ":" + l[2]);
        }
        pom.append("  </dependencies>\n");
        if (!libs.isEmpty() || !shadedRoots.isEmpty()) {
            pom.append("  <build>\n    <plugins>\n      <plugin>\n        <artifactId>maven-shade-plugin</artifactId>\n        <version>3.5.1</version>\n")
                    .append("        <executions>\n          <execution>\n            <phase>package</phase>\n            <goals><goal>shade</goal></goals>\n")
                    .append("            <configuration>\n              <createDependencyReducedPom>false</createDependencyReducedPom>\n")
                    .append("              <!-- TODO: add <relocations> if the original build relocated its libraries -->\n")
                    .append("            </configuration>\n          </execution>\n        </executions>\n      </plugin>\n    </plugins>\n  </build>\n");
        }
        pom.append("</project>\n");
        write(new File(proj, "pom.xml"), pom.toString());

        StringBuilder notes = new StringBuilder();
        notes.append("RECOVERY NOTES\n==============\n")
                .append("Plugin: ").append(name).append(' ').append(version == null ? "" : version).append('\n')
                .append("Main class: ").append(main == null ? "(unknown)" : main).append('\n')
                .append("Compiled for Java ").append(java).append(", Paper API ").append(paper).append(" (a guess from api-version, change it in pom.xml if needed)\n\n")
                .append("Decompiled code is not identical to the original: comments, local variable names, some lambdas and\n")
                .append("switch statements are lost or rewritten, and a few methods may need manual fixes before it compiles.\n")
                .append("Search the sources for the word 'decompil' or 'unable' to find the spots the decompiler flagged.\n\n");
        if (skipShaded && !shadedRoots.isEmpty()) {
            notes.append("Bundled library packages that were skipped (not decompiled):\n");
            for (Map.Entry<String, Integer> e : shadedCount.entrySet()) notes.append("  ").append(e.getKey()).append("  (").append(e.getValue()).append(" classes)\n");
            notes.append("\nIf your code imports these packages, add the matching Maven dependency (and a relocation, if they were\nrelocated under your own package) in pom.xml.\n\n");
            r.skipped.addAll(shadedCount.keySet());
        }
        if (!libs.isEmpty()) {
            notes.append("Libraries found in the JAR's Maven metadata (added to pom.xml):\n");
            for (String l : r.libs) notes.append("  ").append(l).append('\n');
        }
        notes.append("\nSee VERIFY_REPORT.txt for how closely the recovered code matches the original JAR.\n");
        write(new File(proj, "RECOVERY_NOTES.txt"), notes.toString());

        // ---- verify: recompile and compare with the original
        File lib = classLib;
        if (lib == null && m2 != null) {
            File fallback = new File(m2.getParentFile(), "sdk/android.jar");
            if (fallback.isFile()) lib = fallback;
        }
        if (lib == null) {
            log.log("[5/5] Verification skipped (no Java class library available yet)");
            r.verifySummary = "Verification was skipped because no Java class library was available.";
        } else {
            log.log("[5/5] Verifying: recompiling the recovered code and comparing it with your JAR");
            List<File> cp = new ArrayList<>();
            cp.add(jar);
            cp.addAll(apiJars);
            Verifier.Report vr = Verifier.verify(jar, ownSet, proj, cp, lib, java, log);
            write(new File(proj, "VERIFY_REPORT.txt"), vr.text);
            r.verifySummary = vr.summary;
            r.confidence = vr.confidence;
            log.log("  " + vr.summary);
            int shown = 0;
            for (String m : vr.errorMessages) { if (shown++ >= 6) break; log.log("    error: " + m); }
            shown = 0;
            for (String m : vr.memberDiffs) { if (shown++ >= 6) break; log.log("    differs: " + m); }
        }
        return r;
    }

    /** Zips a recovered project, keeping every directory. */
    static void zip(File dir, File zip) throws IOException {
        try (java.util.zip.ZipOutputStream z = new java.util.zip.ZipOutputStream(new FileOutputStream(zip))) {
            addZip(z, dir, "");
        }
    }

    private static void addZip(java.util.zip.ZipOutputStream z, File dir, String prefix) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) { addZip(z, f, prefix + f.getName() + "/"); continue; }
            z.putNextEntry(new ZipEntry(prefix + f.getName()));
            try (InputStream in = new java.io.FileInputStream(f)) { copy(in, z); }
            z.closeEntry();
        }
    }

    // ------------------------------------------------------------------ helpers

    static String pkgOf(String internalName) {
        int i = internalName.lastIndexOf('/');
        return i < 0 ? "" : internalName.substring(0, i).replace('/', '.');
    }

    /** First two segments of the main class package (e.g. me.rwee), or the common package prefix of all classes. */
    static String ownPrefix(String main, List<String> classes) {
        if (main != null && main.contains(".")) {
            String[] p = main.substring(0, main.lastIndexOf('.')).split("\\.");
            return p.length >= 2 ? p[0] + "." + p[1] : p[0];
        }
        String[] common = null;
        for (String c : classes) {
            String pkg = pkgOf(c);
            if (pkg.isEmpty()) return null;
            String[] p = pkg.split("\\.");
            if (common == null) common = p;
            else {
                int k = 0;
                while (k < common.length && k < p.length && common[k].equals(p[k])) k++;
                common = Arrays.copyOf(common, k);
            }
        }
        if (common == null || common.length == 0) return null;
        return String.join(".", common);
    }

    /** Returns the library root package if pkg is bundled library code, else null. */
    static String shadedRoot(String pkg, String keep) {
        if (keep == null) return null;
        if (!(pkg.equals(keep) || pkg.startsWith(keep + "."))) {
            String[] p = pkg.split("\\.");
            return p.length <= 3 ? pkg : p[0] + "." + p[1] + "." + p[2];
        }
        String rest = pkg.length() > keep.length() ? pkg.substring(keep.length() + 1) : "";
        if (rest.isEmpty()) return null;
        String[] p = rest.split("\\.");
        for (int i = 0; i < p.length; i++) {
            if (SHADE_SEGMENTS.contains(p[i])) {
                StringBuilder sb = new StringBuilder(keep);
                for (int k = 0; k <= i; k++) sb.append('.').append(p[k]);
                return sb.toString();
            }
        }
        return null;
    }

    static String yml(String text, String key) {
        Matcher m = Pattern.compile("(?m)^" + Pattern.quote(key) + "\\s*:\\s*(.+?)\\s*$").matcher(text);
        if (!m.find()) return null;
        String v = m.group(1).trim();
        int hash = v.indexOf(" #");
        if (hash > 0) v = v.substring(0, hash).trim();
        if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith("\"") && v.endsWith("\"")))
            v = v.substring(1, Math.max(1, v.length() - 1));
        return v.isEmpty() ? null : v;
    }

    private static Map<String, String> props(String t) {
        Map<String, String> m = new HashMap<>();
        for (String line : t.split("\\r?\\n")) {
            int i = line.indexOf('=');
            if (i > 0 && !line.startsWith("#")) m.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
        }
        return m;
    }

    static String paperVersion(String apiVersion, int java) {
        if (apiVersion != null) {
            String v = apiVersion.trim();
            String mm = v.matches("\\d+\\.\\d+.*") ? v.replaceAll("^(\\d+\\.\\d+).*", "$1") : v;
            if (API_TO_PAPER.containsKey(mm)) return API_TO_PAPER.get(mm);
        }
        if (java >= 21) return "1.21.4";
        if (java >= 17) return "1.19.4";
        if (java >= 11) return "1.16.5";
        return "1.12.2";
    }

    private static int minorOf(String v) {
        try { return Integer.parseInt(v.split("\\.")[1]); } catch (Exception e) { return 99; }
    }

    private static int moveJava(File base, File dir, File dst) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return 0;
        int n = 0;
        for (File f : fs) {
            if (f.isDirectory()) n += moveJava(base, f, dst);
            else if (f.getName().endsWith(".java")) {
                String rel = base.toURI().relativize(f.toURI()).getPath();
                File out = new File(dst, rel);
                out.getParentFile().mkdirs();
                Files.copy(f.toPath(), out.toPath());
                n++;
            }
        }
        return n;
    }

    private static String readText(ZipFile zf, ZipEntry ze) throws IOException {
        return new String(readBytes(zf, ze), StandardCharsets.UTF_8);
    }

    private static byte[] readBytes(ZipFile zf, ZipEntry ze) throws IOException {
        try (InputStream in = zf.getInputStream(ze)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            copy(in, b);
            return b.toByteArray();
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    private static void write(File f, String s) throws IOException {
        Files.write(f.toPath(), s.getBytes(StandardCharsets.UTF_8));
    }
}
