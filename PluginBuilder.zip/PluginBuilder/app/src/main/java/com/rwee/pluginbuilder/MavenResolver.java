package com.rwee.pluginbuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Small Maven dependency resolver: downloads POMs and JARs (with transitive compile-scope
 * dependencies) from a list of repositories into a local cache.
 */
final class MavenResolver {

    static final class Resolved {
        final String key;
        File jar;
        boolean bundle, classpath;
        Resolved(String key) { this.key = key; }
    }

    private static final class Item {
        Pom.Dep dep;
        boolean bundle, classpath;
        Set<String> excl = new HashSet<>();
    }

    private final File cache;
    private final List<String> repos = new ArrayList<>();
    private final BuildLog log;
    private final Map<String, Resolved> result = new LinkedHashMap<>();
    private final Map<String, Pom> pomCache = new HashMap<>();

    MavenResolver(File cache, List<String> repoUrls, BuildLog log) {
        this.cache = cache;
        this.log = log;
        for (String r : repoUrls) addRepo(r);
    }

    private void addRepo(String r) {
        if (r == null || !r.startsWith("http")) return;
        if (!r.endsWith("/")) r += "/";
        if (!repos.contains(r)) repos.add(r);
    }

    /** Roots must already carry their effective version and scope. */
    void resolve(List<Pom.Dep> roots) {
        ArrayDeque<Item> q = new ArrayDeque<>();
        for (Pom.Dep d : roots) {
            String sc = d.scope == null ? "compile" : d.scope;
            if (sc.equals("test")) continue;
            Item it = new Item();
            it.dep = d;
            it.bundle = !(sc.equals("provided") || sc.equals("system"));
            it.classpath = !sc.equals("runtime");
            q.add(it);
        }
        while (!q.isEmpty()) {
            Item it = q.poll();
            Pom.Dep d = it.dep;
            if (isExcluded(it.excl, d)) continue;
            Resolved ex = result.get(d.key());
            if (ex != null) {
                ex.bundle |= it.bundle;
                ex.classpath |= it.classpath;
                continue;
            }
            String ver = cleanVersion(d.v);
            if (ver == null || ver.contains("${")) {
                log.log("  skipped " + d.key() + " (no usable version)");
                continue;
            }
            Pom pom = loadPom(d.g, d.a, ver);
            Resolved r = new Resolved(d.key());
            r.bundle = it.bundle;
            r.classpath = it.classpath;
            boolean pomOnly = "pom".equals(d.type) || (pom != null && "pom".equals(pom.packaging));
            if (!pomOnly) {
                String fv = snapshotVersion(d.g, d.a, ver);
                r.jar = fetch(d.g, d.a, ver, fv, d.classifier, "jar", true);
                if (r.jar == null) log.log("  FAILED to download " + d.g + ":" + d.a + ":" + ver);
            }
            result.put(d.key(), r);
            if (pom == null) {
                if (r.jar == null) log.log("  could not resolve " + d.key() + ":" + ver);
                continue;
            }
            Set<String> ex2 = new HashSet<>(it.excl);
            ex2.addAll(d.excl);
            for (Pom.Dep c : pom.deps) {
                Pom.Dep ce = pom.effective(c);
                String sc = ce.scope == null ? "compile" : ce.scope;
                if (!sc.equals("compile") || ce.optional) continue;
                if ("test-jar".equals(ce.type)) continue;
                Item ci = new Item();
                ci.dep = ce;
                ci.bundle = it.bundle;
                ci.classpath = it.classpath;
                ci.excl = ex2;
                q.add(ci);
            }
        }
    }

    List<File> classpath() {
        List<File> l = new ArrayList<>();
        for (Resolved r : result.values()) if (r.jar != null && r.classpath) l.add(r.jar);
        return l;
    }

    List<File> bundled() {
        List<File> l = new ArrayList<>();
        for (Resolved r : result.values()) if (r.jar != null && r.bundle) l.add(r.jar);
        return l;
    }

    int count() { return result.size(); }

    // ------------------------------------------------------------------

    private static boolean isExcluded(Set<String> ex, Pom.Dep d) {
        return ex.contains(d.key()) || ex.contains(d.g + ":*") || ex.contains("*:*");
    }

    static String cleanVersion(String v) {
        if (v == null) return null;
        v = v.trim();
        if (v.startsWith("[") || v.startsWith("(")) {
            v = v.substring(1, v.length() - 1);
            String[] parts = v.split(",");
            v = parts[0].trim().isEmpty() && parts.length > 1 ? parts[1].trim() : parts[0].trim();
        }
        return v.isEmpty() ? null : v;
    }

    private Pom loadPom(String g, String a, String ver) {
        String k = g + ":" + a + ":" + ver;
        if (pomCache.containsKey(k)) return pomCache.get(k);
        pomCache.put(k, null); // recursion guard
        Pom p = null;
        File f = fetch(g, a, ver, snapshotVersion(g, a, ver), null, "pom", false);
        if (f != null) {
            try {
                p = Pom.parse(f, pr -> {
                    if (pr[0] == null || pr[1] == null || pr[2] == null) return null;
                    return loadPom(pr[0], pr[1], cleanVersion(pr[2]));
                });
            } catch (Exception e) {
                log.log("  warning: could not parse POM of " + k);
            }
        }
        pomCache.put(k, p);
        if (p != null) for (String r : p.repos) addRepo(r);
        return p;
    }

    private File fetch(String g, String a, String ver, String fileVer, String classifier, String ext, boolean announce) {
        String rel = g.replace('.', '/') + "/" + a + "/" + ver + "/" + a + "-" + fileVer
                + (classifier != null && !classifier.isEmpty() ? "-" + classifier : "") + "." + ext;
        File f = new File(cache, rel);
        if (f.isFile() && f.length() > 0) return f;
        if (announce) log.log("  downloading " + a + "-" + fileVer + ".jar");
        for (String r : new ArrayList<>(repos)) {
            if (Net.download(r + rel, f, null)) return f;
        }
        return null;
    }

    /** Turns X-SNAPSHOT into the timestamped file version using maven-metadata.xml. */
    private String snapshotVersion(String g, String a, String ver) {
        if (!ver.endsWith("-SNAPSHOT")) return ver;
        String rel = g.replace('.', '/') + "/" + a + "/" + ver + "/maven-metadata.xml";
        File meta = new File(cache, rel);
        for (String r : new ArrayList<>(repos)) {
            File tmp = new File(meta.getPath() + ".new");
            if (Net.download(r + rel, tmp, null)) {
                meta.delete();
                tmp.renameTo(meta);
                break;
            }
        }
        if (!meta.isFile()) return ver;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            Document doc = dbf.newDocumentBuilder().parse(meta);
            if (doc.getElementsByTagName("snapshot").getLength() > 0) {
                Element snap = (Element) doc.getElementsByTagName("snapshot").item(0);
                String ts = Pom.text(snap, "timestamp"), bn = Pom.text(snap, "buildNumber");
                if (ts != null && bn != null) {
                    return ver.substring(0, ver.length() - "SNAPSHOT".length()) + ts + "-" + bn;
                }
            }
        } catch (Exception ignored) { }
        return ver;
    }
}
