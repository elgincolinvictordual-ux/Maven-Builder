package com.rwee.pluginbuilder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_TREE = 1;
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            ".git", "target", "build", ".gradle", ".idea", "out", "node_modules", ".vscode", ".github"));

    private SharedPreferences prefs;
    private Uri treeUri;
    private TextView folderView, logView;
    private EditText paperEt, javaEt, depsEt, reposEt;
    private Button chooseBtn, pickBtn, buildBtn, shareBtn, cacheBtn;
    private ProgressBar bar;
    private ScrollView scroll;
    private Uri lastJar;
    private final StringBuilder logBuf = new StringBuilder();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("pb", MODE_PRIVATE);
        buildUi();
        String t = prefs.getString("tree", null);
        if (t != null) {
            treeUri = Uri.parse(t);
            DocumentFile d = DocumentFile.fromTreeUri(this, treeUri);
            folderView.setText(d != null && d.canRead() ? "Folder: " + d.getName() : "No folder selected");
            if (d == null || !d.canRead()) treeUri = null;
        }
        paperEt.setText(prefs.getString("paper", ""));
        javaEt.setText(prefs.getString("java", ""));
        depsEt.setText(prefs.getString("deps", ""));
        reposEt.setText(prefs.getString("repos", ""));
    }

    // ------------------------------------------------------------ UI

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private EditText field(String hint, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(14);
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
            e.setMinLines(2);
            e.setGravity(android.view.Gravity.TOP);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            e.setSingleLine(true);
        }
        return e;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setPadding(0, dp(14), 0, 0);
        return t;
    }

    private void buildUi() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(24));

        TextView title = new TextView(this);
        title.setText("Plugin Builder");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Compile Java Minecraft plugins on your phone.");
        sub.setTextSize(13);
        col.addView(sub);

        col.addView(label("Project folder"));
        chooseBtn = new Button(this);
        chooseBtn.setText("Choose project folder");
        chooseBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_TREE);
        });
        col.addView(chooseBtn);
        folderView = new TextView(this);
        folderView.setText("No folder selected");
        folderView.setTextSize(13);
        col.addView(folderView);

        col.addView(label("Paper API version (blank = use the project's own, or a default)"));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        paperEt = field("e.g. 1.21.4-R0.1-SNAPSHOT", false);
        row.addView(paperEt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        pickBtn = new Button(this);
        pickBtn.setText("Pick");
        pickBtn.setOnClickListener(v -> pickPaperVersion());
        row.addView(pickBtn);
        col.addView(row);

        col.addView(label("Java version (blank = auto)"));
        javaEt = field("e.g. 17 or 21", false);
        javaEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        col.addView(javaEt);

        col.addView(label("Extra dependencies, one per line: group:artifact:version  (start with + to bundle into the jar)"));
        depsEt = field("com.zaxxer:HikariCP:5.1.0", true);
        col.addView(depsEt);

        col.addView(label("Extra repositories, one URL per line"));
        reposEt = field("https://jitpack.io", true);
        col.addView(reposEt);

        buildBtn = new Button(this);
        buildBtn.setText("BUILD");
        buildBtn.setTextSize(18);
        buildBtn.setOnClickListener(v -> startBuild());
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64));
        blp.topMargin = dp(18);
        col.addView(buildBtn, blp);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setVisibility(View.GONE);
        col.addView(bar);

        shareBtn = new Button(this);
        shareBtn.setText("Share / open built JAR");
        shareBtn.setVisibility(View.GONE);
        shareBtn.setOnClickListener(v -> shareJar());
        col.addView(shareBtn);

        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(11);
        logView.setTextIsSelectable(true);
        logView.setPadding(0, dp(12), 0, 0);
        col.addView(logView);

        cacheBtn = new Button(this);
        cacheBtn.setText("Clear downloaded libraries");
        cacheBtn.setTextSize(12);
        cacheBtn.setOnClickListener(v -> {
            Builder.deleteRecursive(new File(getFilesDir(), "work/m2"));
            Toast.makeText(this, "Library cache cleared", Toast.LENGTH_SHORT).show();
        });
        col.addView(cacheBtn);

        scroll = new ScrollView(this);
        scroll.addView(col);
        scroll.setFillViewport(true);
        setContentView(scroll);
    }

    // ------------------------------------------------------------ actions

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_TREE && res == RESULT_OK && data != null && data.getData() != null) {
            treeUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            DocumentFile d = DocumentFile.fromTreeUri(this, treeUri);
            folderView.setText("Folder: " + (d != null ? d.getName() : treeUri.getLastPathSegment()));
            prefs.edit().putString("tree", treeUri.toString()).apply();
        }
    }

    private void pickPaperVersion() {
        Toast.makeText(this, "Fetching Paper versions...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String xml = Net.text(Builder.PAPER_REPO + "io/papermc/paper/paper-api/maven-metadata.xml");
            List<String> vs = new ArrayList<>();
            if (xml != null) {
                Matcher m = Pattern.compile("<version>([^<]+)</version>").matcher(xml);
                while (m.find()) vs.add(m.group(1));
            }
            Collections.reverse(vs);
            final List<String> shown = vs.size() > 40 ? vs.subList(0, 40) : vs;
            runOnUiThread(() -> {
                if (shown.isEmpty()) {
                    Toast.makeText(this, "Could not fetch versions. Check your internet.", Toast.LENGTH_LONG).show();
                    return;
                }
                new AlertDialog.Builder(this)
                        .setTitle("Paper API version")
                        .setItems(shown.toArray(new String[0]), (d, which) -> paperEt.setText(shown.get(which)))
                        .show();
            });
        }).start();
    }

    private void startBuild() {
        if (treeUri == null) {
            Toast.makeText(this, "Choose a project folder first", Toast.LENGTH_SHORT).show();
            return;
        }
        final Builder.Options o = new Builder.Options();
        o.paperVersion = paperEt.getText().toString().trim();
        try { o.javaVersion = Integer.parseInt(javaEt.getText().toString().trim()); } catch (NumberFormatException e) { o.javaVersion = 0; }
        o.extraDeps = depsEt.getText().toString();
        o.extraRepos = reposEt.getText().toString();
        prefs.edit().putString("paper", o.paperVersion).putString("java", javaEt.getText().toString().trim())
                .putString("deps", o.extraDeps).putString("repos", o.extraRepos).apply();

        setBusy(true);
        logBuf.setLength(0);
        logView.setText("");
        final Uri uri = treeUri;
        new Thread(null, () -> {
            try {
                File work = new File(getFilesDir(), "work");
                File proj = new File(work, "project");
                Builder.deleteRecursive(proj);
                proj.mkdirs();
                log("Copying project from storage...");
                DocumentFile tree = DocumentFile.fromTreeUri(this, uri);
                if (tree == null) throw new IOException("Cannot open the selected folder. Pick it again.");
                copyTree(tree, proj);
                File jar = new Builder(work, this::log).build(proj, o);
                Uri saved = saveToDownloads(jar);
                lastJar = saved;
                log("\nDONE: Downloads/PluginBuilder/" + jar.getName());
                runOnUiThread(() -> shareBtn.setVisibility(View.VISIBLE));
            } catch (Throwable t) {
                log("\nBUILD FAILED: " + t.getMessage());
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        }, "builder", 128L * 1024 * 1024).start();
    }

    private void setBusy(boolean busy) {
        buildBtn.setEnabled(!busy);
        chooseBtn.setEnabled(!busy);
        bar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (busy) shareBtn.setVisibility(View.GONE);
    }

    private void log(String s) {
        runOnUiThread(() -> {
            logBuf.append(s).append('\n');
            logView.setText(logBuf);
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    private void shareJar() {
        if (lastJar == null) return;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/java-archive");
        i.putExtra(Intent.EXTRA_STREAM, lastJar);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share plugin JAR"));
    }

    // ------------------------------------------------------------ storage

    private void copyTree(DocumentFile dir, File dest) throws IOException {
        ContentResolver cr = getContentResolver();
        DocumentFile[] list = dir.listFiles();
        for (DocumentFile f : list) {
            String n = f.getName();
            if (n == null) continue;
            if (f.isDirectory()) {
                if (SKIP.contains(n)) continue;
                File d = new File(dest, n);
                d.mkdirs();
                copyTree(f, d);
            } else {
                if (f.length() > 100L * 1024 * 1024) continue;
                try (InputStream in = cr.openInputStream(f.getUri());
                     OutputStream out = new FileOutputStream(new File(dest, n))) {
                    if (in == null) continue;
                    byte[] buf = new byte[65536];
                    int c;
                    while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
                }
            }
        }
    }

    private Uri saveToDownloads(File jar) throws IOException {
        ContentResolver cr = getContentResolver();
        String rel = Environment.DIRECTORY_DOWNLOADS + "/PluginBuilder/";
        try {
            cr.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    new String[]{jar.getName(), rel});
        } catch (Exception ignored) { }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME, jar.getName());
        cv.put(MediaStore.Downloads.MIME_TYPE, "application/java-archive");
        cv.put(MediaStore.Downloads.RELATIVE_PATH, rel);
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new IOException("Could not create the file in Downloads.");
        try (OutputStream out = cr.openOutputStream(uri); InputStream in = new FileInputStream(jar)) {
            if (out == null) throw new IOException("Could not write to Downloads.");
            byte[] buf = new byte[65536];
            int c;
            while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
        }
        return uri;
    }
}
