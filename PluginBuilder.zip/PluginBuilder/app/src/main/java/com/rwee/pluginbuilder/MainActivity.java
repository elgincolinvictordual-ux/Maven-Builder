package com.rwee.pluginbuilder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_TREE = 1;
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            ".git", "target", "build", ".gradle", ".idea", "out", "node_modules", ".vscode", ".github"));

    // palette (Morphe-like: deep blue to teal glass on a dark mesh)
    private static final int TEAL = 0xFF14B8A6, TEAL_L = 0xFF2DD4BF, WHITE = 0xFFFFFFFF, MUTED = 0xFFA9BAD3,
            SOFT = 0xFFC5D2E8, DANGER = 0xFFF87171, WARN = 0xFFFBBF24, OKGREEN = 0xFF4ADE80,
            CARD_A = 0xE60C3157, CARD_B = 0xE60B6B73, DIM_A = 0x990C3157, DIM_B = 0x990B6B73,
            BANNER_A = 0xE60B2A55, BANNER_B = 0xE6103C6B, INPUT_BG = 0xB3070E1A, STROKE = 0x6614B8A6;

    private static final class Row {
        LinearLayout view;
        TextView title, sub;
        IconView icon;
        View trail;
    }

    private SharedPreferences prefs;
    private Uri treeUri;
    private boolean cloudMode = true;
    private final List<Uri> savedUris = new ArrayList<>();

    private MeshBackgroundView mesh;
    private final ScrollView[] pages = new ScrollView[3];
    private final LinearLayout[] navItems = new LinearLayout[3];
    private final IconView[] navIcons = new IconView[3];
    private final TextView[] navLabels = new TextView[3];
    private int curPage = 0;

    private Row projectRow, cloudRow, phoneRow, banner;
    private TextView statusView, cloudStatus, resultText, logView, buildBtn, testBtn, pickBtn, shareBtn;
    private EditText tokenEt, repoEt, paperEt, javaEt, depsEt, reposEt;
    private ProgressBar bar;
    private LinearLayout consoleCard, resultCard;
    private final SpannableStringBuilder logBuf = new SpannableStringBuilder();

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("pb", MODE_PRIVATE);
        getWindow().setStatusBarColor(0xFF030812);
        getWindow().setNavigationBarColor(0xFF02060C);
        buildUi();
        String t = prefs.getString("tree", null);
        if (t != null) {
            Uri u = Uri.parse(t);
            DocumentFile d = DocumentFile.fromTreeUri(this, u);
            if (d != null && d.canRead()) {
                treeUri = u;
                setProjectName(d.getName());
            }
        }
        tokenEt.setText(prefs.getString("gh_token", ""));
        repoEt.setText(prefs.getString("gh_repo", ""));
        paperEt.setText(prefs.getString("paper", ""));
        javaEt.setText(prefs.getString("java", ""));
        depsEt.setText(prefs.getString("deps", ""));
        reposEt.setText(prefs.getString("repos", ""));
        selectMode(prefs.getBoolean("cloud", true));
        updateCloudStatus();
        showPage(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mesh.startSensors();
    }

    @Override
    protected void onPause() {
        mesh.stopSensors();
        super.onPause();
    }

    // ------------------------------------------------------------ UI helpers

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable grad(int c1, int c2, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(strokeDp)), stroke);
        return g;
    }

    private GradientDrawable solid(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private RippleDrawable ripple(GradientDrawable content, float radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, solid(WHITE, radiusDp, 0));
    }

    private LinearLayout.LayoutParams lp(int w, int h, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText input(String hint, boolean multi, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF7F92B0);
        e.setTextColor(WHITE);
        e.setTextSize(15);
        e.setBackground(solid(INPUT_BG, 16, STROKE));
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
            e.setMinLines(2);
            e.setGravity(Gravity.TOP);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            e.setSingleLine(true);
        }
        if (password) e.setTransformationMethod(PasswordTransformationMethod.getInstance());
        return e;
    }

    /** Pill-shaped button. primary = blue-to-teal gradient, otherwise glass. */
    private TextView pillBtn(String label, boolean primary, float heightDp) {
        TextView b = text(label, 16, WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setClickable(true);
        b.setPadding(dp(18), 0, dp(18), 0);
        GradientDrawable g = primary
                ? grad(0xFF2563EB, 0xFF14B8A6, heightDp / 2, 0, 0)
                : grad(0xCC12294A, 0xCC0E4A55, heightDp / 2, STROKE, 1);
        b.setBackground(ripple(g, heightDp / 2));
        return b;
    }

    private LinearLayout pill(String label, String count, int tint, int stroke) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.HORIZONTAL);
        p.setGravity(Gravity.CENTER_VERTICAL);
        p.setPadding(dp(14), dp(12), dp(14), dp(12));
        p.setBackground(solid(tint, 24, stroke));
        View dot = new View(this);
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF2563EB, 0xFF2DD4BF});
        d.setShape(GradientDrawable.OVAL);
        dot.setBackground(d);
        p.addView(dot, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView l = text(label, 17, WHITE, true);
        LinearLayout.LayoutParams lpL = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpL.leftMargin = dp(12);
        p.addView(l, lpL);
        TextView c = text(count, 15, MUTED, false);
        LinearLayout.LayoutParams lpC = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpC.leftMargin = dp(12);
        p.addView(c, lpC);
        return p;
    }

    /** Big gradient list card: icon circle, title, subtitle, optional trailing chevron/radio. trail: 0 none, 1 chevron, 2 radio. */
    private Row row(IconView.Type icon, String title, String sub, int trail) {
        Row r = new Row();
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(16), dp(18), dp(18), dp(18));
        v.setClickable(true);
        r.view = v;

        FrameLayout wrap = new FrameLayout(this);
        wrap.setBackground(solid(0x66000000, 20, 0x33FFFFFF));
        r.icon = new IconView(this, icon);
        r.icon.setBoxScale(0.52f);
        wrap.addView(r.icon, new FrameLayout.LayoutParams(dp(60), dp(60)));
        v.addView(wrap, new LinearLayout.LayoutParams(dp(60), dp(60)));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        r.title = text(title, 22, WHITE, true);
        r.sub = text(sub, 15, SOFT, false);
        tx.addView(r.title);
        tx.addView(r.sub, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 2));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tl.leftMargin = dp(16);
        v.addView(tx, tl);

        if (trail == 1) {
            IconView ch = new IconView(this, IconView.Type.CHEVRON);
            ch.setColor(0xCCFFFFFF);
            r.trail = ch;
            v.addView(ch, new LinearLayout.LayoutParams(dp(30), dp(30)));
        } else if (trail == 2) {
            r.trail = new View(this);
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(dp(24), dp(24));
            v.addView(r.trail, rl);
        }
        styleRow(r, true, false);
        return r;
    }

    private void styleRow(Row r, boolean bright, boolean selected) {
        GradientDrawable g = grad(bright ? CARD_A : DIM_A, bright ? CARD_B : DIM_B, 28,
                selected ? TEAL_L : STROKE, selected ? 2 : 1);
        r.view.setBackground(ripple(g, 28));
    }

    private void styleBanner(Row r) {
        r.view.setBackground(ripple(grad(BANNER_A, BANNER_B, 26, 0x5560A5FA, 1), 26));
        r.view.setPadding(dp(16), dp(14), dp(14), dp(14));
    }

    private void setRadio(View v, boolean on) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        if (on) { d.setColor(TEAL_L); d.setStroke(dp(3), 0xFFB5F5EC); }
        else { d.setColor(0x00000000); d.setStroke(dp(2), 0x88FFFFFF); }
        v.setBackground(d);
    }

    private TextView title(String s) {
        TextView t = text(s, 30, WHITE, true);
        return t;
    }

    private ScrollView page(LinearLayout content) {
        ScrollView s = new ScrollView(this);
        s.setBackgroundColor(0);
        s.setVerticalScrollBarEnabled(false);
        s.setOverScrollMode(View.OVER_SCROLL_NEVER);
        s.setFillViewport(true);
        content.setPadding(dp(16), dp(14), dp(16), dp(120));
        s.addView(content);
        return s;
    }

    private FrameLayout circleBtn(IconView.Type t, boolean accent) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable g = solid(accent ? 0xFF0E3A66 : 0x99182236, 26, accent ? 0xFF2D6CB5 : 0x33FFFFFF);
        g.setShape(GradientDrawable.OVAL);
        f.setBackground(g);
        f.setClickable(true);
        IconView i = new IconView(this, t);
        i.setBoxScale(0.5f);
        f.addView(i, new FrameLayout.LayoutParams(dp(54), dp(54)));
        return f;
    }

    private LinearLayout navItem(IconView.Type t, String label, final int idx) {
        LinearLayout n = new LinearLayout(this);
        n.setOrientation(LinearLayout.VERTICAL);
        n.setGravity(Gravity.CENTER);
        n.setClickable(true);
        IconView i = new IconView(this, t);
        i.setBoxScale(0.62f);
        n.addView(i, new LinearLayout.LayoutParams(dp(34), dp(34)));
        TextView l = text(label, 13, MUTED, true);
        n.addView(l);
        navIcons[idx] = i;
        navLabels[idx] = l;
        navItems[idx] = n;
        n.setOnClickListener(v -> showPage(idx));
        return n;
    }

    private void buildUi() {
        final int W = ViewGroup.LayoutParams.MATCH_PARENT, H = ViewGroup.LayoutParams.WRAP_CONTENT;
        FrameLayout root = new FrameLayout(this);
        mesh = new MeshBackgroundView(this);
        root.addView(mesh, new FrameLayout.LayoutParams(W, W));

        // ---------------- page 0: build
        LinearLayout build = new LinearLayout(this);
        build.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout logo = new LinearLayout(this);
        logo.setOrientation(LinearLayout.HORIZONTAL);
        logo.setGravity(Gravity.CENTER_VERTICAL);
        TextView p1 = text("P", 38, WHITE, true);
        p1.getPaint().setShader(new LinearGradient(0, 0, dp(26), dp(46), new int[]{0xFF3B82F6, 0xFF2DD4BF, 0xFF4ADE80}, null, Shader.TileMode.CLAMP));
        TextView p2 = text("lugin Builder", 30, WHITE, false);
        p2.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        logo.addView(p1);
        logo.addView(p2);
        head.addView(logo, new LinearLayout.LayoutParams(0, H, 1f));
        FrameLayout folderBtn = circleBtn(IconView.Type.FOLDER, true);
        folderBtn.setOnClickListener(v -> pickFolder());
        head.addView(folderBtn, new LinearLayout.LayoutParams(dp(54), dp(54)));
        FrameLayout logBtn = circleBtn(IconView.Type.LIST, false);
        logBtn.setOnClickListener(v -> {
            if (logBuf.length() == 0) { Toast.makeText(this, "No output yet", Toast.LENGTH_SHORT).show(); return; }
            consoleCard.setVisibility(consoleCard.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(dp(54), dp(54));
        ll.leftMargin = dp(10);
        head.addView(logBtn, ll);
        build.addView(head, lp(W, H, 4));

        banner = row(IconView.Type.CLOUD, "Set up cloud builds", "", 1);
        styleBanner(banner);
        banner.title.setTextSize(18);
        banner.sub.setTextSize(14);
        banner.view.setOnClickListener(v -> showPage(1));
        build.addView(banner.view, lp(W, H, 22));

        TextView headline = text("Today's forecast: 100% chance of building", 30, WHITE, true);
        headline.setGravity(Gravity.CENTER);
        build.addView(headline, lp(W, H, 26));

        build.addView(pill("Project", "your plugin folder", 0x33135E63, 0x8814B8A6), lp(W, H, 22));
        projectRow = row(IconView.Type.FOLDER, "Choose project folder", "Tap to pick the folder with your plugin", 1);
        projectRow.view.setOnClickListener(v -> pickFolder());
        build.addView(projectRow.view, lp(W, H, 10));

        build.addView(pill("Build mode", "2 options", 0x33325E1F, 0x884ADE80), lp(W, H, 16));
        cloudRow = row(IconView.Type.CLOUD, "Cloud", "Real Maven/Gradle on your GitHub", 2);
        cloudRow.view.setOnClickListener(v -> selectMode(true));
        build.addView(cloudRow.view, lp(W, H, 10));
        phoneRow = row(IconView.Type.PHONE, "On phone", "Compile here with the built-in compiler", 2);
        phoneRow.view.setOnClickListener(v -> selectMode(false));
        build.addView(phoneRow.view, lp(W, H, 10));

        buildBtn = pillBtn("Build plugin", true, 64);
        buildBtn.setTextSize(20);
        buildBtn.setOnClickListener(v -> startBuild());
        build.addView(buildBtn, lp(W, dp(64), 22));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setVisibility(View.GONE);
        build.addView(bar, lp(W, dp(6), 14));
        statusView = text("", 14, SOFT, false);
        statusView.setGravity(Gravity.CENTER);
        build.addView(statusView, lp(W, H, 6));

        resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setPadding(dp(18), dp(16), dp(18), dp(18));
        resultCard.setBackground(grad(0xE6114B2E, 0xE60B6B4F, 28, 0x884ADE80, 1));
        resultCard.setVisibility(View.GONE);
        resultCard.addView(text("Done", 20, WHITE, true));
        resultText = text("", 15, SOFT, false);
        resultCard.addView(resultText, lp(W, H, 6));
        shareBtn = pillBtn("Share / open JAR", false, 48);
        shareBtn.setOnClickListener(v -> shareJars());
        resultCard.addView(shareBtn, lp(W, dp(48), 12));
        build.addView(resultCard, lp(W, H, 14));

        consoleCard = new LinearLayout(this);
        consoleCard.setOrientation(LinearLayout.VERTICAL);
        consoleCard.setPadding(dp(14), dp(12), dp(14), dp(14));
        consoleCard.setBackground(solid(0xCC050B16, 24, 0x33FFFFFF));
        consoleCard.setVisibility(View.GONE);
        LinearLayout ch = new LinearLayout(this);
        ch.setOrientation(LinearLayout.HORIZONTAL);
        ch.setGravity(Gravity.CENTER_VERTICAL);
        ch.addView(text("Output", 16, WHITE, true), new LinearLayout.LayoutParams(0, H, 1f));
        TextView copy = text("Copy", 14, TEAL_L, true);
        copy.setPadding(dp(12), dp(6), dp(4), dp(6));
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("build log", logBuf.toString()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        });
        ch.addView(copy);
        consoleCard.addView(ch);
        logView = text("", 11, SOFT, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        consoleCard.addView(logView, lp(W, H, 8));
        build.addView(consoleCard, lp(W, H, 14));
        pages[0] = page(build);

        // ---------------- page 1: cloud
        LinearLayout cloud = new LinearLayout(this);
        cloud.setOrientation(LinearLayout.VERTICAL);
        cloud.addView(title("GitHub cloud"));
        cloud.addView(text("Builds run on your own GitHub repo with real Maven or Gradle.", 15, MUTED, false), lp(W, H, 4));
        LinearLayout cc = new LinearLayout(this);
        cc.setOrientation(LinearLayout.VERTICAL);
        cc.setPadding(dp(16), dp(16), dp(16), dp(18));
        cc.setBackground(grad(CARD_A, CARD_B, 28, STROKE, 1));
        cc.addView(text("Use a PRIVATE repo you own. The token needs Contents, Actions and Workflows (read and write) for that repo.", 13, SOFT, false));
        tokenEt = input("GitHub token (github_pat_... or ghp_...)", false, true);
        cc.addView(tokenEt, lp(W, H, 14));
        repoEt = input("owner/repo  (e.g. TheUnknown/plugin-builds)", false, false);
        cc.addView(repoEt, lp(W, H, 10));
        testBtn = pillBtn("Save & test", true, 54);
        testBtn.setOnClickListener(v -> saveAndTestCloud());
        cc.addView(testBtn, lp(W, dp(54), 16));
        TextView tokBtn = pillBtn("Create token on GitHub", false, 50);
        tokBtn.setTextSize(15);
        tokBtn.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://github.com/settings/personal-access-tokens/new"))));
        cc.addView(tokBtn, lp(W, dp(50), 10));
        cloudStatus = text("", 14, MUTED, false);
        cc.addView(cloudStatus, lp(W, H, 12));
        cloud.addView(cc, lp(W, H, 18));
        pages[1] = page(cloud);

        // ---------------- page 2: options
        LinearLayout opt = new LinearLayout(this);
        opt.setOrientation(LinearLayout.VERTICAL);
        opt.addView(title("Options"));
        opt.addView(text("Fine-tune what gets compiled. Everything is optional.", 15, MUTED, false), lp(W, H, 4));
        LinearLayout oc = new LinearLayout(this);
        oc.setOrientation(LinearLayout.VERTICAL);
        oc.setPadding(dp(16), dp(16), dp(16), dp(18));
        oc.setBackground(grad(CARD_A, CARD_B, 28, STROKE, 1));
        oc.addView(text("Paper API version (blank = use the project's own)", 13, SOFT, false));
        LinearLayout prow = new LinearLayout(this);
        prow.setOrientation(LinearLayout.HORIZONTAL);
        paperEt = input("e.g. 1.21.4-R0.1-SNAPSHOT", false, false);
        prow.addView(paperEt, new LinearLayout.LayoutParams(0, H, 1f));
        pickBtn = pillBtn("Pick", false, 48);
        pickBtn.setOnClickListener(v -> pickPaperVersion());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(84), dp(48));
        pp.leftMargin = dp(8);
        pp.gravity = Gravity.CENTER_VERTICAL;
        prow.addView(pickBtn, pp);
        oc.addView(prow, lp(W, H, 8));
        oc.addView(text("Java version (blank = auto)", 13, SOFT, false), lp(W, H, 16));
        javaEt = input("17 or 21", false, false);
        javaEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        oc.addView(javaEt, lp(W, H, 8));
        oc.addView(text("Extra dependencies, one per line: group:artifact:version (start with + to bundle)", 13, SOFT, false), lp(W, H, 16));
        depsEt = input("com.zaxxer:HikariCP:5.1.0", true, false);
        oc.addView(depsEt, lp(W, H, 8));
        oc.addView(text("Extra repositories, one URL per line", 13, SOFT, false), lp(W, H, 16));
        reposEt = input("https://jitpack.io", true, false);
        oc.addView(reposEt, lp(W, H, 8));
        opt.addView(oc, lp(W, H, 18));
        TextView clear = pillBtn("Clear downloaded libraries", false, 50);
        clear.setTextSize(15);
        clear.setOnClickListener(v -> {
            Builder.deleteRecursive(new File(getFilesDir(), "work/m2"));
            Toast.makeText(this, "Library cache cleared", Toast.LENGTH_SHORT).show();
        });
        opt.addView(clear, lp(W, dp(50), 14));
        pages[2] = page(opt);

        for (ScrollView s : pages) root.addView(s, new FrameLayout.LayoutParams(W, W));

        // ---------------- floating pill navigation
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackground(solid(0xE60A1322, 40, 0x44FFFFFF));
        String[] labels = {"Build", "Cloud", "Options"};
        IconView.Type[] types = {IconView.Type.BOX, IconView.Type.CLOUD, IconView.Type.SLIDERS};
        for (int i = 0; i < 3; i++) {
            LinearLayout it = navItem(types[i], labels[i], i);
            nav.addView(it, new LinearLayout.LayoutParams(0, dp(66), 1f));
        }
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(W, H);
        nlp.gravity = Gravity.BOTTOM;
        nlp.leftMargin = dp(30);
        nlp.rightMargin = dp(30);
        nlp.bottomMargin = dp(20);
        root.addView(nav, nlp);

        setContentView(root);
    }

    private void showPage(int idx) {
        curPage = idx;
        for (int i = 0; i < 3; i++) {
            pages[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            boolean on = i == idx;
            navItems[i].setBackground(on ? solid(0xFF133A63, 30, 0xFF2D6CB5) : null);
            navIcons[i].setColor(on ? WHITE : MUTED);
            navLabels[i].setTextColor(on ? WHITE : MUTED);
        }
        pages[idx].setAlpha(0f);
        pages[idx].animate().alpha(1f).setDuration(160).start();
    }

    private void setProjectName(String name) {
        projectRow.title.setText(name == null ? "Project folder" : name);
        projectRow.sub.setText("Tap to change the folder");
    }

    private void selectMode(boolean cloud) {
        cloudMode = cloud;
        prefs.edit().putBoolean("cloud", cloud).apply();
        styleRow(cloudRow, cloud, cloud);
        styleRow(phoneRow, !cloud, !cloud);
        setRadio(cloudRow.trail, cloud);
        setRadio(phoneRow.trail, !cloud);
    }

    private void updateCloudStatus() {
        boolean set = !prefs.getString("gh_token", "").isEmpty() && !prefs.getString("gh_repo", "").isEmpty();
        boolean ok = set && prefs.getBoolean("cloud_ok", false);
        banner.title.setText(ok ? "Cloud builds ready" : set ? "Cloud saved, tap to test" : "Set up cloud builds");
        banner.sub.setText(ok ? "Builds run on your GitHub repo" : "Needed for Lombok, shading and big projects");
        cloudStatus.setTextColor(ok ? OKGREEN : MUTED);
        cloudStatus.setText(ok ? "Connected and ready." : set ? "Saved. Tap Save & test to verify." : "Not set up yet.");
    }

    private void pickFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_TREE);
    }

    // ------------------------------------------------------------ actions

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_TREE && res == RESULT_OK && data != null && data.getData() != null) {
            treeUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            DocumentFile d = DocumentFile.fromTreeUri(this, treeUri);
            setProjectName(d != null ? d.getName() : treeUri.getLastPathSegment());
            prefs.edit().putString("tree", treeUri.toString()).apply();
        }
    }

    private void saveCloudPrefs() {
        prefs.edit().putString("gh_token", tokenEt.getText().toString().trim())
                .putString("gh_repo", repoEt.getText().toString().trim()).apply();
    }

    private void saveAndTestCloud() {
        saveCloudPrefs();
        final String token = prefs.getString("gh_token", ""), repo = prefs.getString("gh_repo", "");
        if (token.isEmpty() || repo.isEmpty()) {
            cloudStatus.setText("Enter the token and the repo first.");
            return;
        }
        cloudStatus.setTextColor(MUTED);
        cloudStatus.setText("Testing...");
        testBtn.setEnabled(false);
        showConsole();
        new Thread(() -> {
            String msg;
            int color = OKGREEN;
            boolean good = true;
            try {
                Github gh = new Github(token, repo, "https://api.github.com");
                msg = new CloudBuilder(gh, readAsset("plugin-build.yml"), this::log).verifyAndSetup();
            } catch (CloudBuilder.CloudException e) {
                msg = "Not ready: " + e.getMessage();
                color = DANGER;
                good = false;
            } catch (IllegalArgumentException e) {
                msg = "Not ready: " + e.getMessage();
                color = DANGER;
                good = false;
            } catch (IOException e) {
                msg = "Not ready: " + e.getMessage();
                color = DANGER;
                good = false;
            }
            final String m = msg;
            final int c = color;
            final boolean ok = good;
            runOnUiThread(() -> {
                prefs.edit().putBoolean("cloud_ok", ok).apply();
                updateCloudStatus();
                cloudStatus.setTextColor(c);
                cloudStatus.setText(m);
                testBtn.setEnabled(true);
            });
        }).start();
    }

    private void pickPaperVersion() {
        Toast.makeText(this, "Fetching Paper versions...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String xml = Net.text(Builder.PAPER_REPO + "io/papermc/paper/paper-api/maven-metadata.xml");
            List<String> vs = new ArrayList<>();
            if (xml != null) {
                Matcher m = Pattern.compile("<version>([^<]+)</version>").matcher(xml);
                while (m.find()) vs.add(m.group(1));
            }
            Collections.reverse(vs);
            final List<String> shown = vs.size() > 40 ? new ArrayList<>(vs.subList(0, 40)) : vs;
            runOnUiThread(() -> {
                if (shown.isEmpty()) {
                    Toast.makeText(this, "Could not fetch versions. Check your internet.", Toast.LENGTH_LONG).show();
                    return;
                }
                new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Paper API version")
                        .setItems(shown.toArray(new String[0]), (d, which) -> paperEt.setText(shown.get(which)))
                        .show();
            });
        }).start();
    }

    private void showConsole() {
        consoleCard.setVisibility(View.VISIBLE);
    }

    private void startBuild() {
        if (treeUri == null) {
            Toast.makeText(this, "Choose a project folder first", Toast.LENGTH_SHORT).show();
            return;
        }
        saveCloudPrefs();
        final Builder.Options o = new Builder.Options();
        o.paperVersion = paperEt.getText().toString().trim();
        try { o.javaVersion = Integer.parseInt(javaEt.getText().toString().trim()); } catch (NumberFormatException e) { o.javaVersion = 0; }
        o.extraDeps = depsEt.getText().toString();
        o.extraRepos = reposEt.getText().toString();
        prefs.edit().putString("paper", o.paperVersion).putString("java", javaEt.getText().toString().trim())
                .putString("deps", o.extraDeps).putString("repos", o.extraRepos).apply();

        setBusy(true);
        logBuf.clear();
        logView.setText("");
        resultCard.setVisibility(View.GONE);
        showConsole();
        final Uri uri = treeUri;
        final boolean cloud = cloudMode;
        new Thread(null, () -> runBuild(uri, o, cloud), "builder", 128L * 1024 * 1024).start();
    }

    private void runBuild(Uri uri, Builder.Options o, boolean cloud) {
        boolean ok = false;
        try {
            File work = new File(getFilesDir(), "work");
            File proj = new File(work, "project");
            Builder.deleteRecursive(proj);
            proj.mkdirs();
            log("Copying project from storage...");
            DocumentFile tree = DocumentFile.fromTreeUri(this, uri);
            if (tree == null) throw new IOException("Cannot open the selected folder. Pick it again.");
            copyTree(tree, proj);

            List<File> jars = null;
            if (cloud) {
                try {
                    jars = cloudBuild(proj, o, work);
                } catch (CloudBuilder.CloudException e) {
                    log("\nCloud build failed: " + e.getMessage());
                    boolean go = ask("Cloud build didn't work",
                            e.getMessage() + "\n\nBuild on your phone instead? Some projects may not compile there.",
                            "Build on phone", "Cancel");
                    if (!go) {
                        log("Cancelled.");
                        return;
                    }
                    log("\nSwitching to the on-phone build...\n");
                }
            }
            if (jars == null) {
                File lib = preparedClassLib(work);
                jars = new Builder(work, this::log, lib).build(proj, o);
            }
            List<Uri> saved = new ArrayList<>();
            StringBuilder names = new StringBuilder();
            for (File j : jars) {
                saved.add(saveToDownloads(j));
                names.append(j.getName()).append('\n');
            }
            log("\nDONE: saved to Downloads/PluginBuilder/");
            final String shown = names.toString().trim();
            runOnUiThread(() -> {
                savedUris.clear();
                savedUris.addAll(saved);
                resultText.setText(shown + "\n\nSaved in Downloads/PluginBuilder");
                resultCard.setVisibility(View.VISIBLE);
                pages[0].post(() -> pages[0].fullScroll(View.FOCUS_UP));
            });
            ok = true;
        } catch (Throwable t) {
            log("\nBUILD FAILED: " + t.getMessage());
        } finally {
            final boolean good = ok;
            runOnUiThread(() -> {
                setBusy(false);
                statusView.setText(good ? "Finished" : "");
            });
        }
    }

    private List<File> cloudBuild(File proj, Builder.Options o, File work) throws CloudBuilder.CloudException {
        String token = prefs.getString("gh_token", ""), repo = prefs.getString("gh_repo", "");
        if (token.isEmpty() || repo.isEmpty()) {
            throw new CloudBuilder.CloudException(
                    "Cloud isn't set up yet. Open \"GitHub cloud setup\" and add your token and repository.", false);
        }
        Github gh;
        try {
            gh = new Github(token, repo, "https://api.github.com");
        } catch (IllegalArgumentException e) {
            throw new CloudBuilder.CloudException("The repository must look like owner/name.", false);
        }
        String yaml;
        try {
            yaml = readAsset("plugin-build.yml");
        } catch (IOException e) {
            throw new CloudBuilder.CloudException("The app is missing its workflow file.", false);
        }
        int detected = ProjectConfig.detect(proj, s -> { }).javaVersion;
        int java = o.javaVersion > 0 ? o.javaVersion : detected > 0 ? Math.max(17, detected) : 21;
        File out = new File(work, "cloud-out");
        Builder.deleteRecursive(out);
        return new CloudBuilder(gh, yaml, this::log).build(proj, java, out);
    }

    /** Copies the bundled full-JDK class library out of the APK once per app version. */
    private File preparedClassLib(File work) {
        try {
            long stamp = getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
            File dir = new File(work, "sdk");
            File f = new File(dir, "jdk-api-" + stamp + ".jar");
            if (f.isFile() && f.length() > 1_000_000L) return f;
            dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File x : old) if (x.getName().startsWith("jdk-api-")) x.delete();
            log("Preparing the Java class library (one time)...");
            try (InputStream in = getAssets().open("jdk-api.jar"); OutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[65536];
                int c;
                while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
            }
            return f;
        } catch (Exception e) {
            return null;   // asset not bundled: Builder falls back to downloading android.jar
        }
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        }
    }

    /** Blocks the build thread until the user answers a dialog. */
    private boolean ask(String title, String msg, String yes, String no) {
        final boolean[] res = {false};
        final CountDownLatch latch = new CountDownLatch(1);
        runOnUiThread(() -> new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton(yes, (d, w) -> { res[0] = true; latch.countDown(); })
                .setNegativeButton(no, (d, w) -> latch.countDown())
                .show());
        try {
            latch.await();
        } catch (InterruptedException ignored) { }
        return res[0];
    }

    private void setBusy(boolean busy) {
        buildBtn.setEnabled(!busy);
        buildBtn.setAlpha(busy ? 0.5f : 1f);
        projectRow.view.setEnabled(!busy);
        bar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (busy) {
            statusView.setText("Starting...");
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void log(String s) {
        runOnUiThread(() -> {
            int start = logBuf.length();
            logBuf.append(s).append('\n');
            logBuf.setSpan(new ForegroundColorSpan(colorFor(s)), start, logBuf.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            logView.setText(logBuf);
            if (s.startsWith("[")) statusView.setText(s.replaceFirst("^\\[\\d/\\d\\]\\s*", "") + "...");
            pages[0].post(() -> pages[0].fullScroll(View.FOCUS_DOWN));
        });
    }

    private int colorFor(String s) {
        String l = s.toLowerCase();
        if (l.contains("failed") || l.contains("error")) return DANGER;
        if (l.startsWith("warning") || l.contains("  warning") || l.startsWith("note") || l.contains("unsupported")) return WARN;
        if (s.startsWith("[") || s.startsWith("DONE")) return TEAL_L;
        return SOFT;
    }

    private void shareJars() {
        if (savedUris.isEmpty()) return;
        Intent i;
        if (savedUris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, savedUris.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, new ArrayList<>(savedUris));
        }
        i.setType("application/java-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share plugin JAR"));
    }

    // ------------------------------------------------------------ storage

    private void copyTree(DocumentFile dir, File dest) throws IOException {
        ContentResolver cr = getContentResolver();
        for (DocumentFile f : dir.listFiles()) {
            String n = f.getName();
            if (n == null) continue;
            if (f.isDirectory()) {
                if (SKIP.contains(n)) continue;
                File d = new File(dest, n);
                d.mkdirs();
                copyTree(f, d);
            } else {
                if (f.length() > 100L * 1024 * 1024) continue;
                try (InputStream in = cr.openInputStream(f.getUri());
                     OutputStream out = new FileOutputStream(new File(dest, n))) {
                    if (in == null) continue;
                    byte[] buf = new byte[65536];
                    int c;
                    while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
                }
            }
        }
    }

    private Uri saveToDownloads(File jar) throws IOException {
        ContentResolver cr = getContentResolver();
        String rel = Environment.DIRECTORY_DOWNLOADS + "/PluginBuilder/";
        try {
            cr.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    new String[]{jar.getName(), rel});
        } catch (Exception ignored) { }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME, jar.getName());
        cv.put(MediaStore.Downloads.MIME_TYPE, "application/java-archive");
        cv.put(MediaStore.Downloads.RELATIVE_PATH, rel);
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new IOException("Could not create the file in Downloads.");
        try (OutputStream out = cr.openOutputStream(uri); InputStream in = new FileInputStream(jar)) {
            if (out == null) throw new IOException("Could not write to Downloads.");
            byte[] buf = new byte[65536];
            int c;
            while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
        }
        return uri;
    }
}
