package com.rwee.pluginbuilder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_TREE = 1;
    private static final Set<String> SKIP = new HashSet<>(Arrays.asList(
            ".git", "target", "build", ".gradle", ".idea", "out", "node_modules", ".vscode", ".github"));

    // palette
    private static final int BG = 0xFF0B1220, CARD = 0xFF131C2E, STROKE = 0xFF22304D, INPUT = 0xFF0E1627,
            TXT = 0xFFE6EDF7, SOFT = 0xFFB6C2D9, MUTED = 0xFF8EA0BC, ACCENT = 0xFF22C55E, ACCENT_TXT = 0xFF04210F,
            DANGER = 0xFFF87171, WARN = 0xFFFBBF24, BTN2 = 0xFF1C2842;

    private SharedPreferences prefs;
    private Uri treeUri;
    private boolean cloudMode = true;
    private final List<Uri> savedUris = new ArrayList<>();

    private TextView folderView, statusView, cloudStatus, modeHint, resultText, logView;
    private EditText tokenEt, repoEt, paperEt, javaEt, depsEt, reposEt;
    private Button chooseBtn, pickBtn, buildBtn, testBtn, shareBtn;
    private TextView segCloud, segPhone;
    private ProgressBar bar;
    private ScrollView scroll;
    private LinearLayout consoleCard, resultCard;
    private final SpannableStringBuilder logBuf = new SpannableStringBuilder();

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("pb", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        String t = prefs.getString("tree", null);
        if (t != null) {
            Uri u = Uri.parse(t);
            DocumentFile d = DocumentFile.fromTreeUri(this, u);
            if (d != null && d.canRead()) {
                treeUri = u;
                folderView.setText(d.getName());
                folderView.setTextColor(TXT);
            }
        }
        tokenEt.setText(prefs.getString("gh_token", ""));
        repoEt.setText(prefs.getString("gh_repo", ""));
        paperEt.setText(prefs.getString("paper", ""));
        javaEt.setText(prefs.getString("java", ""));
        depsEt.setText(prefs.getString("deps", ""));
        reposEt.setText(prefs.getString("repos", ""));
        selectMode(prefs.getBoolean("cloud", true));
        updateCloudStatus();
    }

    // ------------------------------------------------------------ UI helpers

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(shape(CARD, 18, STROKE));
        return c;
    }

    private EditText input(String hint, boolean multi, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TXT);
        e.setTextSize(14);
        e.setBackground(shape(INPUT, 12, STROKE));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
            e.setMinLines(2);
            e.setGravity(Gravity.TOP);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            e.setSingleLine(true);
        }
        if (password) e.setTransformationMethod(PasswordTransformationMethod.getInstance());
        return e;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(primary ? ACCENT_TXT : TXT);
        b.setStateListAnimator(null);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape(primary ? ACCENT : BTN2, 14, 0), null));
        return b;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 12, MUTED, true);
        t.setLetterSpacing(0.08f);
        return t;
    }

    /** Header row that shows/hides a body view. */
    private LinearLayout collapsible(String title, View body, boolean open) {
        LinearLayout c = card();
        final TextView head = text((open ? "\u25BE  " : "\u25B8  ") + title, 15, TXT, true);
        head.setPadding(0, dp(2), 0, dp(2));
        c.addView(head);
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        c.addView(body, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        head.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            head.setText((show ? "\u25BE  " : "\u25B8  ") + title);
        });
        return c;
    }

    private void buildUi() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(20), dp(16), dp(28));
        final int W = ViewGroup.LayoutParams.MATCH_PARENT, H = ViewGroup.LayoutParams.WRAP_CONTENT;

        col.addView(text("Plugin Builder", 30, TXT, true));
        col.addView(text("Compile Minecraft plugins from your phone", 14, MUTED, false));

        // project
        LinearLayout proj = card();
        proj.addView(sectionTitle("PROJECT"));
        chooseBtn = button("Choose project folder", false);
        chooseBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_TREE);
        });
        proj.addView(chooseBtn, lp(W, dp(50), 10));
        folderView = text("No folder selected", 14, MUTED, false);
        proj.addView(folderView, lp(W, H, 8));
        col.addView(proj, lp(W, H, 22));

        // mode
        LinearLayout mode = card();
        mode.addView(sectionTitle("BUILD MODE"));
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setBackground(shape(INPUT, 14, STROKE));
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        segCloud = text("Cloud", 15, TXT, true);
        segPhone = text("On phone", 15, TXT, true);
        for (TextView s : new TextView[]{segCloud, segPhone}) {
            s.setGravity(Gravity.CENTER);
            s.setPadding(0, dp(11), 0, dp(11));
            seg.addView(s, new LinearLayout.LayoutParams(0, H, 1f));
        }
        segCloud.setOnClickListener(v -> selectMode(true));
        segPhone.setOnClickListener(v -> selectMode(false));
        mode.addView(seg, lp(W, H, 10));
        modeHint = text("", 12, MUTED, false);
        mode.addView(modeHint, lp(W, H, 8));
        col.addView(mode, lp(W, H, 12));

        // cloud setup
        LinearLayout cloudBody = new LinearLayout(this);
        cloudBody.setOrientation(LinearLayout.VERTICAL);
        cloudBody.addView(text("Use a PRIVATE repo you own. The token needs Contents, Actions and Workflows (read and write).", 12, MUTED, false));
        tokenEt = input("GitHub token (github_pat_... or ghp_...)", false, true);
        cloudBody.addView(tokenEt, lp(W, H, 10));
        repoEt = input("owner/repo  (e.g. TheUnknown/plugin-builds)", false, false);
        cloudBody.addView(repoEt, lp(W, H, 8));
        LinearLayout crow = new LinearLayout(this);
        crow.setOrientation(LinearLayout.HORIZONTAL);
        testBtn = button("Save & test", true);
        testBtn.setOnClickListener(v -> saveAndTestCloud());
        crow.addView(testBtn, new LinearLayout.LayoutParams(0, dp(46), 1f));
        Button tokBtn = button("Create token", false);
        tokBtn.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://github.com/settings/personal-access-tokens/new"))));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        tp.leftMargin = dp(8);
        crow.addView(tokBtn, tp);
        cloudBody.addView(crow, lp(W, H, 10));
        cloudStatus = text("", 13, MUTED, false);
        cloudBody.addView(cloudStatus, lp(W, H, 8));
        col.addView(collapsible("GitHub cloud setup", cloudBody, prefs.getString("gh_token", "").isEmpty()), lp(W, H, 12));

        // advanced
        LinearLayout adv = new LinearLayout(this);
        adv.setOrientation(LinearLayout.VERTICAL);
        adv.addView(text("Paper API version (blank = use the project's own)", 12, MUTED, false));
        LinearLayout prow = new LinearLayout(this);
        prow.setOrientation(LinearLayout.HORIZONTAL);
        paperEt = input("e.g. 1.21.4-R0.1-SNAPSHOT", false, false);
        prow.addView(paperEt, new LinearLayout.LayoutParams(0, H, 1f));
        pickBtn = button("Pick", false);
        pickBtn.setOnClickListener(v -> pickPaperVersion());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(80), dp(46));
        pp.leftMargin = dp(8);
        prow.addView(pickBtn, pp);
        adv.addView(prow, lp(W, H, 6));
        adv.addView(text("Java version (blank = auto)", 12, MUTED, false), lp(W, H, 12));
        javaEt = input("17 or 21", false, false);
        javaEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        adv.addView(javaEt, lp(W, H, 6));
        adv.addView(text("Extra dependencies, one per line: group:artifact:version (start with + to bundle)", 12, MUTED, false), lp(W, H, 12));
        depsEt = input("com.zaxxer:HikariCP:5.1.0", true, false);
        adv.addView(depsEt, lp(W, H, 6));
        adv.addView(text("Extra repositories, one URL per line", 12, MUTED, false), lp(W, H, 12));
        reposEt = input("https://jitpack.io", true, false);
        adv.addView(reposEt, lp(W, H, 6));
        col.addView(collapsible("Advanced options", adv, false), lp(W, H, 12));

        // build
        buildBtn = button("BUILD", true);
        buildBtn.setTextSize(18);
        buildBtn.setOnClickListener(v -> startBuild());
        col.addView(buildBtn, lp(W, dp(60), 18));

        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setVisibility(View.GONE);
        st.addView(bar, lp(W, dp(6), 10));
        statusView = text("", 13, SOFT, false);
        statusView.setGravity(Gravity.CENTER);
        st.addView(statusView, lp(W, H, 6));
        col.addView(st, lp(W, H, 0));

        // result
        resultCard = card();
        resultCard.setVisibility(View.GONE);
        resultCard.addView(sectionTitle("DONE"));
        resultText = text("", 14, TXT, false);
        resultCard.addView(resultText, lp(W, H, 8));
        shareBtn = button("Share / open JAR", false);
        shareBtn.setOnClickListener(v -> shareJars());
        resultCard.addView(shareBtn, lp(W, dp(46), 10));
        col.addView(resultCard, lp(W, H, 14));

        // console
        consoleCard = card();
        consoleCard.setVisibility(View.GONE);
        LinearLayout ch = new LinearLayout(this);
        ch.setOrientation(LinearLayout.HORIZONTAL);
        ch.setGravity(Gravity.CENTER_VERTICAL);
        ch.addView(sectionTitle("OUTPUT"), new LinearLayout.LayoutParams(0, H, 1f));
        TextView copy = text("Copy", 13, ACCENT, true);
        copy.setPadding(dp(10), dp(4), dp(4), dp(4));
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("build log", logBuf.toString()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        });
        ch.addView(copy);
        consoleCard.addView(ch);
        logView = text("", 11, SOFT, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setBackground(shape(INPUT, 12, 0));
        logView.setPadding(dp(10), dp(10), dp(10), dp(10));
        consoleCard.addView(logView, lp(W, H, 8));
        col.addView(consoleCard, lp(W, H, 14));

        Button clear = button("Clear downloaded libraries", false);
        clear.setTextSize(12);
        clear.setOnClickListener(v -> {
            Builder.deleteRecursive(new File(getFilesDir(), "work/m2"));
            Toast.makeText(this, "Library cache cleared", Toast.LENGTH_SHORT).show();
        });
        col.addView(clear, lp(W, dp(40), 16));

        scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.addView(col);
        setContentView(scroll);
    }

    private void selectMode(boolean cloud) {
        cloudMode = cloud;
        prefs.edit().putBoolean("cloud", cloud).apply();
        segCloud.setBackground(cloud ? shape(ACCENT, 11, 0) : null);
        segCloud.setTextColor(cloud ? ACCENT_TXT : SOFT);
        segPhone.setBackground(!cloud ? shape(ACCENT, 11, 0) : null);
        segPhone.setTextColor(!cloud ? ACCENT_TXT : SOFT);
        modeHint.setText(cloud
                ? "Builds on GitHub with real Maven/Gradle. Handles Lombok, relocation and multi-module projects. Needs the cloud setup below."
                : "Compiles on this phone. Works offline after the first download. Lombok is simplified, other annotation processors are not supported.");
    }

    private void updateCloudStatus() {
        boolean set = !prefs.getString("gh_token", "").isEmpty() && !prefs.getString("gh_repo", "").isEmpty();
        cloudStatus.setText(set ? "Saved. Tap Save & test to verify." : "Not set up yet.");
    }

    // ------------------------------------------------------------ actions

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_TREE && res == RESULT_OK && data != null && data.getData() != null) {
            treeUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            DocumentFile d = DocumentFile.fromTreeUri(this, treeUri);
            folderView.setText(d != null ? d.getName() : treeUri.getLastPathSegment());
            folderView.setTextColor(TXT);
            prefs.edit().putString("tree", treeUri.toString()).apply();
        }
    }

    private void saveCloudPrefs() {
        prefs.edit().putString("gh_token", tokenEt.getText().toString().trim())
                .putString("gh_repo", repoEt.getText().toString().trim()).apply();
    }

    private void saveAndTestCloud() {
        saveCloudPrefs();
        final String token = prefs.getString("gh_token", ""), repo = prefs.getString("gh_repo", "");
        if (token.isEmpty() || repo.isEmpty()) {
            cloudStatus.setText("Enter the token and the repo first.");
            return;
        }
        cloudStatus.setTextColor(MUTED);
        cloudStatus.setText("Testing...");
        testBtn.setEnabled(false);
        showConsole();
        new Thread(() -> {
            String msg;
            int color = ACCENT;
            try {
                Github gh = new Github(token, repo, "https://api.github.com");
                msg = new CloudBuilder(gh, readAsset("plugin-build.yml"), this::log).verifyAndSetup();
            } catch (CloudBuilder.CloudException e) {
                msg = "Not ready: " + e.getMessage();
                color = DANGER;
            } catch (IllegalArgumentException e) {
                msg = "Not ready: " + e.getMessage();
                color = DANGER;
            } catch (IOException e) {
                msg = "Not ready: " + e.getMessage();
                color = DANGER;
            }
            final String m = msg;
            final int c = color;
            runOnUiThread(() -> {
                cloudStatus.setTextColor(c);
                cloudStatus.setText(m);
                testBtn.setEnabled(true);
            });
        }).start();
    }

    private void pickPaperVersion() {
        Toast.makeText(this, "Fetching Paper versions...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String xml = Net.text(Builder.PAPER_REPO + "io/papermc/paper/paper-api/maven-metadata.xml");
            List<String> vs = new ArrayList<>();
            if (xml != null) {
                Matcher m = Pattern.compile("<version>([^<]+)</version>").matcher(xml);
                while (m.find()) vs.add(m.group(1));
            }
            Collections.reverse(vs);
            final List<String> shown = vs.size() > 40 ? new ArrayList<>(vs.subList(0, 40)) : vs;
            runOnUiThread(() -> {
                if (shown.isEmpty()) {
                    Toast.makeText(this, "Could not fetch versions. Check your internet.", Toast.LENGTH_LONG).show();
                    return;
                }
                new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Paper API version")
                        .setItems(shown.toArray(new String[0]), (d, which) -> paperEt.setText(shown.get(which)))
                        .show();
            });
        }).start();
    }

    private void showConsole() {
        consoleCard.setVisibility(View.VISIBLE);
    }

    private void startBuild() {
        if (treeUri == null) {
            Toast.makeText(this, "Choose a project folder first", Toast.LENGTH_SHORT).show();
            return;
        }
        saveCloudPrefs();
        final Builder.Options o = new Builder.Options();
        o.paperVersion = paperEt.getText().toString().trim();
        try { o.javaVersion = Integer.parseInt(javaEt.getText().toString().trim()); } catch (NumberFormatException e) { o.javaVersion = 0; }
        o.extraDeps = depsEt.getText().toString();
        o.extraRepos = reposEt.getText().toString();
        prefs.edit().putString("paper", o.paperVersion).putString("java", javaEt.getText().toString().trim())
                .putString("deps", o.extraDeps).putString("repos", o.extraRepos).apply();

        setBusy(true);
        logBuf.clear();
        logView.setText("");
        resultCard.setVisibility(View.GONE);
        showConsole();
        final Uri uri = treeUri;
        final boolean cloud = cloudMode;
        new Thread(null, () -> runBuild(uri, o, cloud), "builder", 128L * 1024 * 1024).start();
    }

    private void runBuild(Uri uri, Builder.Options o, boolean cloud) {
        boolean ok = false;
        try {
            File work = new File(getFilesDir(), "work");
            File proj = new File(work, "project");
            Builder.deleteRecursive(proj);
            proj.mkdirs();
            log("Copying project from storage...");
            DocumentFile tree = DocumentFile.fromTreeUri(this, uri);
            if (tree == null) throw new IOException("Cannot open the selected folder. Pick it again.");
            copyTree(tree, proj);

            List<File> jars = null;
            if (cloud) {
                try {
                    jars = cloudBuild(proj, o, work);
                } catch (CloudBuilder.CloudException e) {
                    log("\nCloud build failed: " + e.getMessage());
                    boolean go = ask("Cloud build didn't work",
                            e.getMessage() + "\n\nBuild on your phone instead? Some projects may not compile there.",
                            "Build on phone", "Cancel");
                    if (!go) {
                        log("Cancelled.");
                        return;
                    }
                    log("\nSwitching to the on-phone build...\n");
                }
            }
            if (jars == null) {
                File lib = preparedClassLib(work);
                jars = new Builder(work, this::log, lib).build(proj, o);
            }
            List<Uri> saved = new ArrayList<>();
            StringBuilder names = new StringBuilder();
            for (File j : jars) {
                saved.add(saveToDownloads(j));
                names.append(j.getName()).append('\n');
            }
            log("\nDONE: saved to Downloads/PluginBuilder/");
            final String shown = names.toString().trim();
            runOnUiThread(() -> {
                savedUris.clear();
                savedUris.addAll(saved);
                resultText.setText(shown + "\n\nSaved in Downloads/PluginBuilder");
                resultCard.setVisibility(View.VISIBLE);
                scroll.post(() -> scroll.fullScroll(View.FOCUS_UP));
            });
            ok = true;
        } catch (Throwable t) {
            log("\nBUILD FAILED: " + t.getMessage());
        } finally {
            final boolean good = ok;
            runOnUiThread(() -> {
                setBusy(false);
                statusView.setText(good ? "Finished" : "");
            });
        }
    }

    private List<File> cloudBuild(File proj, Builder.Options o, File work) throws CloudBuilder.CloudException {
        String token = prefs.getString("gh_token", ""), repo = prefs.getString("gh_repo", "");
        if (token.isEmpty() || repo.isEmpty()) {
            throw new CloudBuilder.CloudException(
                    "Cloud isn't set up yet. Open \"GitHub cloud setup\" and add your token and repository.", false);
        }
        Github gh;
        try {
            gh = new Github(token, repo, "https://api.github.com");
        } catch (IllegalArgumentException e) {
            throw new CloudBuilder.CloudException("The repository must look like owner/name.", false);
        }
        String yaml;
        try {
            yaml = readAsset("plugin-build.yml");
        } catch (IOException e) {
            throw new CloudBuilder.CloudException("The app is missing its workflow file.", false);
        }
        int detected = ProjectConfig.detect(proj, s -> { }).javaVersion;
        int java = o.javaVersion > 0 ? o.javaVersion : detected > 0 ? Math.max(17, detected) : 21;
        File out = new File(work, "cloud-out");
        Builder.deleteRecursive(out);
        return new CloudBuilder(gh, yaml, this::log).build(proj, java, out);
    }

    /** Copies the bundled full-JDK class library out of the APK once per app version. */
    private File preparedClassLib(File work) {
        try {
            long stamp = getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
            File dir = new File(work, "sdk");
            File f = new File(dir, "jdk-api-" + stamp + ".jar");
            if (f.isFile() && f.length() > 1_000_000L) return f;
            dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File x : old) if (x.getName().startsWith("jdk-api-")) x.delete();
            log("Preparing the Java class library (one time)...");
            try (InputStream in = getAssets().open("jdk-api.jar"); OutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[65536];
                int c;
                while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
            }
            return f;
        } catch (Exception e) {
            return null;   // asset not bundled: Builder falls back to downloading android.jar
        }
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        }
    }

    /** Blocks the build thread until the user answers a dialog. */
    private boolean ask(String title, String msg, String yes, String no) {
        final boolean[] res = {false};
        final CountDownLatch latch = new CountDownLatch(1);
        runOnUiThread(() -> new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(title)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton(yes, (d, w) -> { res[0] = true; latch.countDown(); })
                .setNegativeButton(no, (d, w) -> latch.countDown())
                .show());
        try {
            latch.await();
        } catch (InterruptedException ignored) { }
        return res[0];
    }

    private void setBusy(boolean busy) {
        buildBtn.setEnabled(!busy);
        buildBtn.setAlpha(busy ? 0.5f : 1f);
        chooseBtn.setEnabled(!busy);
        bar.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (busy) {
            statusView.setText("Starting...");
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void log(String s) {
        runOnUiThread(() -> {
            int start = logBuf.length();
            logBuf.append(s).append('\n');
            logBuf.setSpan(new ForegroundColorSpan(colorFor(s)), start, logBuf.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            logView.setText(logBuf);
            if (s.startsWith("[")) statusView.setText(s.replaceFirst("^\\[\\d/\\d\\]\\s*", "") + "...");
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    private int colorFor(String s) {
        String l = s.toLowerCase();
        if (l.contains("failed") || l.contains("error")) return DANGER;
        if (l.startsWith("warning") || l.contains("  warning") || l.startsWith("note") || l.contains("unsupported")) return WARN;
        if (s.startsWith("[") || s.startsWith("DONE")) return ACCENT;
        return SOFT;
    }

    private void shareJars() {
        if (savedUris.isEmpty()) return;
        Intent i;
        if (savedUris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, savedUris.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, new ArrayList<>(savedUris));
        }
        i.setType("application/java-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share plugin JAR"));
    }

    // ------------------------------------------------------------ storage

    private void copyTree(DocumentFile dir, File dest) throws IOException {
        ContentResolver cr = getContentResolver();
        for (DocumentFile f : dir.listFiles()) {
            String n = f.getName();
            if (n == null) continue;
            if (f.isDirectory()) {
                if (SKIP.contains(n)) continue;
                File d = new File(dest, n);
                d.mkdirs();
                copyTree(f, d);
            } else {
                if (f.length() > 100L * 1024 * 1024) continue;
                try (InputStream in = cr.openInputStream(f.getUri());
                     OutputStream out = new FileOutputStream(new File(dest, n))) {
                    if (in == null) continue;
                    byte[] buf = new byte[65536];
                    int c;
                    while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
                }
            }
        }
    }

    private Uri saveToDownloads(File jar) throws IOException {
        ContentResolver cr = getContentResolver();
        String rel = Environment.DIRECTORY_DOWNLOADS + "/PluginBuilder/";
        try {
            cr.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?",
                    new String[]{jar.getName(), rel});
        } catch (Exception ignored) { }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME, jar.getName());
        cv.put(MediaStore.Downloads.MIME_TYPE, "application/java-archive");
        cv.put(MediaStore.Downloads.RELATIVE_PATH, rel);
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new IOException("Could not create the file in Downloads.");
        try (OutputStream out = cr.openOutputStream(uri); InputStream in = new FileInputStream(jar)) {
            if (out == null) throw new IOException("Could not write to Downloads.");
            byte[] buf = new byte[65536];
            int c;
            while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
        }
        return uri;
    }
}
