package com.rwee.pluginbuilder;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Minimal GitHub REST client scoped to one repository. */
final class Github {

    static final class ApiException extends IOException {
        final int code;
        ApiException(int code, String msg) { super(msg); this.code = code; }
    }

    final String token, owner, repo, apiBase;

    Github(String token, String repoSpec, String apiBase) {
        String[] r = parseRepo(repoSpec);
        if (r == null) throw new IllegalArgumentException("Repository must look like owner/name");
        this.token = token == null ? "" : token.trim();
        this.owner = r[0];
        this.repo = r[1];
        this.apiBase = apiBase;
    }

    static String[] parseRepo(String s) {
        if (s == null) return null;
        s = s.trim();
        s = s.replaceFirst("^https?://github\\.com/", "").replaceFirst("\\.git$", "").replaceFirst("/+$", "");
        String[] p = s.split("/");
        if (p.length != 2 || p[0].isEmpty() || p[1].isEmpty()) return null;
        return p;
    }

    private Map<String, String> headers(boolean jsonBody) {
        Map<String, String> h = new HashMap<>();
        h.put("Authorization", "Bearer " + token);
        h.put("Accept", "application/vnd.github+json");
        h.put("X-GitHub-Api-Version", "2022-11-28");
        if (jsonBody) h.put("Content-Type", "application/json");
        return h;
    }

    private String repoUrl(String path) { return apiBase + "/repos/" + owner + "/" + repo + path; }

    private static String messageOf(Net.Resp r) {
        String t = r.text();
        try {
            String m = new JSONObject(t).optString("message", "");
            if (!m.isEmpty()) return m;
        } catch (Exception ignored) { }
        return t.length() > 200 ? t.substring(0, 200) : t;
    }

    /** path is relative to the repo, e.g. "/contents/x" (empty string = the repo itself). */
    JSONObject json(String method, String path, JSONObject body) throws IOException {
        byte[] data = body == null ? null : body.toString().getBytes(StandardCharsets.UTF_8);
        Net.Resp r = Net.request(method, repoUrl(path), headers(body != null), data);
        if (r.code >= 400) throw new ApiException(r.code, messageOf(r));
        String t = r.text().trim();
        if (t.isEmpty()) return new JSONObject();
        try {
            return new JSONObject(t);
        } catch (Exception e) {
            throw new IOException("Unexpected reply from GitHub");
        }
    }

    String text(String path) throws IOException {
        Net.Resp r = Net.request("GET", repoUrl(path), headers(false), null);
        if (r.code >= 400) throw new ApiException(r.code, messageOf(r));
        return r.text();
    }

    boolean download(String url, File dest) {
        return Net.download(url, headers(false), dest, null);
    }

    /** Returns the login of the token's owner (verifies the token itself). */
    String login() throws IOException {
        Net.Resp r = Net.request("GET", apiBase + "/user", headers(false), null);
        if (r.code >= 400) throw new ApiException(r.code, messageOf(r));
        try {
            return new JSONObject(r.text()).optString("login", "?");
        } catch (Exception e) {
            return "?";
        }
    }

    static JSONObject obj(Object... kv) {
        try {
            JSONObject o = new JSONObject();
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
            return o;
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
