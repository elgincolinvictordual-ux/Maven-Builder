package com.rwee.pluginbuilder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.view.View;

import java.util.Random;

/**
 * Low-poly 3D mesh background. The mesh is a jittered grid with random depth, rotated in 3D and
 * perspective-projected every frame. The phone's rotation sensor tilts it, so it moves with the phone.
 */
final class MeshBackgroundView extends View implements SensorEventListener {
    private static final int COLS = 9, ROWS = 16;
    private static final float FOCAL = 3.2f;
    private static final float[] LIGHT = norm(-0.35f, -0.5f, 0.79f);

    private final int nv = (COLS + 1) * (ROWS + 1);
    private final float[] ox = new float[nv], oy = new float[nv], oz = new float[nv];
    private final float[] qx = new float[nv], qy = new float[nv], qz = new float[nv];   // rotated 3D
    private final float[] px = new float[nv], py = new float[nv];                         // screen
    private final int[] tris;
    private final float[] tone;
    private final int[] edges;
    private final float[][] lineBuf = new float[3][];
    private final float[] dots = new float[nv * 2];

    private final Paint bgPaint = new Paint(), glowA = new Paint(), glowB = new Paint();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tri = new Path();

    private SensorManager sm;
    private boolean running;
    private final float[] rot = new float[9], base = new float[9], rel = new float[9];
    private boolean haveBase;
    private float lpX, lpY, tx, ty, cx, cy;

    MeshBackgroundView(Context ctx) {
        super(ctx);
        Random rnd = new Random(11);
        for (int j = 0; j <= ROWS; j++) {
            for (int i = 0; i <= COLS; i++) {
                int k = j * (COLS + 1) + i;
                float jx = (rnd.nextFloat() - 0.5f) * 0.76f * (2.6f / COLS);
                float jy = (rnd.nextFloat() - 0.5f) * 0.76f * (2.6f / ROWS);
                ox[k] = -1.3f + 2.6f * i / COLS + jx;
                oy[k] = -1.3f + 2.6f * j / ROWS + jy;
                oz[k] = (rnd.nextFloat() - 0.5f) * 0.9f;
            }
        }
        int cells = COLS * ROWS;
        tris = new int[cells * 6];
        tone = new float[cells * 2];
        int t = 0, tt = 0;
        for (int j = 0; j < ROWS; j++) {
            for (int i = 0; i < COLS; i++) {
                int a = j * (COLS + 1) + i, b = a + 1, c = a + COLS + 1, d = c + 1;
                if (((i + j) & 1) == 0) {
                    set3(tris, t, a, b, d); t += 3; set3(tris, t, a, d, c); t += 3;
                } else {
                    set3(tris, t, a, b, c); t += 3; set3(tris, t, b, d, c); t += 3;
                }
                tone[tt++] = 0.55f + rnd.nextFloat() * 0.45f;
                tone[tt++] = 0.55f + rnd.nextFloat() * 0.45f;
            }
        }
        int ne = (COLS * (ROWS + 1)) + (ROWS * (COLS + 1)) + cells;
        edges = new int[ne * 2];
        int e = 0;
        for (int j = 0; j <= ROWS; j++) for (int i = 0; i < COLS; i++) { int a = j * (COLS + 1) + i; edges[e++] = a; edges[e++] = a + 1; }
        for (int j = 0; j < ROWS; j++) for (int i = 0; i <= COLS; i++) { int a = j * (COLS + 1) + i; edges[e++] = a; edges[e++] = a + COLS + 1; }
        for (int j = 0; j < ROWS; j++) {
            for (int i = 0; i < COLS; i++) {
                int a = j * (COLS + 1) + i;
                if (((i + j) & 1) == 0) { edges[e++] = a; edges[e++] = a + COLS + 2; }
                else { edges[e++] = a + 1; edges[e++] = a + COLS + 1; }
            }
        }
        for (int k = 0; k < 3; k++) lineBuf[k] = new float[ne * 4];

        float d = ctx.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(1.1f * d);
        line.setColor(0xFFCFE3FF);
        dot.setStyle(Paint.Style.STROKE);
        dot.setStrokeCap(Paint.Cap.ROUND);
        dot.setStrokeWidth(2.6f * d);
        dot.setColor(0xFFBFD8FF);
        dot.setAlpha(95);
        fill.setStyle(Paint.Style.FILL);
        setWillNotDraw(false);
    }

    private static void set3(int[] a, int o, int x, int y, int z) { a[o] = x; a[o + 1] = y; a[o + 2] = z; }

    private static float[] norm(float x, float y, float z) {
        float l = (float) Math.sqrt(x * x + y * y + z * z);
        return new float[]{x / l, y / l, z / l};
    }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgPaint.setShader(new LinearGradient(0, 0, 0, h, 0xFF030812, 0xFF02060C, Shader.TileMode.CLAMP));
        glowA.setShader(new RadialGradient(w * 0.5f, h * 0.9f, Math.max(w, 1) * 1.1f, 0x3314B8A6, 0x0014B8A6, Shader.TileMode.CLAMP));
        glowB.setShader(new RadialGradient(w * 0.05f, h * 0.08f, Math.max(w, 1) * 0.9f, 0x302563EB, 0x002563EB, Shader.TileMode.CLAMP));
    }

    // ------------------------------------------------------------ sensors

    void startSensors() {
        running = true;
        sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        if (sm != null) {
            Sensor s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (s == null) s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
        }
        postInvalidateOnAnimation();
    }

    void stopSensors() {
        running = false;
        if (sm != null) sm.unregisterListener(this);
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onSensorChanged(SensorEvent e) {
        float wx, wy;
        int type = e.sensor.getType();
        if (type == Sensor.TYPE_GAME_ROTATION_VECTOR || type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rot, e.values);
            if (!haveBase) { System.arraycopy(rot, 0, base, 0, 9); haveBase = true; lpX = 0; lpY = 0; }
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    rel[i * 3 + j] = base[i] * rot[j] + base[3 + i] * rot[3 + j] + base[6 + i] * rot[6 + j];
                }
            }
            wx = (rel[7] - rel[5]) * 0.5f;
            wy = (rel[2] - rel[6]) * 0.5f;
            if (Math.abs(wx) > 0.9f || Math.abs(wy) > 0.9f) haveBase = false;   // big pose change: re-center
        } else {
            float g = 9.81f;
            wx = (float) Math.atan2(e.values[2], Math.max(0.1f, e.values[1])) - 0f;
            wy = (float) Math.asin(clamp(e.values[0] / g, -1f, 1f));
        }
        lpX += (wx - lpX) * 0.004f;   // slowly drift back to centre when the phone is held still
        lpY += (wy - lpY) * 0.004f;
        tx = clamp(wx - lpX, -0.55f, 0.55f);
        ty = clamp(wy - lpY, -0.55f, 0.55f);
    }

    // ------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight();
        cv.drawRect(0, 0, w, h, bgPaint);
        cv.drawRect(0, 0, w, h, glowA);
        cv.drawRect(0, 0, w, h, glowB);

        float t = SystemClock.uptimeMillis() / 1000f;
        cx += (tx - cx) * 0.1f;
        cy += (ty - cy) * 0.1f;
        float rx = clamp(cx * 0.62f + 0.05f * (float) Math.sin(t * 0.45f), -0.5f, 0.5f);
        float ry = clamp(-cy * 0.62f + 0.06f * (float) Math.cos(t * 0.37f), -0.5f, 0.5f);
        float crx = (float) Math.cos(rx), srx = (float) Math.sin(rx), cry = (float) Math.cos(ry), sry = (float) Math.sin(ry);
        float hw = w * 0.5f, hh = h * 0.5f;

        for (int k = 0; k < nv; k++) {
            float x = ox[k], y = oy[k], z = oz[k] + 0.04f * (float) Math.sin(t * 0.8f + k);
            float x1 = x * cry + z * sry;
            float z1 = -x * sry + z * cry;
            float y1 = y * crx - z1 * srx;
            float z2 = y * srx + z1 * crx;
            float s = FOCAL / (FOCAL - z2);
            qx[k] = x1; qy[k] = y1; qz[k] = z2;
            px[k] = hw + x1 * s * hw;
            py[k] = hh + y1 * s * hh;
            dots[k * 2] = px[k];
            dots[k * 2 + 1] = py[k];
        }

        // faceted fills: brightness follows each triangle's tilt against the light
        for (int i = 0, ti = 0; i < tris.length; i += 3, ti++) {
            int a = tris[i], b = tris[i + 1], c = tris[i + 2];
            float ux = qx[b] - qx[a], uy = qy[b] - qy[a], uz = qz[b] - qz[a];
            float vx = qx[c] - qx[a], vy = qy[c] - qy[a], vz = qz[c] - qz[a];
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz) + 1e-6f;
            float br = Math.abs((nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]) / nl);
            float tn = tone[ti];
            int alpha = (int) (10 + 60 * br * br * tn);
            fill.setColor(Color.argb(alpha, (int) (24 + 40 * br), (int) (110 + 90 * br * tn), (int) (170 + 60 * br)));
            tri.reset();
            tri.moveTo(px[a], py[a]); tri.lineTo(px[b], py[b]); tri.lineTo(px[c], py[c]); tri.close();
            cv.drawPath(tri, fill);
        }

        // edges in three depth buckets (far = faint, near = bright)
        int[] n = new int[3];
        for (int i = 0; i < edges.length; i += 2) {
            int a = edges[i], b = edges[i + 1];
            float z = (qz[a] + qz[b]) * 0.5f;
            int bk = z > 0.12f ? 2 : z > -0.12f ? 1 : 0;
            float[] buf = lineBuf[bk];
            int o = n[bk] * 4;
            buf[o] = px[a]; buf[o + 1] = py[a]; buf[o + 2] = px[b]; buf[o + 3] = py[b];
            n[bk]++;
        }
        int[] alphas = {26, 48, 84};
        for (int bk = 0; bk < 3; bk++) {
            line.setAlpha(alphas[bk]);
            cv.drawLines(lineBuf[bk], 0, n[bk] * 4, line);
        }
        cv.drawPoints(dots, 0, nv * 2, dot);

        if (running) postInvalidateOnAnimation();
    }
}
