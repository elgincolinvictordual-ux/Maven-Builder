package com.rwee.pluginbuilder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Small set of icons drawn in code (no vector files, nothing that can fail to inflate). */
final class IconView extends View {
    enum Type { FOLDER, CLOUD, PHONE, BOX, SLIDERS, LIST, CHEVRON }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private Type type;
    private int color = Color.WHITE;
    private float scaleBox = 0.5f;

    IconView(Context c, Type t) {
        super(c);
        type = t;
    }

    void setColor(int c) { color = c; invalidate(); }

    void setBoxScale(float s) { scaleBox = s; invalidate(); }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h) * scaleBox;
        cv.save();
        cv.translate((w - s) / 2f, (h - s) / 2f);
        cv.scale(s, s);   // draw in unit coordinates
        p.setColor(color);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(0.1f);
        p.setStyle(Paint.Style.STROKE);
        path.reset();
        switch (type) {
            case FOLDER:
                path.moveTo(0.08f, 0.26f); path.lineTo(0.38f, 0.26f); path.lineTo(0.47f, 0.37f);
                path.lineTo(0.92f, 0.37f); path.lineTo(0.92f, 0.8f); path.lineTo(0.08f, 0.8f); path.close();
                cv.drawPath(path, p);
                break;
            case CLOUD:
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(0.31f, 0.56f, 0.17f, p);
                cv.drawCircle(0.52f, 0.41f, 0.22f, p);
                cv.drawCircle(0.74f, 0.57f, 0.15f, p);
                rect.set(0.2f, 0.5f, 0.88f, 0.73f);
                cv.drawRoundRect(rect, 0.11f, 0.11f, p);
                break;
            case PHONE:
                rect.set(0.28f, 0.07f, 0.72f, 0.93f);
                cv.drawRoundRect(rect, 0.1f, 0.1f, p);
                cv.drawLine(0.44f, 0.8f, 0.56f, 0.8f, p);
                break;
            case BOX: {
                float cx = 0.5f, cy = 0.5f, r = 0.42f;
                for (int k = 0; k < 6; k++) {
                    double a = Math.toRadians(-90 + 60 * k);
                    float x = cx + (float) Math.cos(a) * r, y = cy + (float) Math.sin(a) * r;
                    if (k == 0) path.moveTo(x, y); else path.lineTo(x, y);
                }
                path.close();
                cv.drawPath(path, p);
                for (int k = 1; k < 6; k += 2) {
                    double a = Math.toRadians(-90 + 60 * k);
                    cv.drawLine(cx, cy, cx + (float) Math.cos(a) * r, cy + (float) Math.sin(a) * r, p);
                }
                break;
            }
            case SLIDERS: {
                float[] ys = {0.25f, 0.5f, 0.75f}, ks = {0.34f, 0.66f, 0.45f};
                for (int k = 0; k < 3; k++) {
                    p.setStyle(Paint.Style.STROKE);
                    cv.drawLine(0.12f, ys[k], 0.88f, ys[k], p);
                    p.setStyle(Paint.Style.FILL);
                    cv.drawCircle(ks[k], ys[k], 0.1f, p);
                }
                break;
            }
            case LIST:
                for (int k = 0; k < 3; k++) {
                    float y = 0.27f + 0.23f * k;
                    p.setStyle(Paint.Style.FILL);
                    cv.drawCircle(0.16f, y, 0.05f, p);
                    p.setStyle(Paint.Style.STROKE);
                    cv.drawLine(0.34f, y, 0.88f, y, p);
                }
                break;
            case CHEVRON:
                path.moveTo(0.36f, 0.18f); path.lineTo(0.7f, 0.5f); path.lineTo(0.36f, 0.82f);
                cv.drawPath(path, p);
                break;
        }
        cv.restore();
    }
}
