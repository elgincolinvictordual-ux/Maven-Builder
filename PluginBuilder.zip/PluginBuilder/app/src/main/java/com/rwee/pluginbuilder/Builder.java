package com.rwee.pluginbuilder;

import org.eclipse.jdt.core.compiler.batch.BatchCompiler;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Full pipeline: detect project -> resolve dependencies -> compile with ECJ -> package JAR. */
final class Builder {

    static final String ANDROID_JAR_URL =
            "https://raw.githubusercontent.com/Sable/android-platforms/master/android-34/android.jar";
    static final String PAPER_REPO = "https://repo.papermc.io/repository/maven-public/";
    static final String CENTRAL = "https://repo.maven.apache.org/maven2/";
    static final String DEFAULT_PAPER = "1.21.4-R0.1-SNAPSHOT";
    static final int MAX_JAVA = 21;

    static final class Options {
        String paperVersion = "";
        int javaVersion = 0;
        String extraDeps = "";
        String extraRepos = "";
    }

    private static final Set<String> API_KEYS = new HashSet<>(Arrays.asList(
            "io.papermc.paper:paper-api", "com.destroystokyo.paper:paper-api", "org.spigotmc:spigot-api",
            "org.bukkit:bukkit", "dev.folia:folia-api", "org.purpurmc.purpur:purpur-api"));

    private static final Set<String> SKIP_DIRS = new HashSet<>(Arrays.asList(
            ".git", "target", "build", ".gradle", ".idea", "out", "node_modules", ".vscode"));

    private final File work;
    private final BuildLog log;

    Builder(File workDir, BuildLog log) {
        this.work = workDir;
        this.log = log;
    }

    File build(File projectDir, Options o) throws Exception {
        long t0 = System.currentTimeMillis();

        log.log("[1/5] Java class library");
        File androidJar = ensureAndroidJar();

        log.log("[2/5] Reading project");
        File root = locateRoot(projectDir);
        ProjectConfig cfg = ProjectConfig.detect(root, log);

        List<Pom.Dep> roots = new ArrayList<>();
        boolean hasApi = false;
        for (Pom.Dep d0 : cfg.deps) {
            Pom.Dep d = cfg.pom != null ? cfg.pom.effective(d0) : d0;
            String sc = d.scope == null ? "compile" : d.scope;
            if (sc.equals("test")) continue;
            if (!cfg.shade) {
                if (sc.equals("runtime")) continue;
                if (sc.equals("compile")) { d = copy(d); d.scope = "provided"; }
            }
            if (API_KEYS.contains(d.key())) hasApi = true;
            if (d.key().equals("org.projectlombok:lombok")) {
                log.log("Warning: Lombok is not supported on the phone compiler. The build will likely fail.");
            }
            roots.add(d);
        }

        String pv = o.paperVersion.trim();
        if (!pv.isEmpty()) {
            for (int i = roots.size() - 1; i >= 0; i--) if (roots.get(i).key().equals("io.papermc.paper:paper-api")) roots.remove(i);
            roots.add(dep("io.papermc.paper", "paper-api", pv, "provided"));
            log.log("Using Paper API " + pv);
        } else if (!hasApi) {
            roots.add(dep("io.papermc.paper", "paper-api", DEFAULT_PAPER, "provided"));
            log.log("No server API found in the project, adding Paper API " + DEFAULT_PAPER);
        }
        for (String line : o.extraDeps.split("\\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            boolean bundle = line.startsWith("+");
            if (bundle) line = line.substring(1).trim();
            String[] p = line.split(":");
            if (p.length < 3) { log.log("Ignored extra dependency (need group:artifact:version): " + line); continue; }
            Pom.Dep d = dep(p[0].trim(), p[1].trim(), p[2].trim(), bundle ? "compile" : "provided");
            if (p.length >= 4) d.classifier = p[3].trim();
            roots.add(d);
        }
        if (cfg.relocation) log.log("Note: relocation/shading rules are not applied. Libraries are bundled as-is.");

        List<String> repos = new ArrayList<>(Arrays.asList(PAPER_REPO, CENTRAL));
        repos.addAll(cfg.repos);
        for (String r : o.extraRepos.split("\\n")) if (!r.trim().isEmpty()) repos.add(r.trim());

        log.log("[3/5] Resolving dependencies");
        MavenResolver res = new MavenResolver(new File(work, "m2"), repos, log);
        res.resolve(roots);
        log.log("  " + res.count() + " artifacts ready");

        log.log("[4/5] Compiling");
        List<File> srcRoots = sourceRoots(root);
        if (srcRoots.isEmpty()) throw new IOException("No .java files found in the selected folder.");
        File classes = new File(work, "build/classes");
        deleteRecursive(new File(work, "build"));
        classes.mkdirs();

        int lvl = o.javaVersion > 0 ? o.javaVersion : cfg.javaVersion > 0 ? cfg.javaVersion : 17;
        if (lvl > MAX_JAVA) {
            log.log("Java " + lvl + " is above what the bundled compiler supports, using " + MAX_JAVA + ".");
            lvl = MAX_JAVA;
        }
        if (lvl < 8) lvl = 8;
        log.log("  Java level " + lvl);

        List<String> args = new ArrayList<>();
        args.add(lvl <= 8 ? "-1.8" : "-" + lvl);
        args.addAll(Arrays.asList("-encoding", "UTF-8", "-proc:none", "-nowarn", "-g", "-parameters",
                "-bootclasspath", androidJar.getPath(), "-d", classes.getPath()));
        List<File> cp = res.classpath();
        if (!cp.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (File f : cp) { if (sb.length() > 0) sb.append(File.pathSeparator); sb.append(f.getPath()); }
            args.add("-classpath");
            args.add(sb.toString());
        }
        for (File s : srcRoots) args.add(s.getPath());

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        boolean ok = BatchCompiler.compile(args.toArray(new String[0]), pw, pw, null);
        pw.flush();
        String outText = sw.toString().trim();
        if (!outText.isEmpty()) {
            String[] lines = outText.split("\\n");
            for (int i = 0; i < lines.length && i < 120; i++) log.log(lines[i].replace(root.getPath(), "."));
            if (lines.length > 120) log.log("... (" + (lines.length - 120) + " more lines)");
        }
        if (!ok) throw new IOException("Compilation failed. See the errors above.");

        log.log("[5/5] Packaging");
        List<File> resRoots = resourceRoots(root, srcRoots);
        Map<String, String> vars = new HashMap<>(cfg.vars);
        if (cfg.version != null) { vars.put("project.version", cfg.version); vars.put("version", cfg.version); }
        File jar = new File(work, "build/" + jarName(cfg, root) + ".jar");
        Set<String> entries = Packager.pack(jar, classes, resRoots, vars, res.bundled());
        if (!entries.contains("plugin.yml") && !entries.contains("paper-plugin.yml")) {
            log.log("Warning: no plugin.yml found. The server will not load this JAR without one.");
        }
        log.log("Built " + jar.getName() + " (" + (jar.length() / 1024) + " KB) in "
                + (System.currentTimeMillis() - t0) / 1000 + "s");
        return jar;
    }

    // ------------------------------------------------------------------

    private File ensureAndroidJar() throws IOException {
        File f = new File(work, "sdk/android.jar");
        if (f.isFile() && f.length() > 20_000_000L) {
            log.log("  ready");
            return f;
        }
        log.log("  Downloading Java class library (about 26 MB, one time only)...");
        if (!Net.download(ANDROID_JAR_URL, f, log)) {
            throw new IOException("Could not download the Java class library. Check your internet connection.");
        }
        return f;
    }

    private static Pom.Dep dep(String g, String a, String v, String scope) {
        Pom.Dep d = new Pom.Dep();
        d.g = g; d.a = a; d.v = v; d.scope = scope;
        return d;
    }

    private static Pom.Dep copy(Pom.Dep s) {
        Pom.Dep d = dep(s.g, s.a, s.v, s.scope);
        d.classifier = s.classifier; d.type = s.type; d.optional = s.optional;
        d.excl.addAll(s.excl);
        return d;
    }

    /** If the picked folder is just a container with a single project inside, descend into it. */
    private static File locateRoot(File dir) {
        for (int i = 0; i < 2; i++) {
            if (looksLikeProject(dir)) return dir;
            File[] subs = dir.listFiles(File::isDirectory);
            if (subs == null || subs.length != 1) return dir;
            dir = subs[0];
        }
        return dir;
    }

    private static boolean looksLikeProject(File d) {
        return new File(d, "pom.xml").isFile() || new File(d, "build.gradle").isFile()
                || new File(d, "build.gradle.kts").isFile() || new File(d, "src").isDirectory()
                || new File(d, "plugin.yml").isFile();
    }

    private static List<File> sourceRoots(File root) {
        File m = new File(root, "src/main/java");
        if (m.isDirectory() && hasJava(m)) return Collections.singletonList(m);
        File s = new File(root, "src");
        if (s.isDirectory() && hasJava(s)) return Collections.singletonList(s);
        if (hasJava(root)) return Collections.singletonList(root);
        return Collections.emptyList();
    }

    private static boolean hasJava(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) return false;
        for (File f : fs) {
            if (f.isDirectory()) {
                if (!SKIP_DIRS.contains(f.getName()) && hasJava(f)) return true;
            } else if (f.getName().endsWith(".java")) return true;
        }
        return false;
    }

    private List<File> resourceRoots(File root, List<File> srcRoots) {
        File r = new File(root, "src/main/resources");
        if (r.isDirectory()) return Collections.singletonList(r);
        r = new File(root, "resources");
        if (r.isDirectory()) return Collections.singletonList(r);
        r = new File(root, "src/resources");
        if (r.isDirectory()) return Collections.singletonList(r);
        // Loose layout: copy plugin.yml (+ config.yml) from wherever plugin.yml lives.
        File py = findFile(root, "plugin.yml");
        if (py == null) py = findFile(root, "paper-plugin.yml");
        if (py == null) return Collections.emptyList();
        File tmp = new File(work, "build/res");
        tmp.mkdirs();
        for (String n : new String[]{"plugin.yml", "paper-plugin.yml", "config.yml"}) {
            File src = new File(py.getParentFile(), n);
            if (src.isFile()) {
                try { java.nio.file.Files.copy(src.toPath(), new File(tmp, n).toPath()); } catch (IOException ignored) { }
            }
        }
        return Collections.singletonList(tmp);
    }

    private static File findFile(File dir, String name) {
        File[] fs = dir.listFiles();
        if (fs == null) return null;
        for (File f : fs) if (f.isFile() && f.getName().equals(name)) return f;
        for (File f : fs) {
            if (f.isDirectory() && !SKIP_DIRS.contains(f.getName())) {
                File r = findFile(f, name);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static String jarName(ProjectConfig c, File root) {
        String n;
        if (c.finalName != null && !c.finalName.contains("${")) n = c.finalName;
        else if (c.version != null) n = c.name + "-" + c.version;
        else n = c.name != null ? c.name : root.getName();
        return n.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    static void deleteRecursive(File f) {
        File[] fs = f.listFiles();
        if (fs != null) for (File c : fs) deleteRecursive(c);
        f.delete();
    }
}
