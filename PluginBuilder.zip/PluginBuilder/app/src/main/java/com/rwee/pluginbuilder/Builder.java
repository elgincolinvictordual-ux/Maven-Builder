package com.rwee.pluginbuilder;

import org.eclipse.jdt.core.compiler.batch.BatchCompiler;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** On-phone pipeline: detect modules -> resolve deps -> (expand Lombok) -> compile with ECJ -> package JARs. */
final class Builder {

    static final String ANDROID_JAR_URL =
            "https://raw.githubusercontent.com/Sable/android-platforms/master/android-34/android.jar";
    static final String PAPER_REPO = "https://repo.papermc.io/repository/maven-public/";
    static final String CENTRAL = "https://repo.maven.apache.org/maven2/";
    static final String DEFAULT_PAPER = "1.21.4-R0.1-SNAPSHOT";
    static final int MAX_JAVA = 21;

    static final class Options {
        String paperVersion = "";
        int javaVersion = 0;
        String extraDeps = "";
        String extraRepos = "";
    }

    private static final class Module {
        String id;
        File dir;
        ProjectConfig cfg;
        final List<String[]> modDeps = new ArrayList<>();   // {id, scope}
        MavenResolver res;
        File classes;
        List<File> resRoots = new ArrayList<>();
        boolean hasPluginYml;
    }

    private static final Set<String> API_KEYS = new HashSet<>(Arrays.asList(
            "io.papermc.paper:paper-api", "com.destroystokyo.paper:paper-api", "org.spigotmc:spigot-api",
            "org.bukkit:bukkit", "dev.folia:folia-api", "org.purpurmc.purpur:purpur-api"));

    private static final Set<String> SKIP_DIRS = new HashSet<>(Arrays.asList(
            ".git", "target", "build", ".gradle", ".idea", "out", "node_modules", ".vscode"));

    /** Test hook: replaces the default repositories. */
    static List<String> repoOverride;

    private final File work;
    private final BuildLog log;
    private final File bundledLib;

    /** bundledLib: full JDK class library shipped with the app (null = download android.jar instead). */
    Builder(File workDir, BuildLog log, File bundledLib) {
        this.work = workDir;
        this.log = log;
        this.bundledLib = bundledLib;
    }

    List<File> build(File projectDir, Options o) throws Exception {
        long t0 = System.currentTimeMillis();
        deleteRecursive(new File(work, "build"));

        log.log("[1/5] Java class library");
        File classLib = ensureClassLib();

        log.log("[2/5] Reading project");
        File root = locateRoot(projectDir);
        List<Module> mods = findModules(root, null);
        Map<String, Module> byId = new LinkedHashMap<>();
        for (Module m : mods) byId.put(m.id, m);
        if (mods.size() > 1) log.log("  " + mods.size() + " modules: " + byId.keySet());

        List<String> baseRepos = new ArrayList<>(repoOverride != null ? repoOverride : Arrays.asList(PAPER_REPO, CENTRAL));
        for (String r : o.extraRepos.split("\\n")) if (!r.trim().isEmpty()) baseRepos.add(r.trim());

        log.log("[3/5] Resolving dependencies");
        for (Module m : mods) resolveModule(m, byId, o, baseRepos);

        log.log("[4/5] Compiling");
        List<Module> order = topo(mods, byId);
        for (Module m : order) compileModule(m, byId, o, classLib);

        log.log("[5/5] Packaging");
        List<Module> outs = new ArrayList<>();
        for (Module m : mods) if (m.hasPluginYml) outs.add(m);
        if (outs.isEmpty()) {
            Set<String> used = new HashSet<>();
            for (Module m : mods) for (String[] d : m.modDeps) used.add(d[0]);
            for (Module m : mods) if (!used.contains(m.id)) outs.add(m);
        }
        List<File> jars = new ArrayList<>();
        for (Module m : outs) jars.add(packModule(m, byId));
        log.log("Built " + jars.size() + " JAR(s) in " + (System.currentTimeMillis() - t0) / 1000 + "s");
        return jars;
    }

    // ------------------------------------------------------------------ modules

    private List<Module> findModules(File dir, ProjectConfig parent) {
        ProjectConfig c = ProjectConfig.detect(dir, log);
        if (parent != null && !c.system.equals("maven")) {
            c.repos.addAll(parent.repos);
            if (parent.gradleSubprojects) { c.deps.addAll(parent.deps); c.shade |= parent.shade; }
        }
        List<Module> out = new ArrayList<>();
        if (!c.modules.isEmpty()) {
            for (String mod : c.modules) {
                File d = new File(dir, mod);
                if (d.isDirectory()) out.addAll(findModules(d, c));
            }
            if (!out.isEmpty()) return out;
        }
        Module m = new Module();
        m.dir = dir;
        m.cfg = c;
        m.id = c.system.equals("maven") && c.name != null ? c.name : dir.getName();
        out.add(m);
        return out;
    }

    private void resolveModule(Module m, Map<String, Module> byId, Options o, List<String> baseRepos) {
        ProjectConfig cfg = m.cfg;
        List<Pom.Dep> roots = new ArrayList<>();
        boolean hasApi = false;
        for (Pom.Dep d0 : cfg.deps) {
            Pom.Dep d = cfg.pom != null ? cfg.pom.effective(d0) : d0;
            String sc = d.scope == null ? "compile" : d.scope;
            if (sc.equals("test")) continue;
            if (cfg.system.equals("maven") && byId.containsKey(d.a) && !d.a.equals(m.id)) {
                m.modDeps.add(new String[]{d.a, sc});
                continue;
            }
            if (API_KEYS.contains(d.key())) hasApi = true;
            if (d.key().equals("org.projectlombok:lombok")) log.log("  Lombok found: using the built-in simplified expansion");
            roots.add(d);
        }
        for (String[] md : cfg.modDeps) {
            String id = md[0].substring(md[0].lastIndexOf('/') + 1);
            if (byId.containsKey(id) && !id.equals(m.id)) m.modDeps.add(new String[]{id, md[1]});
        }
        String pv = o.paperVersion.trim();
        if (!pv.isEmpty()) {
            for (int i = roots.size() - 1; i >= 0; i--) if (roots.get(i).key().equals("io.papermc.paper:paper-api")) roots.remove(i);
            roots.add(dep("io.papermc.paper", "paper-api", pv, "provided"));
        } else if (!hasApi) {
            roots.add(dep("io.papermc.paper", "paper-api", DEFAULT_PAPER, "provided"));
            log.log("  " + m.id + ": no server API in the project, adding Paper API " + DEFAULT_PAPER);
        }
        for (String line : o.extraDeps.split("\\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            boolean bundle = line.startsWith("+");
            if (bundle) line = line.substring(1).trim();
            String[] p = line.split(":");
            if (p.length < 3) { log.log("  ignored extra dependency (need group:artifact:version): " + line); continue; }
            Pom.Dep d = dep(p[0].trim(), p[1].trim(), p[2].trim(), bundle ? "compile" : "provided");
            if (p.length >= 4) d.classifier = p[3].trim();
            roots.add(d);
        }
        if (!cfg.relocations.isEmpty()) log.log("  " + m.id + ": " + cfg.relocations.size() + " relocation rule(s) will be applied");
        List<String> repos = new ArrayList<>(baseRepos);
        repos.addAll(cfg.repos);
        m.res = new MavenResolver(new File(work, "m2"), repos, log);
        m.res.resolve(roots);
        log.log("  " + m.id + ": " + m.res.count() + " artifacts ready");
    }

    private List<Module> topo(List<Module> mods, Map<String, Module> byId) {
        List<Module> out = new ArrayList<>();
        Set<String> done = new HashSet<>(), busy = new HashSet<>();
        for (Module m : mods) visit(m, byId, done, busy, out);
        return out;
    }

    private void visit(Module m, Map<String, Module> byId, Set<String> done, Set<String> busy, List<Module> out) {
        if (done.contains(m.id) || !busy.add(m.id)) return;
        for (String[] d : m.modDeps) visit(byId.get(d[0]), byId, done, busy, out);
        done.add(m.id);
        out.add(m);
    }

    /** Module deps reachable from m (excluding provided-scope edges when onlyBundled). */
    private Set<Module> moduleClosure(Module m, Map<String, Module> byId, boolean onlyBundled) {
        Set<Module> out = new LinkedHashSet<>();
        collect(m, byId, onlyBundled, out);
        out.remove(m);
        return out;
    }

    private void collect(Module m, Map<String, Module> byId, boolean onlyBundled, Set<Module> out) {
        if (!out.add(m)) return;
        for (String[] d : m.modDeps) {
            if (onlyBundled && (d[1].equals("provided") || d[1].equals("system"))) continue;
            collect(byId.get(d[0]), byId, onlyBundled, out);
        }
    }

    // ------------------------------------------------------------------ compile

    private void compileModule(Module m, Map<String, Module> byId, Options o, File classLib) throws Exception {
        List<File> srcRoots = sourceRoots(m.dir);
        if (srcRoots.isEmpty()) {
            log.log("  " + m.id + ": no Java sources, skipped");
            m.classes = new File(work, "build/" + m.id + "/classes");
            m.classes.mkdirs();
            m.resRoots = resourceRoots(m);
            return;
        }
        srcRoots = expandLombok(m, srcRoots);

        m.classes = new File(work, "build/" + m.id + "/classes");
        m.classes.mkdirs();
        int lvl = o.javaVersion > 0 ? o.javaVersion : m.cfg.javaVersion > 0 ? m.cfg.javaVersion : 17;
        if (lvl > MAX_JAVA) {
            log.log("  Java " + lvl + " is above what the bundled compiler supports, using " + MAX_JAVA);
            lvl = MAX_JAVA;
        }
        if (lvl < 8) lvl = 8;
        log.log("  " + m.id + ": compiling (Java " + lvl + ")");

        List<String> args = new ArrayList<>();
        args.add(lvl <= 8 ? "-1.8" : "-" + lvl);
        args.addAll(Arrays.asList("-encoding", "UTF-8", "-proc:none", "-nowarn", "-g", "-parameters",
                "-bootclasspath", classLib.getPath(), "-d", m.classes.getPath()));
        Set<File> cp = new LinkedHashSet<>(m.res.classpath());
        for (Module d : moduleClosure(m, byId, false)) {
            cp.add(d.classes);
            cp.addAll(d.res.classpath());
        }
        if (!cp.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (File f : cp) { if (sb.length() > 0) sb.append(File.pathSeparator); sb.append(f.getPath()); }
            args.add("-classpath");
            args.add(sb.toString());
        }
        for (File s : srcRoots) args.add(s.getPath());

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        boolean ok = BatchCompiler.compile(args.toArray(new String[0]), pw, pw, null);
        pw.flush();
        String outText = sw.toString().trim();
        if (!outText.isEmpty()) {
            String[] lines = outText.split("\\n");
            for (int i = 0; i < lines.length && i < 120; i++) {
                log.log(lines[i].replace(work.getPath() + "/build/" + m.id + "/src", ".").replace(m.dir.getPath(), "."));
            }
            if (lines.length > 120) log.log("... (" + (lines.length - 120) + " more lines)");
        }
        if (!ok) throw new IOException("Compilation failed in module " + m.id + ". See the errors above.");
        m.resRoots = resourceRoots(m);
        for (File r : m.resRoots) {
            if (new File(r, "plugin.yml").isFile() || new File(r, "paper-plugin.yml").isFile()) m.hasPluginYml = true;
        }
    }

    /** Applies the simplified Lombok expansion to a copy of the sources when needed. */
    private List<File> expandLombok(Module m, List<File> srcRoots) throws IOException {
        boolean any = false;
        for (File r : srcRoots) if (containsLombok(r)) { any = true; break; }
        if (!any) return srcRoots;
        File dst = new File(work, "build/" + m.id + "/src");
        List<String> warnings = new ArrayList<>();
        List<File> out = new ArrayList<>();
        int i = 0;
        for (File r : srcRoots) {
            File d = new File(dst, "r" + (i++));
            copyExpanded(r, d, warnings);
            out.add(d);
        }
        log.log("  " + m.id + ": Lombok annotations expanded");
        for (String w : new LinkedHashSet<>(warnings)) log.log("  Warning: " + w);
        return out;
    }

    private static boolean containsLombok(File dir) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return false;
        for (File f : fs) {
            if (f.isDirectory()) { if (!SKIP_DIRS.contains(f.getName()) && containsLombok(f)) return true; }
            else if (f.getName().endsWith(".java") && MiniLombok.usesLombok(readText(f))) return true;
        }
        return false;
    }

    private static void copyExpanded(File src, File dst, List<String> warnings) throws IOException {
        File[] fs = src.listFiles();
        if (fs == null) return;
        dst.mkdirs();
        for (File f : fs) {
            if (f.isDirectory()) {
                if (!SKIP_DIRS.contains(f.getName())) copyExpanded(f, new File(dst, f.getName()), warnings);
            } else if (f.getName().endsWith(".java")) {
                String t = readText(f);
                if (MiniLombok.usesLombok(t)) t = MiniLombok.transform(t, warnings);
                Files.write(new File(dst, f.getName()).toPath(), t.getBytes(StandardCharsets.UTF_8));
            }
        }
    }

    // ------------------------------------------------------------------ package

    private File packModule(Module m, Map<String, Module> byId) throws IOException {
        ProjectConfig cfg = m.cfg;
        List<File> classDirs = new ArrayList<>();
        classDirs.add(m.classes);
        List<File> resRoots = new ArrayList<>(m.resRoots);
        Set<File> libs = new LinkedHashSet<>();
        List<String[]> rules = new ArrayList<>(cfg.relocations);
        if (cfg.shade) {
            libs.addAll(m.res.bundled());
            for (Module d : moduleClosure(m, byId, true)) {
                classDirs.add(d.classes);
                resRoots.addAll(d.resRoots);
                libs.addAll(d.res.bundled());
                rules.addAll(d.cfg.relocations);
            }
        }
        Map<String, String> vars = new HashMap<>(cfg.vars);
        if (cfg.version != null) { vars.put("project.version", cfg.version); vars.put("version", cfg.version); }
        File jar = new File(work, "build/" + jarName(cfg, m.dir) + ".jar");
        Set<String> entries = Packager.pack(jar, classDirs, resRoots, vars, new ArrayList<>(libs), new Relocator(rules));
        if (!entries.contains("plugin.yml") && !entries.contains("paper-plugin.yml")) {
            log.log("  Warning: " + jar.getName() + " has no plugin.yml");
        }
        log.log("  " + jar.getName() + " (" + (jar.length() / 1024) + " KB)");
        return jar;
    }

    // ------------------------------------------------------------------ helpers

    private File ensureClassLib() throws IOException {
        if (bundledLib != null && bundledLib.isFile() && bundledLib.length() > 1_000_000L) {
            log.log("  full JDK class library (bundled)");
            return bundledLib;
        }
        File f = new File(work, "sdk/android.jar");
        if (f.isFile() && f.length() > 20_000_000L) {
            log.log("  Android class library (limited: no java.net.http / java.awt)");
            return f;
        }
        log.log("  Downloading the Java class library (about 26 MB, one time)...");
        if (!Net.download(ANDROID_JAR_URL, f, log)) {
            throw new IOException("Could not download the Java class library. Check your internet connection.");
        }
        log.log("  Note: this library lacks java.net.http and java.awt");
        return f;
    }

    private static Pom.Dep dep(String g, String a, String v, String scope) {
        Pom.Dep d = new Pom.Dep();
        d.g = g; d.a = a; d.v = v; d.scope = scope;
        return d;
    }

    private static File locateRoot(File dir) {
        for (int i = 0; i < 2; i++) {
            if (looksLikeProject(dir)) return dir;
            File[] subs = dir.listFiles(File::isDirectory);
            if (subs == null || subs.length != 1) return dir;
            dir = subs[0];
        }
        return dir;
    }

    private static boolean looksLikeProject(File d) {
        return new File(d, "pom.xml").isFile() || new File(d, "build.gradle").isFile()
                || new File(d, "build.gradle.kts").isFile() || new File(d, "settings.gradle").isFile()
                || new File(d, "src").isDirectory() || new File(d, "plugin.yml").isFile();
    }

    private static List<File> sourceRoots(File root) {
        File m = new File(root, "src/main/java");
        if (m.isDirectory() && hasJava(m)) return Collections.singletonList(m);
        File s = new File(root, "src");
        if (s.isDirectory() && hasJava(s)) return Collections.singletonList(s);
        File flat = new File(root, "plugin.yml").isFile() || new File(root, "pom.xml").isFile() ? root : null;
        if (flat != null && hasJava(root)) return Collections.singletonList(root);
        return Collections.emptyList();
    }

    private static boolean hasJava(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) return false;
        for (File f : fs) {
            if (f.isDirectory()) {
                if (!SKIP_DIRS.contains(f.getName()) && hasJava(f)) return true;
            } else if (f.getName().endsWith(".java")) return true;
        }
        return false;
    }

    private List<File> resourceRoots(Module m) {
        File root = m.dir;
        for (String p : new String[]{"src/main/resources", "resources", "src/resources"}) {
            File r = new File(root, p);
            if (r.isDirectory()) return Collections.singletonList(r);
        }
        File py = findFile(root, "plugin.yml");
        if (py == null) py = findFile(root, "paper-plugin.yml");
        if (py == null) return Collections.emptyList();
        File tmp = new File(work, "build/" + m.id + "/res");
        tmp.mkdirs();
        for (String n : new String[]{"plugin.yml", "paper-plugin.yml", "config.yml"}) {
            File src = new File(py.getParentFile(), n);
            if (src.isFile()) {
                try { Files.copy(src.toPath(), new File(tmp, n).toPath()); } catch (IOException ignored) { }
            }
        }
        return Collections.singletonList(tmp);
    }

    private static File findFile(File dir, String name) {
        File[] fs = dir.listFiles();
        if (fs == null) return null;
        for (File f : fs) if (f.isFile() && f.getName().equals(name)) return f;
        for (File f : fs) {
            if (f.isDirectory() && !SKIP_DIRS.contains(f.getName())) {
                File r = findFile(f, name);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static String jarName(ProjectConfig c, File dir) {
        String n;
        if (c.finalName != null && !c.finalName.contains("${")) n = c.finalName;
        else if (c.version != null) n = c.name + "-" + c.version;
        else n = c.name != null ? c.name : dir.getName();
        return n.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static String readText(File f) throws IOException {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    static void deleteRecursive(File f) {
        File[] fs = f.listFiles();
        if (fs != null) for (File c : fs) deleteRecursive(c);
        f.delete();
    }
}
